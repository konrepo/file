import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
import urlresolver

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonThai')
addon_name = 'plugin.video.KonThai'


KHMOTION ='https://www.khmotionn.com/'
KHDRAMA ='http://movie.pkhmer.com/'
JONGMEL ='http://www.merlroeungtamtv.club/'
K8MER = 'http://www.phumi-thai9.com/'
KHREPLAY ='https://www.khreplay8.com/'
PHUMKOM ='http://www.phumkomsan.com/'
KHMERKOM ='http://www.citykhmer9.com/'
PHUMIHD ='https://www.phumihd.com/'
VIDEO4U ='http://www.video4khmer36.com/'
PHUMIKHMER ='http://phumikhmer.club/'
PHUMIKHMER1 ='https://phumikhmer.media/'
PHUMIKHMER2 ='http://www.phumikhmer1.com/'
LAKHOAN ='http://www.khmerallmovie.com/'
MERLKON ='http://www.merlkon.net/'
TUBE_KHMER ='http://www.khmer.video/'
MERL7 ='http://www.merl7.com/'
DRAMA4 ='http://www.khmer-drama.com/'
Chan7 ='http://mvkhmer.com/'
CITY ='http://www.khmerkomsan.net/' 
MERLKON1 ='http://www.khmerdrama.com/' 
CKH7 ='http://www.ckh7.com/' 
KM168 ='http://www.kolabkhmer7.club/'
MERL ='https://www.merlhd.club/'


USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
SearchImage = os.path.join(ADDON_PATH, 'resources', 'images','search.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')
songImage = os.path.join(ADDON_PATH, 'resources', 'images','song.jpg')
videoImage = os.path.join(ADDON_PATH, 'resources', 'images','video.jpg')
tvImage = os.path.join(ADDON_PATH, 'resources', 'images','tv.png')

# KhmerTV
def OpenURLS(url):
	cj = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	opener.addheaders = [('Content-Type','application/x-www-form-urlencoded'),
		('User-Agent', 'Dalvik/2.1.0 (Linux; U; Android 7.0; SM-G955F Build/NRD90M)'),
		('Host','hd.khmertv.xyz'),
		('Connection','keep-alive'),
		('Accept-Encoding','gzip'),
		('Content-Length','23')]
	usock = opener.open(url,data)
	if usock.info().get('Content-Encoding') == 'gzip':
		buf = StringIO.StringIO(usock.read())
		f = gzip.GzipFile(fileobj=buf)
		response = f.read()
	else:
		response = usock.read()
	usock.close()
	return (response)
# End


def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response

def GetInput(strMessage,headtxt,ishidden):
    keyboard = xbmc.Keyboard("",strMessage,ishidden)
    keyboard.setHeading(headtxt) # optional
    keyboard.doModal()
    inputText=""
    if (keyboard.isConfirmed()):
        inputText = keyboard.getText()
    del keyboard
    return inputText	
	 
def HOME():
		addDir('Search',MERLKON,5,SearchImage+'')	
		addDir('Khmer Drama',KM168+'search/label/KHMER?&max-results=24',211,'https://3.bp.blogspot.com/-RZvc1uxiryw/W-DikglgySI/AAAAAAAACco/oBUuktIzTJALzxzBR90dKlFk41hWoxaAACLcBGAs/s1600/Kon%2BPus%2BKengkong.jpg')				
		addDir('7Khmer',KHMOTION+'search/label/Thai%20Drama?&max-results=20',11,'http://1.bp.blogspot.com/-eYngwVMs7wk/VbIiF42BlDI/AAAAAAAAMpc/APh97n98Vy4/s1600/7khmer%2Blogo.png')
		addDir('Boran',MERLKON+'genre/thai-boran/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')	
		#addDir('CityKhmer',KHMERKOM+'category.php?cat=thai-drama',81,'http://www.citykhmer9.com/templates/default/img/logo-school.png')			
		addDir('CKH7',CKH7+'category.php?cat=thai-drama',201,'http://www.ckh7.com/templates/default/img/logo.png')		
		addDir('Drama4Khmer',DRAMA4+'category.php?cat=thai-drama',161,'http://www.khmer-drama.com/templates/default/img/khmer-drama.png')		
		#addDir('Lovevod',JONGMEL+'search/label/Thailand',41,'https://lh3.googleusercontent.com/-6ij55yZ9DnY/WN3XXm3HNNI/AAAAAAAAQFQ/aWW4Ys6LVtcLL0WfMp60JZRsegLmsTz1gCLcB/h1600/jm-pf.png')	
		addDir('Horror',MERLKON+'genre/horror/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')
		addDir('KhmerTvDrama',MERLKON1+'albumcategory/thai/',191,'http://www.khmerdrama.com/wp-content/uploads/2017/02/kd-logo.png')
		addDir('KhmerKomsan',CITY+'category.php?cat=thai-drama',181,'http://www.khmerkomsan9.com/templates/default/img/KhmerKomsan.png')
		#addDir('Khreplay8',KHREPLAY+'search/label/Thailand?&max-results=16',31,'https://4.bp.blogspot.com/-SjgUAOtc5gI/W3QkCiozQLI/AAAAAAAAE2w/hMRAJP_mdVofEN-1I_xdXPaMwNdyqYCbgCK4BGAYYCw/s1600/khreplay.png')	
		addDir('KolapKhmer',KM168+'search/label/THAI?&max-results=24',211,'https://2.bp.blogspot.com/-Fs1Xu7DJ20k/WojR-gsNIOI/AAAAAAAAOgQ/xGXdg-jUr0YAfbRCvLj_q2P5a_SqXmTWgCK4BGAYYCw/s1600/kolabkhmer%2Blogo%2B1.png')			
		#addDir('Lakhoan',LAKHOAN+'search/label/Thai%20Lakorn',121,'http://4.bp.blogspot.com/-IeF6JqLHJkE/Vk88zTPRrAI/AAAAAAAAAdQ/qj3rA3tiYXo/s1600-r/logo.png')	
		addDir('Merl7',MERL7+'search/label/Thai%20Lakorn',151,'http://1.bp.blogspot.com/-gH925wHJgg4/V2Y0JovOicI/AAAAAAAADR8/EJquSrKR4IIv9X8Ou64aJ6ANyGtLVe7bQCK4B/s1600/merl7.png')		
		addDir('MerlHD',MERL+'search/label/Thai%20Drama?&max-results=20',21,'https://3.bp.blogspot.com/-plaeV5Paei0/WpiesrNaoeI/AAAAAAAAAm0/NT73FOu8J50zdNYflNX2Q5-RSNd9oPJlgCK4BGAYYCw/s1600/MerlHD-logo.png')		
		addDir('Mayura',MERLKON+'dubbed/mayura',131,'http://logos.textgiraffe.com/logos/logo-name/Mayura-designstyle-birthday-m.png')			
		addDir('Merlkon',MERLKON+'genre/modern-thai/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')	
		addDir('MerlkonHD',MERLKON+'albumcategory/hd-videos/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')		
		addDir('PhumiHD',PHUMIHD+'drama/thai-lakorn/',91,'http://www.phumihd.com/wp-content/uploads/2014/10/phd-01.png')
		addDir('PhumiKhmer',PHUMIKHMER+'category/thai-lakorn/',111,'http://1.bp.blogspot.com/-i6AYFwrqk5A/WBP85TWifNI/AAAAAAAACYc/tJWxkJFCkpEpYMVxUaqOpDcbffBkw2ixgCK4B/s1600/PhumiKhmer-logo-2017-web.PNG')
		addDir('PhumiMedia',PHUMIKHMER1+'page/1/',221,'https://4.bp.blogspot.com/-OlhlObrvgSc/WKLHP0Ii2YI/AAAAAAAAC0Q/-lBVlE1h24QOll92L10agxH3Ax6rqxryQCLcB/s300/400.PNG')		
		addDir('PhumiKhmer1',PHUMIKHMER2+'newvideos.php',231,'http://www.phumikhmer1.com/templates/default/img/phumikhmer-logo.png')	
		#addDir('PhumKomsan',PHUMKOM+'search/label/Thai%20Drama',71,'http://1.bp.blogspot.com/-mLnQCEv8hRs/V_sSRlxVgSI/AAAAAAAABGE/qHwOVe1JiJEGrwllFV7dUBIhbFUbS0DoACK4B/s1600/phum-komsan-web-logo.png')
		addDir('PhumiThai9',K8MER+'khmer-dubbed-thai-lakorn-category/completed-drama-lakorn-catalogue-537-page-1.html',51,'http://www.phumi-thai9.com/templates/thailakorn/images/logo.png')			
		addDir('TubeKhmer',TUBE_KHMER+'search/label/Thai%20Lakorn?&max-results=15',141,'http://1.bp.blogspot.com/-ptat91ZIzbw/V5wk9Br2GRI/AAAAAAAAAXM/keCw24Msw8wELtZhPiRZ-E9bf6cWTQeTQCK4B/s1600/H-90.gif')		
		addDir('VideoKhmer',VIDEO4U+'khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')
		addDir('Video4Khmer',VIDEO4U+'khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')
		
		xbmcplugin.endOfDirectory(pluginhandle)

### search ###
def SEARCH():
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        #searchText = '01'
        if (keyb.isConfirmed()):
                searchText = urllib.quote_plus(keyb.getText())
        url = 'http://www.khmerdrama.com/?s='+ searchText
        SINDEX_MERLKON1(url)
        url = 'https://www.khmotionn.com/search?q='+ searchText
        SINDEX_KHMOTION(url)
        url = 'http://www.video4khmer36.com/search.php?keywords='+ searchText
        SINDEX_VIDEO4U(url)	
        url = 'http://www.kolabkhmer7.club/search/max-results=8?q='+ searchText
        SINDEX_KOLAB(url)	
        url = 'http://www.khmer-drama.com/search.php?keywords='+ searchText
        SINDEX_KHDRAMA(url)	
        #url = 'http://www.citykhmer9.com/search.php?keywords='+ searchText
        #SINDEX_KHMERKOMSAN(url)		
        url = 'http://www.ckh7.com/search.php?keywords='+ searchText
        SINDEX_CKH7(url)			
        url = 'http://www.phumkomsan.com/search?q='+ searchText
        SINDEX_PHUMKOM(url)	
        url = 'https://www.phumihd.com/?s='+ searchText
        SINDEX_PHUMIHD(url)		
        url = 'http://phumikhmer.club/?s='+ searchText
        SINDEX_PHUMIKHMER(url)	
        url = 'https://phumikhmer.media/?s='+ searchText
        SINDEX_PHUMIKHMER1(url)		
        url = 'http://www.merlkon.net/?s='+ searchText
        SINDEX_MERLKON(url)		
        url = 'http://www.merlkon.net/?s='+ searchText
        SINDEX_MAYURA(url)	
        url = 'http://www.merl7.com/search?q='+ searchText
        SINDEX_MERL7(url)			
        url = 'http://www.khmerkomsan.net/search.php?keywords='+ searchText
        SINDEX_CITY(url)	
        #url = 'https://www.khreplay8.com/search?q='+ searchText
        #SINDEX_KHREPLAY(url)
### End search ####	

############## khreplay SITE ****************** 
def INDEX_KHREPLAY(url):     
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,35,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,31,"")                       
        xbmcplugin.endOfDirectory(pluginhandle)

###search ###		
def SINDEX_KHREPLAY(url):     
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] KHREPLAY[/COLOR]',vLink,35,vImage)	
### end ###
	
def EPISODE_KHREPLAY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 		


############## 7Khmer SITE ****************** 
def INDEX_MERL(url):     
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,25,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,21,"")                       
        xbmcplugin.endOfDirectory(pluginhandle)

###search ###		
def SINDEX_MERL(url):     
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] MerlHD[/COLOR]',vLink,25,vImage)	
### end ###
	
def EPISODE_MERL(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle)

############## khmerkomsan SITE ****************** 			   
def INDEX_CITY(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,185,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmerkomsan9.com/' + pageurl.encode("utf-8")),181,"")		 
         except:pass
		 
### search ##			
def SINDEX_CITY(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] KHMERKOMSAN[/COLOR]',vLink,185,vImage)			
##end ##		 

def EPISODE_CITY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 
		
############## KOLAPKHMER SITE ****************** 			 
def INDEX_KM168(url):     
     #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,215,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,211,"") 

### search ##			
def SINDEX_KOLAB(url):
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] KOLABKHMER[/COLOR]',vLink,215,vImage)			
##end ##
			
def EPISODE_KM168(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')
        else: 
         match=re.compile('<a href="(.+?)" rel="nofollow" target="_blank">(.+?)</a>').findall(link)
         if(len(match) > 0):     
          for vLink, vLinkName in match:
           addLink(vLinkName,vLink,3,'')			
		
############## ckh7 SITE ****************** 
def INDEX_CKH7(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,205,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.ckh7.com/' + pageurl.encode("utf-8")),201,"")		 
         except:pass	
		 
## SEARCH ##

def SINDEX_CKH7(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] CKH7[/COLOR]',vLink,205,vImage)
##END ##		 
						
def EPISODE_CKH7(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')		   		
		
		
############## 7Khmer SITE ****************** 
def INDEX_KHMOTION(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' id=\'pindah-judul\' itemprop=\'headline\'>\n<a href=\'(.+?)\' itemprop=\'url mainEntityOfPage\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;",""),vurl,15,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir(pagenum.replace("Older Posts","Next Page").replace("Newer Posts","Prev Page"),pageurl,11,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)
		
###search ###		
def SINDEX_KHMOTION(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' id=\'pindah-judul\' itemprop=\'headline\'>\n<a href=\'(.+?)\' itemprop=\'url mainEntityOfPage\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;","")+'[COLOR red] 7KHMER[/COLOR]',vurl,15,vimage)		
### end ###		
	
def EPISODE_KH(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle) 
		
############## drama4khmers SITE ****************** 			   
def INDEX_DRAMA4(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"heading"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt'].replace("&euro;&lsaquo;","")
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,165,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmer-drama.com/' + pageurl.encode("utf-8")),161,"")		 
         except:pass 
		 
### SEARCH ###
def SINDEX_KHDRAMA(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"heading"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;","")+'[COLOR red] DRAMA4K[/COLOR]',vLink,165,vImage)		 
## END ##		 

def EPISODE_DRAMA4(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'')		      


############## LOVEVOD SITE ****************** 		
def INDEX_JONGMEL(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' itemprop=\'name headline\'>\n<a href=\'(.+?)\' itemprop=\'url\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname,vurl,45,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir(pagenum.replace("Older Posts","Next Page").replace("Newer Posts","Prev Page"),pageurl,41,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)			
   
def EPISODE_JONGMEL(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')		

############## phumi-thai9 SITE ****************** 		
def INDEX_K8MERHD(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"movie-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,55,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,51,"")
        except:pass 
				
def EPISODE_K8MERHD(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content"})
        for item in listcontent[0].findAll('div', {"class" :"movie-thumb"}):
			vname=item.a.img["alt"]
			vname = vname.encode("UTF-8",'replace')   
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        try:
			paging = soup('div',{'class':'pagination'})
			pages = BeautifulSoup(str(paging[0]))('a')
			for p in pages:
				psoup = BeautifulSoup(str(p))
				pageurl = psoup('a')[0]['href']
				pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir(" Page " + pagenum.encode("utf-8") ,pageurl,55,"")
        except:pass 	

############## Phumkomsan SITE ****************** 		  
def INDEX_PHUMKOM(url):
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumbimage imglatest"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,75,vImage)		  
         pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE',pageurl,71,"")                    

### SEARCH ###				
def SINDEX_PHUMKOM(url):
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumbimage imglatest"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle+'[COLOR red] DRAMA4K[/COLOR]',vLink,75,vImage)				
## END ##				
		  
def EPISODE_PHUMKOM(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')			 

############## CityKhmer9 SITE ****************** 
def INDEX_KHMERKOMSAN(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vTitle = BeautifulSoup(str(link))('img')[0]['alt']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,85,vImage)
			
        try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace('&laquo;','Prev').replace('&raquo;','Last').replace('...','')
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.citykhmer9.com/' + pageurl.encode("utf-8")),81,"")
        except:pass
		
##SEARCH ##
def SINDEX_KHMERKOMSAN(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vTitle = BeautifulSoup(str(link))('img')[0]['alt']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle+'[COLOR red] CITYKHMER[/COLOR]',vLink,85,vImage)		
## END ###		
			    
def EPISODE_KHMERKOMSAN(url,name):    
        link = OpenURL(url)        
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
             addLink(vLinkName,vLink,4,'')
        else: 
         match=re.compile('[^>]*{"idGD":\s*"([^"]+?)"').findall(link)
         print 'MATCHIFRAM: %s' % match
         if(len(match) > 0):
           EPlink = match[0].replace("0!?^0!?A"," ")       
           match = EPlink.split(' ')   
           counter = 0      
           for vLink in match:
               counter += 1 
               addLink(name.encode("utf-8") + " part " + str(counter), 'https://docs.google.com/file/d/%s' % vLink,4,'')
         else:
           match=re.compile('<div id="Playerholder">\r\n\t\t\t<iframe [^>]*src="([^"]+?)"').findall(link)
           print 'MATCHPLAY: %s' % match
           if(len(match) > 0):      
            for vLink in match:
              addLink(name.encode("utf-8"),vLink,4,'')		  


############## KhmerTvDrama SITE ****************** 		  
def INDEX_MERLKON1(url):    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8211;","").replace("&#8217;","").replace("Source 2",""),vLink,195,vImage)
        match5=re.compile('<div class=\'wp-pagenavi\'>\n(.+?)\n</div>').findall(html)
        if(len(match5)):
           pages=re.compile('<a class=".+?" href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.replace("&raquo;","").replace("&laquo;",""),pageurl.encode("utf-8"),191,"")                            
        xbmcplugin.endOfDirectory(pluginhandle)
	
## SEARCH ##	
def SINDEX_MERLKON1(url):    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8211;","").replace("&#8217;","").replace("Source 2","")+'[COLOR red] KhmerTvDrama[/COLOR]',vLink,195,vImage)		

## END ##
			
def EPISODE_MERLKON1(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",\s*"description":\s*".+?",\s*"image":\s*"(.+?)"').findall(link)			
        if(len(match) > 0):      
         for vLink,vLinkName,vImage in match:                 
          addLink(vLinkName,vLink,4,vImage)			  
			  
			  
############## PhumiHD SITE ****************** 
def INDEX_PHUMIHD(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"thumb"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,95,vImage)
         try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,91,"")
         except:pass
				
## SEARCH ##
def SINDEX_PHUMIHD(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"thumb"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] PHUMIHD[/COLOR]',vLink,95,vImage)
## END ##			 
						
def EPISODE_PHUMIHD(url,name):
         html = OpenSoup(url)
         addLink(name,url,3,'')
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode("utf-8"))
         epis = soup('a',{"class":"related-post"})
         for link in epis:	 
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0].contents[2]
             addLink(vTitle,vLink,3,'')

############## video4khmer1 SITE ****************** 
def INDEX_VIDEO4U(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,105,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,101,"")
        except:pass

### SEARCH ##
def SINDEX_VIDEO4U(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle+'[COLOR red] VIDEO4U[/COLOR]',vLink,105,vImage)
## END ##		
     
def EPISODE_VIDEO4U(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content-center"})
        for item in listcontent[0].findAll('div', {"class" : "movie-thumb"}):
			vname=item.a.img["alt"]
			vname = vname.encode("UTF-8",'replace')   
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        for item in listcontent[0].findAll('li'):
             if(item.a!=None):
				pageurl=item.a["href"]
				pagenum=item.a.contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir("Page " + pagenum,pageurl,105,"")
    #except: pass
     #xbmcplugin.endOfDirectory(pluginhandle)
	 
def EPISODE4U(url,name):        
        link = OpenURL(url)
        match=re.compile('<div class=".+?"><div class="movie-thumb"><a href="(.+?)"><img src="(.+?)" alt=".+?" title="(.+?)" width="180" height="170"').findall(link)
        counter = 1
        #for url,name,thumbnail in match:
        if (len(match) >= 1):
           for vLink,Vimage,vLinkName in match:
               counter += 1
               addLink(vLinkName,vLink,3,Vimage)
        match5=re.compile('<div class="pagination">(.+?)</div>').findall(link)
        if(len(match5)):
           pages=re.compile('<a href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.encode("utf-8"),pageurl,105,"")     
           xbmcplugin.endOfDirectory(pluginhandle)

############## Phumikhmer.club SITE ****************** 	
def INDEX_PHUMIKHMER(url):     
    #try:
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle,vLink,115,vImage)
        pages=re.compile("<a class='page-numbers' href='(.+?)'>(.+?)</a>").findall(html)
        for pageurl,pagenum in pages:
            addDir("[B][COLOR blue]Page %s[/B][/COLOR]"% pagenum.encode("utf-8"),pageurl,111,"")

### SEARCH ##
def SINDEX_PHUMIKHMER(url):     
    #try:
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle+'[COLOR red] PHUMICLUB[/COLOR]',vLink,115,vImage)
## END ##			
			
def EPISODE_PHUMIKHMER(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	
		  
############## Phumikhmer.media SITE ****************** 	
def INDEX_PHUMIKHMER1(url):  
    #try:
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle,vLink,225,vImage)
        pagecontent=soup.findAll('div', {"class" : re.compile("page-nav*")})
        if(len(pagecontent)>0):
            for item in pagecontent[0].findAll('a', {"class" : ["page", "last"]}):
				addDir("page " + item.contents[0],item["href"],221,"")

## SEARCH ##
def SINDEX_PHUMIKHMER1(url):  
    #try:
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle+'[COLOR red] PHUMIMEDIA[/COLOR]',vLink,225,vImage)
## END ##			

def buildNextPage2(pagenum,label):
	pagecount=str((int(pagenum) - 1) * 18)
	url=PHUMIKHMER1+"feeds/posts/summary/?start-index="+pagecount+"&max-results=1&alt=json-in-script&callback=finddatepost"
	link = OpenURL(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('"published":\{"\$t":"(.+?)"\}').findall(link)
	print match
	if(len(match)>0):
		tsvalue=urllib.quote_plus(match[0][0:19]+match[0][23:29])
		newurl=PHUMIKHMER1+"search/label/"+label+"?updated-max="+tsvalue+"&max-results=18#PageNo="+pagenum
	else:
		newurl=""
	return newurl

def EPISODE_PHUMIKHMER1(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')			  
		  
############## Phumikhmer1 SITE ****************** 
def INDEX_PHUMIKHMER2(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-6 col-sm-4 col-md-4"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;",""),vLink,235,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://phumikhmer1.com/' + pageurl.encode("utf-8")),231,"")		 
         except:pass

def EPISODE_PHUMIKHMER2(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'')	  
		  

############## khmerallmovie SITE ****************** 
def INDEX_LAKHOAN(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":'post-outer'})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,125,vImage)             
         pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
               addDir('NEXT PAGE',pageurl,121,"")
			   			 
						
def EPISODE_LAKHOAN(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')

############## Merlkon and Mayura SITE ****************** 		  
def INDEX_MERLKON(url):    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;",""),vLink,135,vImage)
        try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0]
             addDir(" Page " + pagenum.replace("&raquo;","").replace("&laquo;",""),pageurl.encode("utf-8"),131,"")
        except:pass 

## search ##
def SINDEX_MERLKON(url):    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;","")+'[COLOR red] MERLKON[/COLOR]',vLink,135,vImage)
			
def SINDEX_MAYURA(url):    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;","")+'[COLOR red] MAYURA[/COLOR]',vLink,135,vImage)			
## end ##		

def EPISODE_MERLKON(url,name):
        link = OpenURL(url)
        match=re.compile('<a href="(.+?)"><button type="button" class="btn btn-episode">(.+?)</button></a>').findall(link)     
        if(len(match) == 0):
          match=re.compile('<a href="(.+?)"><span style=".+?">(.+?)</span></a>').findall(link)
        for vLink, vLinkName in match:
            addLink(vLinkName,vLink,3,'')
        xbmcplugin.endOfDirectory(pluginhandle)		
		
############## TubeKhmer SITE ****************** 			
def INDEX_TUBE(url):
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            print vImage.encode("UTF-8")
            addDir(vTitle,vLink,145,vImage)
        label="" #re.compile("/label/(.+?)\?").findall(url)[0]
        print label
        pagenum=re.compile("PageNo=(.+?)").findall(url)
        print pagenum
        prev="0"
        if(len(pagenum)>0):
              prev=str(int(pagenum[0])-1)
              pagenum=str(int(pagenum[0])+1)

        else:
              pagenum="2"
        nexurl=buildNextPage(pagenum,label)

        if(int(pagenum)>2 and prev=="1"):
              urlhome=url.split("?")[0]+"?"
              addDir("[B][COLOR blue]<< Back Page >>[/B][/COLOR]",urlhome,141,"")
        elif(int(pagenum)>2):
              addDir("[B][COLOR blue]<< Back Page >>[/B][/COLOR]",buildNextPage(prev,label),141,"")
        if(nexurl!=""):
              addDir("[B][COLOR green]<< Next Page >>[/B][/COLOR]",nexurl,141,"")
        
        #except:pass
    #xbmc.executebuiltin('Container.SetViewMode(500)')
        xbmcplugin.endOfDirectory(pluginhandle)	

def buildNextPage(pagenum,label):
	pagecount=str((int(pagenum) - 1) * 18)
	url=TUBE_KHMER+"feeds/posts/summary?start-index="+pagecount+"&max-results=1&alt=json-in-script&callback=finddatepost"
	link = OpenSoup(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('"published":\{"\$t":"(.+?)"\}').findall(link)
	if(len(match)>0):
		tsvalue=urllib.quote_plus(match[0][0:19]+match[0][23:29])
		newurl=TUBE_KHMER+"search/label/"+label+"?updated-max="+tsvalue+"&max-results=18#PageNo="+pagenum
	else:
		newurl=""
	return newurl
		
def EPISODE_TUBE(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')		
		
############## Merl7 SITE ****************** 		  
def INDEX_MERL7(url):    
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumb-area thumb-outer latest-img"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,155,vImage)		  
         pages=re.compile('<span class=\'pager-older-link\'>\n<a class=\'blog-pager-older-link btn\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE',pageurl,151,"")                    

## SEARCH ##
def SINDEX_MERL7(url):    
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumb-area thumb-outer latest-img"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle+'[COLOR red] MERL7[/COLOR]',vLink,155,vImage)
## END ##			 

def EPISODE_MERL7(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	

############## END OF VIDEO SITE ****************** 		
		
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):              
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link.replace('=m37','=m18')) 
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):   
                            match=re.compile('playlist: "(.+?)"').findall(link)# Good Link
                            if(len(match) == 0):
                             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# KhmerTV
                             if(len(match) == 0):							
                              match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                              for url in match:
                               vid = url[0].replace("['']", "")       
                               match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                               #REAL_VIDEO_HOST(match)
                               VIDEO_HOSTING(match)
                               print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
   
def VIDEO_HOSTING(vlink):          
           if 'dailymotion' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'khmotions.com' in vlink:   
                VideoURL = KHMOTIONS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Khmotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'kolabkhmer.club' in vlink:
                VideoURL = KOLABKHMERS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'ok.ru' in vlink:
                VideoURL = OKRU(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'hd.khmertv.xyz' in vlink:   
                VideoURL = KHMERTVHD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'mvkhmer.com/song' in vlink:   
                VideoURL = MVKHMER2(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'media.mvkhmer.com' in vlink:   
                VideoURL = MediaMVKhmer(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'google.com' in vlink:   
                VideoURL = DOCS_GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'vimeo' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)

           elif 'vid.me' in vlink:                   
                VideoURL = VIDDME(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vid.me Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'sendvid.com' in vlink:
                VideoURL = SENDVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sendvid Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'viddme' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Viddme Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'az665436' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,AZ Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'd1wst0behutosd' in vlink:
                #link = OpenURL(vlink)   
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,d1wst0behutosd Loading selected video)")
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
           #     Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,MP4UPLOAD Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'videobam' in vlink:  
                VideoURL = VIDEOBAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Videobam Loading selected video)")                                
                Play_VIDEO(VideoURL)     

           elif 'sharevids.net' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sharevids Loading selected video)")
                Play_VIDEO(VideoURL)   
                    # d = xbmcgui.Dialog()
                    # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')     
					
           elif 'videos4share.com' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,videos4share Loading selected video)")
                #Play_VIDEO(VideoURL)
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
				
           elif 'youtu.be' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")            
                Play_VIDEO(VideoURL)     

           elif 'youtube' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)
           else:
                #if 'grayshare.net' in vlink:
                if 'share.net' in vlink:    
                    VideoURL = vlink
                    print 'VideoURL: %s' % VideoURL
                    Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))    
                      # d = xbmcgui.Dialog()
                      # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')                
               
                else:
                    print 'VideoURL: %s' % vlink
                    xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonThai is loading...)")
                    Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                    #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                    #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)	

def DAILYMOTION(SID):
        match=re.compile('(dailymotion\.com\/(watch\?(.*&)?v=|(embed|v|user|video)\/))([^\?&"\'>]+)').findall(SID)                
        SID = match[0][len(match[0])-1]
        VideoURL = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' +SID
        return VideoURL

def KHMOTIONS(SID):
	req = urllib2.Request(SID)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()    
	match720p = re.compile('file:\s"(.+?)",.+?720.+?"', re.DOTALL).findall(link)
	match480p = re.compile('file:\s"(.+?)",.+?480.+?"', re.DOTALL).findall(link)
	match360p = re.compile('file:\s"(.+?)",.+?360.+?"', re.DOTALL).findall(link)
	match240p = re.compile('file:\s"(.+?)",.+?240.+?"', re.DOTALL).findall(link)
	matchSD = re.compile('file : "(.+?)"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	elif matchSD:
		VideoURL = matchSD[0]
	return VideoURL			
		
def OKRU(SID):
        VideoURL = urlresolver.HostedMediaFile(url=SID).resolve()
        return VideoURL 	

def KOLABKHMERS(SID):
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        VideoURL =  re.compile('"file":"(.+?)"').findall(link.replace('\/','/'))[0]
        return VideoURL	 		
		
def KHMERTVHD(Video_ID):
       link = OpenURLS(url)
       VideoURL=re.compile("<!\[CDATA\[(.*?)\]\]></tvurl>").findall(link)[0]
       return VideoURL			
		
def MediaMVKhmer(Video_ID):
        VideoURL = url
        return VideoURL

def MVKHMER2(Video_ID):
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('file="(.+?)"').findall(link)               
        for URL in match:
         VideoURL = URL.replace(" ","%20")
        return VideoURL 		
		
def DOCS_GOOGLE(Video_ID):
                docid=re.compile('/d/(.+?)/preview').findall(Video_ID)[0]
                cj = cookielib.LWPCookieJar()
                (cj,vidcontent) = GetContent2("https://docs.google.com/get_video_info?docid="+docid,"", cj) 
                html = urllib2.unquote(vidcontent)
                cookiestr=""
                for cookie in cj:
					cookiestr += '%s=%s;' % (cookie.name, cookie.value)
                try:
					html=html.encode("utf-8","ignore")
                except: pass
                stream_map = re.compile('fmt_stream_map=(.+?)&fmt_list').findall(html)
                if(len(stream_map) > 0):
					formatArray = stream_map[0].replace("\/", "/").split(',')
					for formatContent in formatArray:
						 formatContentInfo = formatContent.split('|')
						 qual = formatContentInfo[0]
						 vidlink = (formatContentInfo[1]).decode('unicode-escape')

                else:
						cj = cookielib.LWPCookieJar()
						newlink1="https://docs.google.com/uc?export=download&id="+docid  
						(cj,vidcontent) = GetContent2(newlink1,newlink, cj)
						soup = BeautifulSoup(vidcontent)
						downloadlink=soup.findAll('a', {"id" : "uc-download-link"})[0]
						newlink2 ="https://docs.google.com" + downloadlink["href"]
						vidlink=GetDirVideoUrl(newlink2,cj) 
                VideoURL = (vidlink+ ('|Cookie=%s' % cookiestr))
                return  VideoURL

def FACEBOOK (SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()
       vlink = 'http://www.facebook.com/video/video.php?v=' + str(link)
       #vlink = re.compile('"params","([\w\%\-\.\\\]+)').findall(link)[0]
       html = urllib.unquote(vlink.replace('\u0025', '%')).decode('utf-8')
       html = html.replace('\\', '')
       videoUrl = re.compile('(?:hd_src|sd_src)\":\"([\w\-\.\_\/\&\=\:\?]+)').findall(html)
       if len(videoUrl) > 0:    
           VideoURL =  videoUrl[0]
       else:
           VideoURL =  videoUrl
       return  VideoURL  

def MP4UPLOAD(SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()    
       VideoURL=re.compile('\'file\': \'(.+?)\'').findall(link)[0]
       return VideoURL

def SENDVID(SID):
        #Video_ID = urllib.unquote_plus(SID).replace("//", "http://")
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match = re.compile('<source src="([^"]+?)"').findall(link)
        #match = re.compile('<meta property="og:video:secure_url" content="([^"]+?)"').findall(link)
        #VideoURL = (match[0]).decode("utf-8")
        VideoURL =  urllib2.unquote(match[0]).replace("//", "http://")
        return VideoURL

def VIDDME(Video_ID):
        VideoURL = urlresolver.HostedMediaFile(url=url).resolve()
        #SID=re.compile('vid.me/e/(.+)').findall(Video_ID)[0]
        #URL = "https://vid.me/e/"+str(SID)
        #VideoURL = media_url = urlresolver.resolve(URL)
        return VideoURL      

def VIDEOBAM(Video_ID):        
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('"url"\s*:\s*"(.+?)","').findall(link)               
        for URL in match:
            if(URL.find("mp4") > -1):
               VideoURL = URL.replace("\\","")
        return VideoURL       

def VIMEO(Video_ID):
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            SID =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              SID =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
        VideoURL = 'plugin://plugin.video.vimeo/play/?video_id='+str(SID)
        return VideoURL
		
def VIMEO1(Video_ID):
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            vlink =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              vlink =re.compile("//vimeo.com/(.+?)\?").findall(Video_ID+'?')
        #result = common.fetchPage({"link": "http://player.vimeo.com/video/%s/config?type=moogaloop&referrer=&player_url=player.vimeo.com&v=1.0.0&cdn_url=http://a.vimeocdn.com" % vlink[0],"refering": HomeURL})
        result = common.fetchPage({"link": "http://player.vimeo.com/video/%s?title=0&byline=0&portrait=0" % vlink[0],"refering": HomeURL})        
        print 'Result: %s' % result
        collection = {}
        if result["status"] == 200:
            html = result["content"]
            html = html[html.find('={"cdn_url"')+1:]
            html = html[:html.find('}};')]+"}}"
            #print html
            collection = json.loads(html)
            print 'Collection: %s' %collection
            #codec = collection["request"]["files"]["codecs"][0]
            #print codec            
            video = collection["request"]["files"]["progressive"]#[0]
            #isHD = collection["request"]["files"][video]
            print 'VideoCOLL1: %s' % video
            if(len(video) > 2):
            #if video.get("720p"):
                VideoURL = video[2]['url']
                print 'VideoSD: %s' % VideoURL
            #elif(len(video) > 1):
            #    VideoURL = video[1]['url']
            #    print 'VideoSD: %s' % VideoURL
            else: 
               VideoURL = video[0]['url']
               print 'VideoLD: %s' % VideoURL
        return VideoURL
		
def YOUTUBE(SID):
        match=re.compile('(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)').findall(SID)
        if(len(match) > 0):
             URL = match[0][len(match[0])-1].replace('v/','')
        else:   
             match = re.compile('([^\?&"\'>]+)').findall(SID)
             URL = match[1].replace('v=','')
        VideoURL = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' +URL.replace('?','')     
        return VideoURL
###################### Resolver End  ###################        

def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)     
elif mode==5:
        SEARCH()		
	
elif mode==11:
        INDEX_KHMOTION(url)    
elif mode==15:
        EPISODE_KH(url,name)
elif mode==21:
        INDEX_MERL(url)    
elif mode==25:
        EPISODE_MERL(url,name)		
elif mode==31:
        INDEX_KHREPLAY(url)    
elif mode==35:
        EPISODE_KHREPLAY(url,name)			
elif mode==41:
        INDEX_JONGMEL(url)    
elif mode==45:
        EPISODE_JONGMEL(url,name)			
elif mode==51:
        INDEX_K8MERHD(url)    
elif mode==55:
        EPISODE_K8MERHD(url,name)			
elif mode==61:
        INDEX_KHMER4F(url)    
elif mode==65:
        EPISODE_KHMER4F(url,name)	
elif mode==71:
        INDEX_PHUMKOM(url)    
elif mode==75:
        EPISODE_PHUMKOM(url,name)	
elif mode==81:
        INDEX_KHMERKOMSAN(url)    
elif mode==85:
        EPISODE_KHMERKOMSAN(url,name)			
elif mode==91:
        INDEX_PHUMIHD(url)    
elif mode==95:
        EPISODE_PHUMIHD(url,name)		
elif mode==101:
        INDEX_VIDEO4U(url)    
elif mode==105:
        EPISODE_VIDEO4U(url,name)			
elif mode==111:
        INDEX_PHUMIKHMER(url)    
elif mode==115:
        EPISODE_PHUMIKHMER(url,name)
elif mode==121:
        INDEX_LAKHOAN(url)    
elif mode==125:
        EPISODE_LAKHOAN(url,name)
elif mode==131:
        INDEX_MERLKON(url)    
elif mode==135:
        EPISODE_MERLKON(url,name)
elif mode==141:
        INDEX_TUBE(url)    
elif mode==145:
        EPISODE_TUBE(url,name)		
elif mode==151:
        INDEX_MERL7(url)    
elif mode==155:
        EPISODE_MERL7(url,name)		
elif mode==161:
        INDEX_DRAMA4(url)    
elif mode==165:
        EPISODE_DRAMA4(url,name)	
elif mode==171:
        INDEX_CHAN7(url) 
elif mode==172:
        CDVCD(url)		
elif mode==173:
        EPISODE_CHAN7(url,name)		
elif mode==181:
        INDEX_CITY(url)    
elif mode==185:
        EPISODE_CITY(url,name)
elif mode==191:
        INDEX_MERLKON1(url)    
elif mode==195:
        EPISODE_MERLKON1(url,name)		
elif mode==201:
        INDEX_CKH7(url)    
elif mode==205:
        EPISODE_CKH7(url,name)
elif mode==211:
        INDEX_KM168(url)    
elif mode==215:
        EPISODE_KM168(url,name)		
elif mode==221:
        INDEX_PHUMIKHMER1(url)    
elif mode==225:
        EPISODE_PHUMIKHMER1(url,name)			
elif mode==231:
        INDEX_PHUMIKHMER2(url)    
elif mode==235:
        EPISODE_PHUMIKHMER2(url,name)	
	
		
xbmcplugin.endOfDirectory(int(sysarg))
        