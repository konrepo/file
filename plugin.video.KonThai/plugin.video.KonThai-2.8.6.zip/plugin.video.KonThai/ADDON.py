import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
import resolveurl
import jsunpack
import pickle
from dodge import dodge
dodge = dodge()

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonThai')
addon_name = 'plugin.video.KonThai'
addondl = 'plugin.video.khmerdl' ########## Download

WATCHASIAN ='https://www3.watchasian.co/'
KHMOTION ='https://www.khmotionn.com/'
K8MER = 'http://www.phumi-thai9.com/'
KHREPLAY ='https://alakorn.com/'
PHUMIHD ='https://www.phumihd.com/'  #offline
VIDEO4U ='http://www.video4khmer36.com/'
PHUMIKHMER ='http://phumikhmer.club/'  #offline
PHUMIKHMER1 ='https://phumikhmer.media/'
PHUMIKHMER2 ='http://www.phumikhmer1.com/'
MERLKON ='http://www.merlkon.net/'
TUBE_KHMER ='https://www.khmer-movie.club/'
MERL7 ='http://www.merl7.com/'
DRAMA4 ='http://www.thekomsan.com/'
CITY ='http://www.khmerkomsan.net/'
CKH7 ='http://www.ckh7.com/'
KM168 ='http://www.khmer7.club/'
MERL ='https://www.merlhd.club/'
KHMERFAN = 'http://www.khmerfans.com/'
AVERY ='https://dramavery.com/'


USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
########### download 
dpath = xbmc.translatePath('special://profile/addon_data/'+addondl+'/cookies/')
if not os.path.exists(dpath):
	os.makedirs(dpath)
###########
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
addon_name = PLUGIN.getAddonInfo('profile')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
SearchImage = os.path.join(ADDON_PATH, 'resources', 'images','search.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')
songImage = os.path.join(ADDON_PATH, 'resources', 'images','song.jpg')
videoImage = os.path.join(ADDON_PATH, 'resources', 'images','video.jpg')
tvImage = os.path.join(ADDON_PATH, 'resources', 'images','tv.png')
DramaImage = os.path.join(ADDON_PATH, 'resources', 'images','dramacool.png')

# KhmerTV
def OpenURLS(url):
	cj = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	opener.addheaders = [('Content-Type','application/x-www-form-urlencoded'),
		('User-Agent', 'Dalvik/2.1.0 (Linux; U; Android 7.0; SM-G955F Build/NRD90M)'),
		('Host','hd.khmertv.xyz'),
		('Connection','keep-alive'),
		('Accept-Encoding','gzip'),
		('Content-Length','23')]
	usock = opener.open(url,data)
	if usock.info().get('Content-Encoding') == 'gzip':
		buf = StringIO.StringIO(usock.read())
		f = gzip.GzipFile(fileobj=buf)
		response = f.read()
	else:
		response = usock.read()
	usock.close()
	return (response)
# End


def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response

def GetInput(strMessage,headtxt,ishidden):
    keyboard = xbmc.Keyboard("",strMessage,ishidden)
    keyboard.setHeading(headtxt) # optional
    keyboard.doModal()
    inputText=""
    if (keyboard.isConfirmed()):
        inputText = keyboard.getText()
    del keyboard
    return inputText	
	 
def HOME():
		addDir('Search',MERLKON,5,SearchImage+'')	
		addDir('Khmer Drama',KM168+'search/label/KHMER?&max-results=24',211,'https://3.bp.blogspot.com/-RZvc1uxiryw/W-DikglgySI/AAAAAAAACco/oBUuktIzTJALzxzBR90dKlFk41hWoxaAACLcBGAs/s1600/Kon%2BPus%2BKengkong.jpg')		
		#addDir('AsiaLakorn',KHREPLAY+'category/thai-lakorn/',31,'https://alakorn.com/wp-content/uploads/2018/05/AsiaLakorn-S.png')			
		addDir('7Khmer',KHMOTION+'search/label/Thai%20Drama?&max-results=20',11,'http://1.bp.blogspot.com/-eYngwVMs7wk/VbIiF42BlDI/AAAAAAAAMpc/APh97n98Vy4/s1600/7khmer%2Blogo.png')
		addDir('Boran',MERLKON+'genre/thai-boran/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')				
		addDir('CKH7',CKH7+'category.php?cat=thai-drama',201,'http://www.ckh7.com/templates/default/img/logo.png')			
		addDir('Drama4Khmer',DRAMA4+'category.php?cat=thai',161,'http://www.thekomsan.com/templates/default/img/the-komsan-logo.png')		
		#addDir('(D) Speak Thai',WATCHASIAN+'category/thailand-drama',81,DramaImage+'')
		#addDir('(A) Speak Thai',AVERY+'country/thailand/',82,'https://boxdrama.com/themes/ViewAsian/images/logo.png')		
		#addDir('(M) Speak Thai',WATCHASIAN+'category/thailand-movies',81,DramaImage+'')	
		addDir('Horror',MERLKON+'genre/horror/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')
		addDir('KhmerFans',KHMERFAN+'albumcategory/thai/',131,'http://www.khmerfans.com/wp-content/themes/khmerdrama/img/logo.png')
		addDir('KhmerKomsan',CITY+'category.php?cat=thai-drama',181,'http://www.khmerkomsan.net/templates/default/img/KhmerKomsan.png')	
		addDir('KolapKhmer',KM168+'search/label/THAI?&max-results=24',211,'https://2.bp.blogspot.com/-Fs1Xu7DJ20k/WojR-gsNIOI/AAAAAAAAOgQ/xGXdg-jUr0YAfbRCvLj_q2P5a_SqXmTWgCK4BGAYYCw/s1600/kolabkhmer%2Blogo%2B1.png')			
		addDir('Merl7',MERL7+'search/label/Thai%20Lakorn',151,'http://1.bp.blogspot.com/-gH925wHJgg4/V2Y0JovOicI/AAAAAAAADR8/EJquSrKR4IIv9X8Ou64aJ6ANyGtLVe7bQCK4B/s1600/merl7.png')		
		addDir('MerlHD',MERL+'search/label/Thai%20Drama?&max-results=20',21,'https://3.bp.blogspot.com/-plaeV5Paei0/WpiesrNaoeI/AAAAAAAAAm0/NT73FOu8J50zdNYflNX2Q5-RSNd9oPJlgCK4BGAYYCw/s1600/MerlHD-logo.png')		
		addDir('Mayura',MERLKON+'dubbed/mayura',131,'http://logos.textgiraffe.com/logos/logo-name/Mayura-designstyle-birthday-m.png')			
		addDir('Modern',MERLKON+'genre/modern-thai/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')	
		addDir('HD Videos',MERLKON+'albumcategory/hd-videos/',131,'http://www.merlkon.net/wp-contents/uploads/logo.jpg')		
		#addDir('PhumiHD',PHUMIHD+'drama/thai-lakorn/',91,'http://www.phumihd.com/wp-content/uploads/2014/10/phd-01.png')
		#addDir('PhumiKhmer',PHUMIKHMER+'category/thai-lakorn/',111,'http://1.bp.blogspot.com/-i6AYFwrqk5A/WBP85TWifNI/AAAAAAAACYc/tJWxkJFCkpEpYMVxUaqOpDcbffBkw2ixgCK4B/s1600/PhumiKhmer-logo-2017-web.PNG')
		addDir('PhumiMedia',PHUMIKHMER1+'category/thai-lakorn/',221,'https://4.bp.blogspot.com/-OlhlObrvgSc/WKLHP0Ii2YI/AAAAAAAAC0Q/-lBVlE1h24QOll92L10agxH3Ax6rqxryQCLcB/s300/400.PNG')		
		addDir('PhumiKhmer1',PHUMIKHMER2+'search/label/Thai?&max-results=24',231,'http://3.bp.blogspot.com/-VaXP9fkIUiw/XSIO0_BrYgI/AAAAAAAAD6U/a6qaOxqfQDo1Es3yghpemISQmFa2JEtBACK4BGAYYCw/s1600/custom-logo.png')	
		addDir('PhumiThai9',K8MER+'khmer-dubbed-thai-lakorn-category/completed-drama-lakorn-catalogue-537-page-1.html',51,'http://www.phumi-thai9.com/templates/thailakorn/images/logo.png')			
		#addDir('TubeKhmer',TUBE_KHMER+'search/label/THAI?&max-results=24',211,'https://1.bp.blogspot.com/-BmGAT-rD6D8/XACirHsqiNI/AAAAAAAACmU/MnRBKXtJBXgkR1O6ZxO2TBcFExybqCkbQCK4BGAYYCw/s1600/KHMER-Movie.gif')			
		addDir('VideoKhmer',VIDEO4U+'khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html',101,'http://www.video4khmer36.com/templates/kulenkiri/specials/kny2019/logo.png')
		addDir('Video4Khmer',VIDEO4U+'khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html',101,'http://www.video4khmer36.com/templates/kulenkiri/specials/kny2019/logo.png')		
		xbmcplugin.endOfDirectory(pluginhandle)

### search ###
def SEARCH():
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        #searchText = '01'
        if (keyb.isConfirmed()):
                searchText = urllib.quote_plus(keyb.getText())
        url = 'https://www.khmotionn.com/search?q='+ searchText
        SINDEX_KHMOTION(url)
        url = 'http://www.video4khmer36.com/search.php?keywords='+ searchText
        SINDEX_VIDEO4U(url)	
        url = 'http://www.kolabkhmer7.club/search/max-results=8?q='+ searchText
        SINDEX_KOLAB(url)	
        url = 'http://www.thekomsan.com/search.php?keywords='+ searchText
        SINDEX_KHDRAMA(url)	
        #url = 'https://www12.watchasian.co/search?type=movies&keyword='+ searchText
        #SINDEX_WATCHASIAN(url)		
        url = 'http://www.ckh7.com/search.php?keywords='+ searchText
        SINDEX_CKH7(url)			
        url = 'https://www.phumihd.com/?s='+ searchText
        SINDEX_PHUMIHD(url)		
        #url = 'http://phumikhmer.club/?s='+ searchText
        #SINDEX_PHUMIKHMER(url)	
        url = 'https://phumikhmer.media/?s='+ searchText
        SINDEX_PHUMIKHMER1(url)		
        url = 'http://www.merlkon.net/?s='+ searchText
        SINDEX_MERLKON(url)		
        url = 'http://www.merlkon.net/?s='+ searchText
        SINDEX_MAYURA(url)	
        url = 'http://www.merl7.com/search?q='+ searchText
        SINDEX_MERL7(url)			
        url = 'http://www.khmerkomsan.net/search.php?keywords='+ searchText
        SINDEX_CITY(url)	
        #url = 'https://asialakorn.com/?s='+ searchText
        #SINDEX_KHREPLAY(url)
        #url = 'https://dramavery.com/search/'+ searchText
        #SINDEX_AVERY(url)		
### End search ####	

############## DRAMAVERY SITE ****************** 
def INDEX_AVERY(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-xlg-2 col-lg-15 col-md-3 col-sm-4 col-xs-6"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,83,vImage)
        match5=re.compile('<ul class="pagination">(.+?)</ul>').findall(html)
        if(len(match5)):
           pages=re.compile('<a href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.encode("utf-8").replace("&laquo;","").replace("&raquo;",""),pageurl,82,"")     
           xbmcplugin.endOfDirectory(pluginhandle)
		   
def SINDEX_AVERY(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        link = OpenURL(url) 
        try:   
           link =link.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(link.decode('utf-8'))
        div_index = soup('div',{'class':"col-xlg-2 col-lg-15 col-md-3 col-sm-4 col-xs-6"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle+'[COLOR red] SPEAK THAI[/COLOR]',vLink,83,vImage)		   

def	EPISODE_AVERY(url,name):
	link = OpenURL(url+'watch')
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('<a data-id=".+?" href="(.+?)" title=".+?">(.+?)</a>').findall(link)
	for vurl,vname in match:
		addDir("Episode " + vname,vurl,84,'')
			
def HOST_AVERY(url,name):
	domain = urllib.quote_plus('https://p.dramavery.com/')
	link = OpenURL(url)
	match=re.compile('<iframe id="player-content" src="(.+?)"').findall(link.replace('//','https://'))[0]
	link2 = OpenURL(match)
	string = re.compile('<script type="text/javascript">;(.+?);</script>').findall(link2)[0]
	unpacked = jsunpack.unpack(string.replace('\\',''))
	data = re.compile("data:{url:'(.+?)'").findall(unpacked)[0]
	link3 = OpenURL('https://p.dramavery.com/player?url='+data+'&index=1&global='+domain)
	string2 = re.compile('</video> <script type="text/javascript">;(.+?);</script>').findall(link3)[0]
	unpacked2 = jsunpack.unpack(string2.replace('\\',''))
	data1 = re.compile('src="https://href.li\?(.+?)"').findall(unpacked2)[0]
	host = OpenURL(data1)
	match=re.compile('data-video="(.+?)">(.+?)</li>').findall(host.replace('//kshows','https://kshows'))
	for vurl,vname in match:
		addLink(vname,vurl,4,'')

############## asialakorn SITE ****************** 
def INDEX_KHREPLAY(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-block-span6'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,35,vImage)
        pagecontent=soup.findAll('div', {"class" : re.compile("page-nav*")})
        if(len(pagecontent)>0):
            for item in pagecontent[0].findAll('a', {"class" : ["page", "last"]}):
				addDir("page " + item.contents[0],item["href"],31,"")
				
###search ###		
def SINDEX_KHREPLAY(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-block-span6'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] ASIALOKORN[/COLOR]',vLink,35,vImage)	
### end ###
	
def EPISODE_KHREPLAY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 		


############## MERL ****************** 
def INDEX_MERL(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,25,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,21,"")                       
        xbmcplugin.endOfDirectory(pluginhandle)

###search ###		
def SINDEX_MERL(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('a',{'class':'thumbimgx'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] MerlHD[/COLOR]',vLink,25,vImage)	
### end ###
	
def EPISODE_MERL(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle)

############## khmerkomsan SITE ****************** 			   
def INDEX_CITY(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()      
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,185,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmerkomsan9.com/' + pageurl.encode("utf-8")),181,"")		 
         except:pass
		 
### search ##			
def SINDEX_CITY(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] KHMERKOMSAN[/COLOR]',vLink,185,vImage)			
##end ##		 

def EPISODE_CITY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 
		
############## KOLAPKHMER SITE ****************** 			 
def INDEX_KM168(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle.replace("&euro;&lsaquo;",""),vLink,215,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,211,"") 

### search ##			
def SINDEX_KOLAB(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle.replace("&euro;&lsaquo;","")+'[COLOR red] KOLABKHMER[/COLOR]',vLink,215,vImage)			
##end ##
			
def EPISODE_KM168(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
	if(len(match) > 0):      
		for vLink,vLinkName in match:                 
			addLink(vLinkName,vLink,4,'')
	else:
		soup = BeautifulSoup(link.decode('utf-8'))
		script = soup.body.p.findAll('script')[0]
		for data in script:
			link = dodge.resolver(data)
			vdata=re.compile('src=(.+?)>').findall(link.replace('\'','').replace('\"',''))[0]
			html = OpenURL(vdata)
			html2=re.compile('options.player_list = \[(.+?)\]; var player').findall(html.replace('\n',''))     
			for vid in html2:
				match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(vid)     
				if(len(match) > 0):      
					for vLink,vLinkName in match:                 
						addLink(vLinkName,vLink,4,'')		
		
############## ckh7 SITE ****************** 
def INDEX_CKH7(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,205,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.ckh7.com/' + pageurl.encode("utf-8")),201,"")		 
         except:pass	
		 
## SEARCH ##

def SINDEX_CKH7(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] CKH7[/COLOR]',vLink,205,vImage)
##END ##		 
						
def EPISODE_CKH7(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')		   		
		
		
############## 7Khmer SITE ****************** 
def INDEX_KHMOTION(url): 
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()    
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile("<a class='thumbimgx' href='(.+?)'.+?><img alt='(.+?)' class='.+? itemprop='image' src='(.+?)'").findall(link.replace('s72-c','s1600'))
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;",""),vurl,15,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir(pagenum.replace("Older Posts","Next Page").replace("Newer Posts","Prev Page"),pageurl,11,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)
		
###search ###		
def SINDEX_KHMOTION(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()      
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile("<a class='thumbimgx' href='(.+?)'.+?><img alt='(.+?)' class='.+? itemprop='image' src='(.+?)'").findall(link.replace('s72-c','s1600'))
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;","")+'[COLOR red] 7KHMER[/COLOR]',vurl,15,vimage)		
### end ###		
	
def EPISODE_KH(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle) 
	
def get_link(url, movie):
    if xbmcaddon.Addon(id='service.liveproxy'):
        command = 'streamlink --player-passthrough hls --http-header "Origin=%s" %s best' % (movie, url)
        return "http://127.0.0.1:53422/base64/%s" % base64.b64encode(command)
    else:
        header = {
            'Origin': movie('originUrl'),
            'User-Agent': "Chrome/59.0.3071.115 Safari/537.36",
            'Referrer': movie('originUrl')
        }

    return url + "|%s" % urlencode(header)	
		
############## drama4khmers SITE ****************** 			   
def INDEX_DRAMA4(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-sm-4 portfolio-item"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt'].replace("&euro;&lsaquo;","")
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,165,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.thekomsan.com/' + pageurl.encode("utf-8")),161,"")		 
         except:pass 
		 
### SEARCH ###
def SINDEX_KHDRAMA(url): 
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-sm-4 portfolio-item"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;","")+'[COLOR red] DRAMA4K[/COLOR]',vLink,165,vImage)		 
## END ##		 

def EPISODE_DRAMA4(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'')		      
	

############## phumi-thai9 SITE ****************** 		
def INDEX_K8MERHD(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"movie-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,55,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,51,"")
        except:pass 
				
def EPISODE_K8MERHD(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content"})
        for item in listcontent[0].findAll('div', {"class" :"movie-thumb"}):
			vname=item.a.img["alt"]
			vname = vname.encode("UTF-8",'replace')   
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        try:
			paging = soup('div',{'class':'pagination'})
			pages = BeautifulSoup(str(paging[0]))('a')
			for p in pages:
				psoup = BeautifulSoup(str(p))
				pageurl = psoup('a')[0]['href']
				pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir(" Page " + pagenum.encode("utf-8") ,pageurl,55,"")
        except:pass 			 

############## DRAMACOOL SITE ****************** 
def INDEX_WATCHASIAN(url):
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('</span>\s*<a href="(.+?)">(.+?)</a>').findall(newlink)
	for vlink,vname in match:
		addDir(vname,WATCHASIAN+vlink,85,'') 
		
def SINDEX_WATCHASIAN(url):
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('</span>\s*<a href="(.+?)">(.+?)</a>').findall(newlink)
	for vlink,vname in match:
		addDir(vname+'[COLOR red] DRAMACOOL[/COLOR]',WATCHASIAN+vlink,85,vimage)		
		
def	EPISODE_WATCHASIAN(url,name):
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	vImage=re.compile('<div class="img"><img src="(.+?)"').findall(link)[0]
	match=re.compile('<h3 class="title" onclick="window.location = \'(.+?)\'">\n                  (.+?)                </h3>').findall(link.replace('\t','')) 
	if(len(match) > 0):      
		for vLink,vName in reversed(match):                 
			addDir(vName,WATCHASIAN+vLink,86,vImage)
			
def HOST_WATCHASIAN(url,name):
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('Standard Server <span>(.+?)</ul></div>').findall(newlink)
	match=re.compile('rel=".+?" data-video="(.+?)">(.+?)').findall(match[0])
	addLink('[B][COLOR red]Please select link below:[/B][/COLOR]','','',DramaImage+'')
	for vurl,vname in match:
		addLink('[B][COLOR orange]%s[/B][/COLOR]'% vname,vurl.replace('//k-vid','https://k-vid'),4,'')


############## PhumiHD SITE ****************** 
def INDEX_PHUMIHD(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 		
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"thumb"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,95,vImage)
         try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,91,"")
         except:pass
				
## SEARCH ##
def SINDEX_PHUMIHD(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 		
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"thumb"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] PHUMIHD[/COLOR]',vLink,95,vImage)
## END ##			 
						
def EPISODE_PHUMIHD(url,name):
         html = OpenSoup(url)
         addLink(name,url,3,'')
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode("utf-8"))
         epis = soup('a',{"class":"related-post"})
         for link in epis:	 
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0].contents[2]
             addLink(vTitle,vLink,3,'')

############## video4khmer1 SITE ****************** 
def INDEX_VIDEO4U(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,105,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,101,"")
        except:pass

### SEARCH ##
def SINDEX_VIDEO4U(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle+'[COLOR red] VIDEO4U[/COLOR]',vLink,105,vImage)
## END ##		
     
def EPISODE_VIDEO4U(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content-center"})
        for item in listcontent[0].findAll('div', {"class" : "movie-thumb"}):
			vname=item.a.img["alt"]
			vname = vname.encode("UTF-8",'replace')   
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        for item in listcontent[0].findAll('li'):
             if(item.a!=None):
				pageurl=item.a["href"]
				pagenum=item.a.contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir("Page " + pagenum,pageurl,105,"")
    #except: pass
     #xbmcplugin.endOfDirectory(pluginhandle)
	 
def EPISODE4U(url,name):        
        link = OpenURL(url)
        match=re.compile('<div class=".+?"><div class="movie-thumb"><a href="(.+?)"><img src="(.+?)" alt=".+?" title="(.+?)" width="180" height="170"').findall(link)
        counter = 1
        #for url,name,thumbnail in match:
        if (len(match) >= 1):
           for vLink,Vimage,vLinkName in match:
               counter += 1
               addLink(vLinkName,vLink,3,Vimage)
        match5=re.compile('<div class="pagination">(.+?)</div>').findall(link)
        if(len(match5)):
           pages=re.compile('<a href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.encode("utf-8"),pageurl,105,"")     
           xbmcplugin.endOfDirectory(pluginhandle)

############## Phumikhmer.club SITE ****************** 	
def INDEX_PHUMIKHMER(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 		
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle,vLink,115,vImage)
        pages=re.compile("<a class='page-numbers' href='(.+?)'>(.+?)</a>").findall(html)
        for pageurl,pagenum in pages:
            addDir("[B][COLOR blue]Page %s[/B][/COLOR]"% pagenum.encode("utf-8"),pageurl,111,"")

### SEARCH ##
def SINDEX_PHUMIKHMER(url):     
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle+'[COLOR red] PHUMICLUB[/COLOR]',vLink,115,vImage)
## END ##			
			
def EPISODE_PHUMIKHMER(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	
		  
############## Phumikhmer.media SITE ****************** 	
def INDEX_PHUMIKHMER1(url):  
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle,vLink,225,vImage)
        pagecontent=soup.findAll('div', {"class" : re.compile("page-nav*")})
        if(len(pagecontent)>0):
            for item in pagecontent[0].findAll('a', {"class" : ["page", "last"]}):
				addDir("page " + item.contents[0],item["href"],221,"")

## SEARCH ##
def SINDEX_PHUMIKHMER1(url):  
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close() 
        html = OpenSoup(url)
        try:
            html =html.encode("UTF-8")
        except: pass
        #html = urllib2.urlopen(url).read()
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'td-module-thumb'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            addDir(vTitle+'[COLOR red] PHUMIMEDIA[/COLOR]',vLink,225,vImage)
## END ##			

def buildNextPage2(pagenum,label):
	pagecount=str((int(pagenum) - 1) * 18)
	url=PHUMIKHMER1+"feeds/posts/summary/?start-index="+pagecount+"&max-results=1&alt=json-in-script&callback=finddatepost"
	link = OpenURL(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('"published":\{"\$t":"(.+?)"\}').findall(link)
	print match
	if(len(match)>0):
		tsvalue=urllib.quote_plus(match[0][0:19]+match[0][23:29])
		newurl=PHUMIKHMER1+"search/label/"+label+"?updated-max="+tsvalue+"&max-results=18#PageNo="+pagenum
	else:
		newurl=""
	return newurl

def EPISODE_PHUMIKHMER1(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')			  
		  
############## Phumikhmer1 SITE ****************** 
def INDEX_PHUMIKHMER2(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"thumb-area thumb-outer latest-img"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;",""),vLink,235,vImage)			 
         pages=re.compile('<span class=\'pager-older-link\'>\n<a class=\'blog-pager-older-link btn\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE', pageurl,231,"")  


def EPISODE_PHUMIKHMER2(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'')	  
		    
		  

############## Merlkon and Mayura SITE ****************** 		  
def INDEX_MERLKON(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;",""),vLink,135,vImage)
        try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8"),pageurl,131,"")
        except:pass 

## search ##
def SINDEX_MERLKON(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;","")+'[COLOR red] MERLKON[/COLOR]',vLink,135,vImage)
			
def SINDEX_MAYURA(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle.replace("&#8217;","")+'[COLOR red] MAYURA[/COLOR]',vLink,135,vImage)			
## end ##		

def EPISODE_MERLKON(url,name):
        link = OpenURL(url)
        match=re.compile('<a href="(.+?)"><button type="button" class="btn btn-episode">(.+?)</button></a>').findall(link)     
        if(len(match) == 0):
          match=re.compile('<a href="(.+?)"><span style=".+?">(.+?)</span></a>').findall(link)
        for vLink, vLinkName in match:
            addLink(vLinkName,vLink,3,'')
        xbmcplugin.endOfDirectory(pluginhandle)		
		
############## Merl7 SITE ****************** 		  
def INDEX_MERL7(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()   
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumb-area thumb-outer latest-img"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,155,vImage)		  
         pages=re.compile('<span class=\'pager-older-link\'>\n<a class=\'blog-pager-older-link btn\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE',pageurl,151,"")                    

## SEARCH ##
def SINDEX_MERL7(url): 
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()    
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumb-area thumb-outer latest-img"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle+'[COLOR red] MERL7[/COLOR]',vLink,155,vImage)
## END ##			 

def EPISODE_MERL7(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	

############## END OF VIDEO SITE ****************** 		
		
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):              
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link.replace('=m37','=m18')) 
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):   
                            match=re.compile('playlist: "(.+?)"').findall(link)# Good Link
                            if(len(match) == 0):
                             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# KhmerTV
                             if(len(match) == 0):							
                              match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                              for url in match:
                               vid = url[0].replace("['']", "")       
                               match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                               #REAL_VIDEO_HOST(match)
                               VIDEO_HOSTING(match)
                               print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
    
def VIDEO_HOSTING(vlink):
           if 'khmotions.com' in vlink:   
                VideoURL = KHMOTIONS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Khmotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'kolabkhmer.club' in vlink:
                VideoURL = KOLABKHMERS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Kolabkhmer Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'dailymotion.com' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'estream.to' in vlink:   
                VideoURL = ESTREAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Estream Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'fembed.com' in vlink:
                VideoURL = FEMBED(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Fembed Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'gcloud.live' in vlink:
                 VideoURL = GCLOUD(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Gcloud Loading selected video)")
                 Play_VIDEO(VideoURL)					

           elif 'google.com' in vlink:   
                VideoURL = GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'k-vid.net' in vlink:   
                VideoURL = KVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,K-vid Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Mp4upload Loading selected video)")
                Play_VIDEO(VideoURL)				
		
           elif 'ok.ru' in vlink:
                VideoURL = OKRU(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,OK Loading selected video)")
                Play_VIDEO(VideoURL)	
				
           elif 'openload.co' in vlink:   
                VideoURL = OPENLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Openload Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'rapidvideo.com' in vlink:   
                VideoURL = RAPIDVIDEOCOM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Rapidvideo Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'streamango.com' in vlink:   
                VideoURL = STREAMANGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)		
				
           elif 'subkh.com' in vlink:   
                VideoURL = SUBKH(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Subkh Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'vev.io' in vlink:   
                VideoURL = VEVIO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vevio Loading selected video)")
                Play_VIDEO(VideoURL)				
     
           elif 'vimeo.com' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)
				 
           elif 'vidlox.me' in vlink:
                 VideoURL = VIDLOX(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vidlox Loading selected video)")
                 Play_VIDEO(VideoURL)	

           elif 'xstreamcdn.com' in vlink:
                 VideoURL = XSTREAMCDN(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,xStreamcdn Loading selected video)")
                 Play_VIDEO(VideoURL)	

           elif 'kshows.to' in vlink:
                 VideoURL = KSHOW(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,xStreamcdn Loading selected video)")
                 Play_VIDEO(VideoURL)				 

           elif 'youtube.com' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)        
       
           else:
                print 'VideoURL: %s' % vlink
                xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonJen is loading...)")
                Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)
	
def KHMOTIONS(SID):
	req = urllib2.Request(SID)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()    
	match720p = re.compile('file:\s"(.+?)",.+?720.+?"', re.DOTALL).findall(link)
	match480p = re.compile('file:\s"(.+?)",.+?480.+?"', re.DOTALL).findall(link)
	match360p = re.compile('file:\s"(.+?)",.+?360.+?"', re.DOTALL).findall(link)
	match240p = re.compile('file:\s"(.+?)",.+?240.+?"', re.DOTALL).findall(link)
	matchSD = re.compile('file : "(.+?)"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	elif matchSD:
		VideoURL = matchSD[0]
	return VideoURL			

def KOLABKHMERS(SID):
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        VideoURL =  re.compile('"file":"(.+?)"').findall(link.replace('\/','/'))[0]
        return VideoURL	

def DAILYMOTION(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def ESTREAM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL		

def FACEBOOK(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	

def FEMBED(Video_ID):
	media_id = re.compile("fembed.com/v/(.+)").findall(Video_ID)[0]
	SID = 'https://www.fembed.com/api/source/%s' % media_id
	link = requests.post(SID).content
	match720p = re.compile('"file":"(.+?)".+?"720p"', re.DOTALL).findall(link)
	match480p = re.compile('"file":"(.+?)".+?"480p"', re.DOTALL).findall(link)
	match360p = re.compile('"file":"(.+?)".+?"360p"', re.DOTALL).findall(link)
	match240p = re.compile('"file":"(.+?)".+?"240p"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	return VideoURL.replace('\/','/')
	
def GCLOUD(SID):
    headers = {
    "origin": "https://gcloud.live",
    "referer": SID,
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "x-requested-with": "XMLHttpRequest",
    "user-agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.52 Safari/536.5",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    }
    response = requests.post(url = 'https://gcloud.live/api/source/' + SID.split("/")[-1], headers = headers)
    metadata = response.json()
    url = metadata['data'][-1]['file']
    response = requests.get(url = url, allow_redirects=False)
    VideoURL = response.headers['Location']
    return VideoURL	

def GOOGLE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def KVID(SID):
		link = OpenURL(SID)
		URL=re.compile('window.location = "(.+?)"').findall(link)[0]
		VideoURL = resolveurl.resolve(URL)
		return VideoURL	

def MP4UPLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def OKRU(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def OPENLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL			

def RAPIDVIDEOCOM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def STREAMANGO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def SUBKH(SID):
	media_id = re.compile("id=(.+?)&").findall(SID)[0]
	headers = {'Referer': 'https://khmotionn.com','User-Agent': 'Mozilla/5.0 (Linux: Android 4.4.2: Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'}	
	link = requests.post(SID, headers=headers).content
	key = re.compile('key: "(.+?)",').findall(link)[0]
	data = {'key':key,'type':'slug','value':media_id,'dataType':'m3u8'}
	url2 = requests.post("https://multi.idocdn.com/vip",data=data).content
	vid = re.compile('"link":"(.+?)",').findall(url2)[0]
	orgin = 'https://subkh.com'
	VideoURL = get_link(vid, orgin)
	return VideoURL				

def VEVIO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL  		
		
def VIDLOX(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def VIMEO(Video_ID):
        pickle_in = open(dpath+"dict.pickle","rb")
        referer = pickle.load(pickle_in)
        Referer = (referer[1])
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            media_id =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              media_id =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
        SID = "https://player.vimeo.com/video/%s?api=1&amp;player_id=video_player" % media_id[0]  
        headers = {'Referer': Referer}
        link = requests.get(SID, headers=headers)
        VideoURL = re.compile('"hls"[^>]*"akfire_interconnect_quic":{"url":"(.+?)"').findall(link.content)[0]
        return VideoURL		
		
def XSTREAMCDN(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	
	
def KSHOW(SID):
	ID = 'https://kshows.to/'
	link = OpenURL(SID)
	VideoURL = re.compile("file: '(.+?)'").findall(link)[1]
	return(VideoURL+'|User-Agent=Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-G950U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/10.1 Chrome/71.0.3578.99 Mobile Safari/537.36&Referer=%s' % ID)			
	
def YOUTUBE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
###################### Resolver End  ###################        

def addLink(name,url,mode,iconimage):
### added download popup
        u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&title="+urllib.quote_plus(name)+"&thumb="+urllib.quote_plus(iconimage)
        ok = True
        contextMenuItems = []
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name})
        liz.setProperty('IsPlayable', 'true')
        contextMenuItems.append(('Download', 'XBMC.RunPlugin(plugin://plugin.video.khmerdl?url=%s&mode=%s&name=%s)'%(urllib.quote_plus(url),mode,urllib.quote_plus(name))))
        contextMenuItems.append(('Download Manager', 'XBMC.RunScript(script.module.youtube.dl)'))
        liz.addContextMenuItems(contextMenuItems)
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
        return ok		
###
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)     
elif mode==5:
        SEARCH()		
	
elif mode==11:
        INDEX_KHMOTION(url)    
elif mode==15:
        EPISODE_KH(url,name)
elif mode==21:
        INDEX_MERL(url)    
elif mode==25:
        EPISODE_MERL(url,name)		
elif mode==31:
        INDEX_KHREPLAY(url)    
elif mode==35:
        EPISODE_KHREPLAY(url,name)	
elif mode==51:
        INDEX_K8MERHD(url)    
elif mode==55:
        EPISODE_K8MERHD(url,name)	
elif mode==81:
        INDEX_WATCHASIAN(url)    
elif mode==85:
        EPISODE_WATCHASIAN(url,name)
elif mode==86:
        HOST_WATCHASIAN(url,name)		
elif mode==82:
        INDEX_AVERY(url)    
elif mode==83:
        EPISODE_AVERY(url,name)
elif mode==84:
        HOST_AVERY(url,name)		
elif mode==91:
        INDEX_PHUMIHD(url)    
elif mode==95:
        EPISODE_PHUMIHD(url,name)		
elif mode==101:
        INDEX_VIDEO4U(url)    
elif mode==105:
        EPISODE_VIDEO4U(url,name)
elif mode==111:
        INDEX_PHUMIKHMER(url)    
elif mode==115:
        EPISODE_PHUMIKHMER(url,name)		
elif mode==131:
        INDEX_MERLKON(url)    
elif mode==135:
        EPISODE_MERLKON(url,name)			
elif mode==151:
        INDEX_MERL7(url)    
elif mode==155:
        EPISODE_MERL7(url,name)	
elif mode==161:
        INDEX_DRAMA4(url)    
elif mode==165:
        EPISODE_DRAMA4(url,name)			
elif mode==181:
        INDEX_CITY(url)    
elif mode==185:
        EPISODE_CITY(url,name)
elif mode==201:
        INDEX_CKH7(url)    
elif mode==205:
        EPISODE_CKH7(url,name)
elif mode==211:
        INDEX_KM168(url)    
elif mode==215:
        EPISODE_KM168(url,name)			
elif mode==221:
        INDEX_PHUMIKHMER1(url)    
elif mode==225:
        EPISODE_PHUMIKHMER1(url,name)			
elif mode==231:
        INDEX_PHUMIKHMER2(url)    
elif mode==235:
        EPISODE_PHUMIKHMER2(url,name)		
			      
xbmcplugin.endOfDirectory(int(sysarg))