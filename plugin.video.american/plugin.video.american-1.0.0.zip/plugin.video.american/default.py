# ── Standard Library ────────────────────────────────────────────
import sys
import os
import re
import json
import time
import base64
import urllib.parse
from urllib.parse import quote_plus, unquote_plus, urljoin
from html import unescape as html_unescape

# ── Third-Party Libraries ───────────────────────────────────────
import requests
import resolveurl
from bs4 import BeautifulSoup

# ── Kodi Modules ────────────────────────────────────────────────
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ── Logging Helper ──────────────────────────────────────────────
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

# ── Global Cache ────────────────────────────────────────────────
ABOUT_SHOWN_CACHE = {}  # prevent repeated "About" dialogs

# ── Add-on Constants ────────────────────────────────────────────
ADDON_ID = 'plugin.video.american'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])


# ── Constants ──────────────────────────────────────────────────
BASE_URL = "https://serialgo.tv"

# ── User Agent ─────────────────────────────────────────────────
USER_AGENT = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

# ── Request Headers ────────────────────────────────────────────
HEADERS = {
    "User-Agent": USER_AGENT,
    "X-Requested-With": "XMLHttpRequest",
    "Referer": BASE_URL,
}

# ── Icons and Fanart ────────────────────────────────────────────
IMAGE_PATH     = os.path.join(ADDON_PATH, 'resources', 'images')
ICON_JOLCHET   = os.path.join(IMAGE_PATH, 'icon.png')
ICON_SEARCH    = os.path.join(IMAGE_PATH, 'search1.png')
FANART         = os.path.join(IMAGE_PATH, 'fanart.jpg')

# ── Utility Functions ───────────────────────────────────────────
def OpenURL(url, timeout=10, retries=3, delay=2, headers=None, as_text=False):
    final_headers = {'User-Agent': USER_AGENT}
    if headers:
        final_headers.update(headers)
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, headers=final_headers, timeout=timeout)
            response.raise_for_status()
            return response.text if as_text else response.content
        except Exception as e:
            if attempt >= retries:
                raise e
            time.sleep(delay)
            
headers = {
  'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
  'sec-ch-ua-platform': "\"Windows\"",
  'x-requested-with': "XMLHttpRequest",
  'sec-ch-ua': "\"Chromium\";v=\"140\", \"Not=A?Brand\";v=\"24\", \"Google Chrome\";v=\"140\"",
  'sec-ch-ua-mobile': "?0",
  'sec-fetch-site': "same-origin",
  'sec-fetch-mode': "cors",
  'sec-fetch-dest': "empty",
  'referer': "https://serialgo.tv/",
  'accept-language': "en-US,en;q=0.9,pt;q=0.8",
  'priority': "u=1, i"
  }
  
def URL(url):
    response = requests.get(url,headers=headers).text
    return response

def OpenSoup(url, return_html=False, **kwargs):
    html = OpenURL(url, as_text=True, **kwargs)
    if not html:
        raise Exception(f"Empty or failed response from URL: {url}")
    soup = BeautifulSoup(html, "html.parser")
    return (soup, html) if return_html else soup

def GetInput(message, heading, is_hidden=False):
    keyboard = xbmc.Keyboard('', message, is_hidden)
    keyboard.setHeading(heading)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ""
   
def show_description_once(title, description):
    if title in ABOUT_SHOWN_CACHE:
        return
    ABOUT_SHOWN_CACHE[title] = True
    xbmcgui.Dialog().textviewer(title, description)

# ── Main Menu ───────────────────────────────────────────────────
def HOME():
    addDir("New Movies", urljoin(BASE_URL, "/filter?type=movie&quality=all&release_year=all&genre=all&country=all"), "index_serialgo")
    addDir("New TV Shows", urljoin(BASE_URL, "/filter?type=tv&quality=all&release_year=all&genre=all&country=all"), "index_serialgo")
    addDir("Movies", urljoin(BASE_URL, "/movie"), "index_serialgo")
    addDir("TV Shows", urljoin(BASE_URL, "/tv-show"), "index_serialgo")
    addDir("Genre", "", "genre_menu")
    addDir("Country", "", "country_menu")
    addDir("Search", "", "search_serialgo")

# ── Genre Menu ──────────────────────────────────────────────────
def GENRE_MENU():
    try:
        soup = OpenSoup(BASE_URL)

        seen = {}
        for a in soup.find_all("a", href=True):
            href = a["href"]
            title = a.get_text(strip=True)
            if "/genre/" in href and title:
                seen[href] = title  # use dict to avoid duplicates

        # sort alphabetically by title
        for href, title in sorted(seen.items(), key=lambda x: x[1].lower()):
            xbmc.log(f"[{ADDON_ID}] GENRE found: {title} → {href}", xbmc.LOGINFO)
            addDir(title, urljoin(BASE_URL, href), "index_serialgo")

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] GENRE_MENU scrape failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to load Genres", xbmcgui.NOTIFICATION_ERROR)

# ── Country Menu ────────────────────────────────────────────────
def COUNTRY_MENU():
    try:
        soup = OpenSoup(BASE_URL)

        seen = {}
        for a in soup.find_all("a", href=True):
            href = a["href"]
            title = a.get_text(strip=True)
            if "/country/" in href and title:
                seen[href] = title  # avoid duplicates

        # --- Add country manually if missing ---
        if "/country/PH" not in seen:
            seen["/country/PH"] = "Philippines"

        # sort alphabetically by title
        for href, title in sorted(seen.items(), key=lambda x: x[1].lower()):
            xbmc.log(f"[{ADDON_ID}] COUNTRY found: {title} → {href}", xbmc.LOGINFO)
            addDir(title, urljoin(BASE_URL, href), "index_serialgo")

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] COUNTRY_MENU scrape failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Failed to load Countries", xbmcgui.NOTIFICATION_ERROR)


# ── Listing Handler ─────────────────────────────────────────────
def INDEX_SERIALGO(url):
    try:
        xbmc.log(f"[{ADDON_ID}] Fetching index: {url}", xbmc.LOGINFO)
        html = OpenURL(url, as_text=True)
        soup = BeautifulSoup(html, 'html.parser')
        items = soup.select('.flw-item')

        if not items:
            raise Exception("No items found on page.")

        for item in items:
            title_tag = item.select_one('.film-name a')
            img_tag = item.select_one('img')
            year_tag = item.select_one('.fdi-item')
            quality_tag = item.select_one('.film-poster-quality')
            type_tag = item.select_one('.fdi-type')

            if not title_tag or not img_tag:
                continue

            link = title_tag.get('href', '')
            title = title_tag.get_text(strip=True)
            year = year_tag.get_text(strip=True) if year_tag else ''
            quality = quality_tag.get_text(strip=True) if quality_tag else ''
            media_type = type_tag.get_text(strip=True) if type_tag else ''

            extras = " ".join([f"[{x}]" for x in (year, quality, media_type) if x])
            display_title = f"{title} {extras}" if extras else title

            image = img_tag.get('data-src') or img_tag.get('src') or ''
            html=URL("https://serialgo.tv"+link)

            if 'data-type="1"' in html:
                vid = re.compile("movies-free-(.+)").findall(link)[0]
                sid = "https://serialgo.tv/ajax/episode/list/"+str(vid)
                addDir(display_title, sid, "playloop", iconimage=image, description=link)
            elif 'data-type="2"' in html:
                vid = re.compile("movies-free-(.+)").findall(link)[0]
                sid = "https://serialgo.tv/ajax/season/list/"+str(vid)
                addDir(display_title, sid, "season", iconimage=image, description=link)

        # ── Pagination ─────────────────────────────
        parsed = urllib.parse.urlparse(url)
        query = dict(urllib.parse.parse_qsl(parsed.query))
        current_page = int(query.get('page', '1'))

        def build_page_url(page_num):
            query['page'] = str(page_num)
            return urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(query)))

        if current_page > 1:
            addDir("< Previous Page", build_page_url(current_page - 1), "index_serialgo")

        addDir("Next Page >", build_page_url(current_page + 1), "index_serialgo")

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] INDEX_SERIALGO error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)


# ── Search Handler ──────────────────────────────────────────────
def SEARCH_SERIALGO():
    search_text = GetInput("Enter Search Text", "Search SerialGo")
    if not search_text:
        return

    try:
        search_url = urljoin(BASE_URL, f"/search/{quote_plus(search_text)}")
        INDEX_SERIALGO(search_url)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[{ADDON_ID}] Search failed: {e}", xbmc.LOGERROR)


def SEASON(url, name):
    desc_url = params.get("desc", "")
    if desc_url and name not in ABOUT_SHOWN_CACHE:
        html = URL("https://serialgo.tv" + desc_url if desc_url.startswith("/") else desc_url)
        desc_tag = BeautifulSoup(html, "html.parser").select_one(".description")
        description = desc_tag.get_text(strip=True) if desc_tag else ""
        if description:
            show_description_once(name, description)   
    link = OpenURL(url)
    soup = BeautifulSoup(link, 'html.parser')
    div_index = soup('div',{'class':"dropdown-menu dropdown-menu-new"})
    for link in div_index:
        vLink = link("a")[0]["data-id"]
        vTitle = link('a')[0].text
        addDir(vTitle,'https://serialgo.tv/ajax/season/episodes/'+vLink, "episode")


def EPISODE(url, name):
    link = OpenURL(url)
    soup = BeautifulSoup(link, 'html.parser')
    div_index = soup('li',{'class':"nav-item"})
    print(div_index)
    for link in div_index:
        vLink = link("a")[0]["data-id"]
        vTitle = link('a')[0].text
        addDir(vTitle, "https://serialgo.tv/ajax/episode/servers/"+vLink, "server")
        
def SERVER(url,name):
    link = OpenURL(url)
    soup = BeautifulSoup(link, 'html.parser')
    print(soup)
    div_index = soup('li',{'class':"nav-item"})
    for link in div_index:
        vLink = link("a")[0]["data-id"]
        vTitle = link('a')[0].text
        addLink(vTitle, "http://dodge.eu5.org/go/?url=https://serialgo.tv/ajax/episode/sources/"+vLink, "play_server")
        
def PLAYLOOP(url, name):
    desc_url = params.get("desc", "")
    if desc_url and name not in ABOUT_SHOWN_CACHE:
        html = URL("https://serialgo.tv" + desc_url if desc_url.startswith("/") else desc_url)
        desc_tag = BeautifulSoup(html, "html.parser").select_one(".description")
        description = desc_tag.get_text(strip=True) if desc_tag else ""
        if description:
            show_description_once(name, description)
    link = OpenURL(url)
    soup = BeautifulSoup(link, 'html.parser')
    div_index = soup('li',{'class':"nav-item"})
    for link in div_index:
        vLink = link("a")[0]["data-linkid"]
        vTitle = link('a')[0]['title']
        addLink(vTitle, "http://dodge.eu5.org/go/?url=https://serialgo.tv/ajax/episode/sources/"+vLink, "play_server")


def PLAY_SERVER(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'}
    link = OpenURL(url)
    Video = re.compile('</form>(.+)').findall(link.decode("utf-8"))[0]
    Play_VIDEO(Video)


def Play_VIDEO( VideoURL):
    print ('PLAY VIDEO: %s' % VideoURL)   
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)
		

def addLink(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    li = xbmcgui.ListItem(label=name)
    li.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    li.getVideoInfoTag().setTitle(name)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)


def addDir(name, url, action, iconimage="", description=""):
    u = f"{sys.argv[0]}?url={quote_plus(str(url))}&action={quote_plus(str(action))}&name={quote_plus(str(name))}&desc={quote_plus(description)}"
    li = xbmcgui.ListItem(label=name)
    if iconimage:
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'poster': iconimage})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)


def get_params():
    param = {}
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else sys.argv[2]
    for pair in paramstring.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            param[key] = unquote_plus(value)
    return param

# ----- Parameter Parsing -----
params = get_params()
url    = urllib.parse.unquote_plus(params.get("url", ""))
name   = params.get("name", "")
action = params.get("action", "home")  # Default to 'home' if not specified

# ----- Routing -----
ROUTES = {
    "home":            lambda: HOME(),
    "genre_menu":      lambda: GENRE_MENU(),
    "country_menu":    lambda: COUNTRY_MENU(),
    "index_serialgo":  lambda: INDEX_SERIALGO(url),
    "search_serialgo": lambda: SEARCH_SERIALGO(),
    "playloop":        lambda: PLAYLOOP(url, name), 
    "season":          lambda: SEASON(url, name), 
    "episode":         lambda: EPISODE(url, name), 
    "server":          lambda: SERVER(url,name),
    "play_server":     lambda: PLAY_SERVER(url),
}


# ----- Execute Action -----
ROUTES.get(action, lambda: HOME())()

# ----- End of Directory -----
xbmcplugin.endOfDirectory(PLUGIN_HANDLE)