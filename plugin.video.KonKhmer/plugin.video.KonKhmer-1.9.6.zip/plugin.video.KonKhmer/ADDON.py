import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
import urlresolver

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonKhmer')
addon_name = 'plugin.video.KonKhmer'

# Khmer TV
FILM4KH ='http://hd.khmertv.xyz/api-tv/get-tv-v1'
data = 'name=tntdev.com.khmertv'
ID = 'http://hd.khmertv.xyz//api-tv/get-url-v1?id='
# End 

Chan7 ='http://mvkhmer.com/'
VIDEO4U ='http://www.video4khmer19.com/'
KHMOTION ='https://www.khmotion.com/'
KHMERKOM ='http://www.khmerkomsan.co/'
KHDRAMA ='http://www.khmer-drama.com/'
MVKHMERS = 'https://www.kolabkhmer.cf/'


USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')
songImage = os.path.join(ADDON_PATH, 'resources', 'images','song.jpg')
videoImage = os.path.join(ADDON_PATH, 'resources', 'images','video.jpg')
tvImage = os.path.join(ADDON_PATH, 'resources', 'images','tv.png')

# KhmerTV
def OpenURLS(url):
	cj = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	opener.addheaders = [('Content-Type','application/x-www-form-urlencoded'),
		('User-Agent', 'Dalvik/2.1.0 (Linux; U; Android 7.0; SM-G955F Build/NRD90M)'),
		('Host','hd.khmertv.xyz'),
		('Connection','keep-alive'),
		('Accept-Encoding','gzip'),
		('Content-Length','23')]
	usock = opener.open(url,data)
	if usock.info().get('Content-Encoding') == 'gzip':
		buf = StringIO.StringIO(usock.read())
		f = gzip.GzipFile(fileobj=buf)
		response = f.read()
	else:
		response = usock.read()
	usock.close()
	return (response)
# End


def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response

	 
def HOME():
		addDir('Khmer TV',FILM4KH,31,tvImage+'')  
		addDir('Music Video',Chan7+'video-clip',171,videoImage+'')
		addDir('Music Album',Chan7,172,songImage+'')
		addDir('Khmotion',KHMOTION+'search/label/Khmer%20drama?&max-results=20',11,'http://1.bp.blogspot.com/-eYngwVMs7wk/VbIiF42BlDI/AAAAAAAAMpc/APh97n98Vy4/s1600/7khmer%2Blogo.png')
		addDir('KhmerDrama',KHDRAMA+'category.php?cat=khmer-drama',21,'http://www.khmer-drama.com/templates/default/img/khmer-drama.png')
		addDir('KhmerKomsan',KHMERKOM+'category.php?cat=khmer-collection-dubbed',81,'http://www.khmerkomsan.co/templates/default/img/KhmerKomsan.png')	
		addDir('KolabKhmer',MVKHMERS+'search/label/KHMER?&max-results=20',41,'https://2.bp.blogspot.com/-Fs1Xu7DJ20k/WojR-gsNIOI/AAAAAAAAOgQ/xGXdg-jUr0YAfbRCvLj_q2P5a_SqXmTWgCK4BGAYYCw/s1600/kolabkhmer%2Blogo%2B1.png')			
		addDir('VideoKhmer',VIDEO4U+'khmer-movie-category/khmer-drama-watch-online-free-catalogue-504-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')
		addDir('Video4Khmer',VIDEO4U+'khmer-movie-category/khmer-movies-watch-online-free-catalogue-503-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')

		xbmcplugin.endOfDirectory(pluginhandle)

############## KOLABKHMER SITE ******************	
def INDEX_KOLAB(url):
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            #print vImage.encode("UTF-8")
            addDir(vTitle,vLink,45,vImage)
        label="" #re.compile("/label/(.+?)\?").findall(url)[0]
        print label
        pagenum=re.compile("PageNo=(.+?)").findall(url)
        print pagenum
        prev="0"
        if(len(pagenum)>0):
              prev=str(int(pagenum[0])-1)
              pagenum=str(int(pagenum[0])+1)

        else:
              pagenum="2"
        nexurl=buildNextPage(pagenum,label)

        if(int(pagenum)>2 and prev=="1"):
              urlhome=url.split("?")[0]+"?"
              addDir("[B][COLOR blue]<< Back Page >>[/B][/COLOR]",urlhome,41,"")
        elif(int(pagenum)>2):
              addDir("[B][COLOR blue]<< Back Page >>[/B][/COLOR]",buildNextPage(prev,label),41,"")
        if(nexurl!=""):
              addDir("[B][COLOR green]<< Next Page >>[/B][/COLOR]",nexurl,41,"")

        xbmcplugin.endOfDirectory(pluginhandle)	

def buildNextPage(pagenum,label):
	pagecount=str((int(pagenum) - 1) * 18)
	url=MVKHMERS+"feeds/posts/summary?start-index="+pagecount+"&max-results=1&alt=json-in-script&callback=finddatepost"
	link = OpenSoup(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('"published":\{"\$t":"(.+?)"\}').findall(link)
	if(len(match)>0):
		tsvalue=urllib.quote_plus(match[0][0:19]+match[0][23:29])
		newurl=MVKHMERS+"search/label/"+label+"?updated-max="+tsvalue+"&max-results=18#PageNo="+pagenum
	else:
		newurl=""
	return newurl
			
def EPISODE_KOLAP(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')			
		
		
		
		
############## KhmerTV *******************
def INDEX_FILM2US(url):
        link = OpenURLS(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<id><!\[CDATA\[(.*?)\]\]></id>\s*<title><!\[CDATA\[(.*?)\]\]></title>\s*<imageurl><!\[CDATA\[(.*?)\]\]></imageurl>').findall(link)
        for vurl,vname,vimage in match:
            addLink(vname,(ID+vurl),4,vimage)		
		
		
############## 7Khmer SITE ****************** 
def INDEX_KHMOTION(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' itemprop=\'name headline\'>\n<a href=\'(.+?)\' itemprop=\'url\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname,vurl,15,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir("[B][COLOR blue]<<<%s>>>[/B][/COLOR]"% pagenum,pageurl,11,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)
	
def EPISODE_KH(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')  
		
	
############## KhmerDrama SITE ****************** 	
def INDEX_KHDRAMA(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"heading"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,25,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmer-drama.com/' + pageurl.encode("utf-8")),21,"")		 
         except:pass				    

def EPISODE_KHD(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	    
	 

############## Khmerkomsan24 SITE ****************** 
def INDEX_KHMERKOMSAN(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,85,vImage)
        pages=re.compile('<li class="">\r\n\s*<a href="(.+?)">&raquo;</a>').findall(html)
        if(len(pages)):
          for pageurl in pages:
              addDir("[B][COLOR blue]<< Next Page >>[/B][/COLOR]",('http://www.khmerkomsan.co/' + pageurl.encode("utf-8")),81,"")
			    
def EPISODE_KHMERKOMSAN(url,name):    
        link = OpenURL(url)        
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
             addLink(vLinkName,vLink,4,'')
        else: 
         match=re.compile('[^>]*{"idGD":\s*"([^"]+?)"').findall(link)
         print 'MATCHIFRAM: %s' % match
         if(len(match) > 0):
           EPlink = match[0].replace("0!?^0!?A"," ")       
           match = EPlink.split(' ')   
           counter = 0      
           for vLink in match:
               counter += 1 
               addLink(name.encode("utf-8") + " part " + str(counter), 'https://docs.google.com/file/d/%s' % vLink,4,'')
         else:
           match=re.compile('<div id="Playerholder">\r\n\t\t\t<iframe [^>]*src="([^"]+?)"').findall(link)
           print 'MATCHPLAY: %s' % match
           if(len(match) > 0):      
            for vLink in match:
              addLink(name.encode("utf-8"),vLink,4,'')		  

############## MVKHMER SITE ****************** 			 
def INDEX_CHAN7(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<a href="(.+?)" target="_parent" data-transition="slide">\s*<img src="(.+?)" class="ui-li-thumb" alt="(.+?)"').findall(link)
        for vurl,vimage,vname in match:
            addLink(vname,vurl,3,vimage)
        pages=re.compile('<span style="padding:4px 10px;text-align:center;border:1px solid #d9d9d9;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;font-size:12px;margin-right:2px;font-weight:bold; line-height:20px;"><a href="(.+?)">(.+?)</a>').findall(link)
        for pageurl,pagenum in pages:
            addDir("[B][COLOR blue]Page %s[/B][/COLOR]"% pagenum.encode("utf-8"),pageurl,171,"")
			
def CDVCD(url):
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<a href="(.+?)" target="_parent" data-transition="slide">\s*<img src="(.+?)" class="ui-li-thumb" alt="(.+?)"').findall(link)
        for vurl,vimage,vname in match:
            addDir(vname,vurl,173,vimage)
        pages=re.compile('<span style="padding:4px 10px;text-align:center;border:1px solid #d9d9d9;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;font-size:12px;margin-right:2px;font-weight:bold; line-height:20px;"><a href="(.+?)">(.+?)</a>').findall(link)
        for pageurl,pagenum in pages:
            addDir("[B][COLOR blue]Page %s[/B][/COLOR]"% pagenum.encode("utf-8"),pageurl,172,"")			
		  
def EPISODE_CHAN7(url,name):    
        link = OpenURL(url)
        URL=re.compile('playlist: "(.+?)",').findall(link)[0]
        req = urllib2.Request(URL)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        rss=response.read()
        response.close()               
        match=re.compile('<!\[CDATA\[(.*?)\]\]></title>\s*<description>\s*<!\[CDATA\[.*?\]\]>\s*</description>\s*<jwplayer:file>\n*<!\[CDATA\[(.*?)\]\]>').findall(rss)
        for vname,vurl in match:
             addLink(vname.replace("&nbsp;"," "),vurl.replace(" ","%20"),4,'')	


############## video4khmer1 SITE ****************** 
def INDEX_VIDEO4U(url):
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,105,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,101,"")
        except:pass
     #except: pass
     #xbmcplugin.endOfDirectory(pluginhandle)   
     
def EPISODE_VIDEO4U(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content-center"})
        for item in listcontent[0].findAll('div', {"class" : "movie-thumb"}):
			vname=item.a.img["alt"]
			vname = vname.encode("UTF-8",'replace')   
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        for item in listcontent[0].findAll('li'):
             if(item.a!=None):
				pageurl=item.a["href"]
				pagenum=item.a.contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir("Page " + pagenum,pageurl,105,"")
    #except: pass
     #xbmcplugin.endOfDirectory(pluginhandle)
	 
def EPISODE4U(url,name):        
        link = OpenURL(url)
        match=re.compile('<div class=".+?"><div class="movie-thumb"><a href="(.+?)"><img src="(.+?)" alt=".+?" title="(.+?)" width="180" height="170"').findall(link)
        counter = 1
        #for url,name,thumbnail in match:
        if (len(match) >= 1):
           for vLink,Vimage,vLinkName in match:
               counter += 1
               addLink(vLinkName,vLink,3,Vimage)
        match5=re.compile('<div class="pagination">(.+?)</div>').findall(link)
        if(len(match5)):
           pages=re.compile('<a href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.encode("utf-8"),pageurl,105,"")     
           xbmcplugin.endOfDirectory(pluginhandle)



############## END OF VIDEO SITE ****************** 		
		
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):              
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link)
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):   
                            match=re.compile('playlist: "(.+?)"').findall(link)# Good Link
                            if(len(match) == 0):
                             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# KhmerTV
                             if(len(match) == 0):							
                              match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                              for url in match:
                               vid = url[0].replace("['']", "")       
                               match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                               #REAL_VIDEO_HOST(match)
                               VIDEO_HOSTING(match)
                               print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
   
def VIDEO_HOSTING(vlink):          
           if 'dailymotion' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'hd.khmertv.xyz' in vlink:   
                VideoURL = KHMERTVHD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'mvkhmer.com/song' in vlink:   
                VideoURL = MVKHMER2(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'media.mvkhmer.com' in vlink:   
                VideoURL = MediaMVKhmer(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'google.com' in vlink:   
                VideoURL = DOCS_GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'vimeo' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)

           elif 'vid.me' in vlink:                   
                VideoURL = VIDDME(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vid.me Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'sendvid.com' in vlink:
                VideoURL = SENDVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sendvid Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'viddme' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Viddme Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'az665436' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,AZ Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'd1wst0behutosd' in vlink:
                #link = OpenURL(vlink)   
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,d1wst0behutosd Loading selected video)")
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
           #     Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,MP4UPLOAD Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'videobam' in vlink:  
                VideoURL = VIDEOBAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Videobam Loading selected video)")                                
                Play_VIDEO(VideoURL)     

           elif 'sharevids.net' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sharevids Loading selected video)")
                Play_VIDEO(VideoURL)   
                    # d = xbmcgui.Dialog()
                    # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')     
					
           elif 'videos4share.com' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,videos4share Loading selected video)")
                #Play_VIDEO(VideoURL)
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
				
           elif 'youtu.be' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")            
                Play_VIDEO(VideoURL)     

           elif 'youtube' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)
           else:
                #if 'grayshare.net' in vlink:
                if 'share.net' in vlink:    
                    VideoURL = vlink
                    print 'VideoURL: %s' % VideoURL
                    Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))    
                      # d = xbmcgui.Dialog()
                      # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')                
               
                else:
                    print 'VideoURL: %s' % vlink
                    xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonKhmer is loading...)")
                    Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                    #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                    #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)	

def DAILYMOTION(SID):
        match=re.compile('(dailymotion\.com\/(watch\?(.*&)?v=|(embed|v|user|video)\/))([^\?&"\'>]+)').findall(SID)                
        SID = match[0][len(match[0])-1]
        VideoURL = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' +SID
        return VideoURL

def KHMERTVHD(Video_ID):
       link = OpenURLS(url)
       VideoURL=re.compile("<!\[CDATA\[(.*?)\]\]></tvurl>").findall(link)[0]
       return VideoURL			
		
def MediaMVKhmer(Video_ID):
        VideoURL = url
        return VideoURL

def MVKHMER2(Video_ID):
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('file="(.+?)"').findall(link)               
        for URL in match:
         VideoURL = URL.replace(" ","%20")
        return VideoURL 		
		
def DOCS_GOOGLE(Video_ID):
                docid=re.compile('/d/(.+?)/preview').findall(Video_ID)[0]
                cj = cookielib.LWPCookieJar()
                (cj,vidcontent) = GetContent2("https://docs.google.com/get_video_info?docid="+docid,"", cj) 
                html = urllib2.unquote(vidcontent)
                cookiestr=""
                for cookie in cj:
					cookiestr += '%s=%s;' % (cookie.name, cookie.value)
                try:
					html=html.encode("utf-8","ignore")
                except: pass
                stream_map = re.compile('fmt_stream_map=(.+?)&fmt_list').findall(html)
                if(len(stream_map) > 0):
					formatArray = stream_map[0].replace("\/", "/").split(',')
					for formatContent in formatArray:
						 formatContentInfo = formatContent.split('|')
						 qual = formatContentInfo[0]
						 vidlink = (formatContentInfo[1]).decode('unicode-escape')

                else:
						cj = cookielib.LWPCookieJar()
						newlink1="https://docs.google.com/uc?export=download&id="+docid  
						(cj,vidcontent) = GetContent2(newlink1,newlink, cj)
						soup = BeautifulSoup(vidcontent)
						downloadlink=soup.findAll('a', {"id" : "uc-download-link"})[0]
						newlink2 ="https://docs.google.com" + downloadlink["href"]
						vidlink=GetDirVideoUrl(newlink2,cj) 
                VideoURL = (vidlink+ ('|Cookie=%s' % cookiestr))
                return  VideoURL

def FACEBOOK (SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()
       vlink = 'http://www.facebook.com/video/video.php?v=' + str(link)
       #vlink = re.compile('"params","([\w\%\-\.\\\]+)').findall(link)[0]
       html = urllib.unquote(vlink.replace('\u0025', '%')).decode('utf-8')
       html = html.replace('\\', '')
       videoUrl = re.compile('(?:hd_src|sd_src)\":\"([\w\-\.\_\/\&\=\:\?]+)').findall(html)
       if len(videoUrl) > 0:    
           VideoURL =  videoUrl[0]
       else:
           VideoURL =  videoUrl
       return  VideoURL  

def MP4UPLOAD(SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()    
       VideoURL=re.compile('\'file\': \'(.+?)\'').findall(link)[0]
       return VideoURL

def SENDVID(SID):
        #Video_ID = urllib.unquote_plus(SID).replace("//", "http://")
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match = re.compile('<source src="([^"]+?)"').findall(link)
        #match = re.compile('<meta property="og:video:secure_url" content="([^"]+?)"').findall(link)
        #VideoURL = (match[0]).decode("utf-8")
        VideoURL =  urllib2.unquote(match[0]).replace("//", "http://")
        return VideoURL

def VIDDME(Video_ID):
        SID=re.compile('vid.me/e/(.+)').findall(Video_ID)[0]
        URL = "https://vid.me/e/"+str(SID)
        VideoURL = media_url = urlresolver.resolve(URL)
        return VideoURL    

def VIDEOBAM(Video_ID):        
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('"url"\s*:\s*"(.+?)","').findall(link)               
        for URL in match:
            if(URL.find("mp4") > -1):
               VideoURL = URL.replace("\\","")
        return VideoURL       

def VIMEO(Video_ID):
        SID=re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID)[0]
        VideoURL = 'plugin://plugin.video.vimeo/play/?video_id=' +SID
        return VideoURL
		
def VIMEO1(Video_ID):
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            vlink =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              vlink =re.compile("//vimeo.com/(.+?)\?").findall(Video_ID+'?')
        #result = common.fetchPage({"link": "http://player.vimeo.com/video/%s/config?type=moogaloop&referrer=&player_url=player.vimeo.com&v=1.0.0&cdn_url=http://a.vimeocdn.com" % vlink[0],"refering": HomeURL})
        result = common.fetchPage({"link": "http://player.vimeo.com/video/%s?title=0&byline=0&portrait=0" % vlink[0],"refering": HomeURL})        
        print 'Result: %s' % result
        collection = {}
        if result["status"] == 200:
            html = result["content"]
            html = html[html.find('={"cdn_url"')+1:]
            html = html[:html.find('}};')]+"}}"
            #print html
            collection = json.loads(html)
            print 'Collection: %s' %collection
            #codec = collection["request"]["files"]["codecs"][0]
            #print codec            
            video = collection["request"]["files"]["progressive"]#[0]
            #isHD = collection["request"]["files"][video]
            print 'VideoCOLL1: %s' % video
            if(len(video) > 2):
            #if video.get("720p"):
                VideoURL = video[2]['url']
                print 'VideoSD: %s' % VideoURL
            #elif(len(video) > 1):
            #    VideoURL = video[1]['url']
            #    print 'VideoSD: %s' % VideoURL
            else: 
               VideoURL = video[0]['url']
               print 'VideoLD: %s' % VideoURL
        return VideoURL
		
def YOUTUBE(SID):
        match=re.compile('(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)').findall(SID)
        if(len(match) > 0):
             URL = match[0][len(match[0])-1].replace('v/','')
        else:   
             match = re.compile('([^\?&"\'>]+)').findall(SID)
             URL = match[1].replace('v=','')
        VideoURL = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' +URL.replace('?','')     
        return VideoURL
###################### Resolver End  ###################        

def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)        
	
elif mode==11:
        INDEX_KHMOTION(url)    
elif mode==15:
        EPISODE_KH(url,name)
elif mode==21:
        INDEX_KHDRAMA(url)    
elif mode==25:
        EPISODE_KHD(url,name)		
elif mode==31:
        INDEX_FILM2US(url)    
elif mode==35:
        EPISODE_FILM2US(url,name)			
elif mode==41:
        INDEX_KOLAB(url)    
elif mode==45:
        EPISODE_KOLAP(url,name)			
elif mode==51:
        INDEX_K8MERHD(url)    
elif mode==55:
        EPISODE_K8MERHD(url,name)			
elif mode==61:
        INDEX_KHMER4F(url)    
elif mode==65:
        EPISODE_KHMER4F(url,name)	
elif mode==71:
        INDEX_PHUMKOM(url)    
elif mode==75:
        EPISODE_PHUMKOM(url,name)	
elif mode==81:
        INDEX_KHMERKOMSAN(url)    
elif mode==85:
        EPISODE_KHMERKOMSAN(url,name)			
elif mode==91:
        INDEX_PHUMIHD(url)    
elif mode==95:
        EPISODE_PHUMIHD(url,name)		
elif mode==101:
        INDEX_VIDEO4U(url)    
elif mode==105:
        EPISODE_VIDEO4U(url,name)			
elif mode==111:
        INDEX_PHUMIKHMER(url)    
elif mode==115:
        EPISODE_PHUMIKHMER(url,name)
elif mode==121:
        INDEX_LAKHOAN(url)    
elif mode==125:
        EPISODE_LAKHOAN(url,name)
elif mode==131:
        INDEX_MERLKON(url)    
elif mode==135:
        EPISODE_MERLKON(url,name)
elif mode==141:
        INDEX_TUBE(url)    
elif mode==145:
        EPISODE_TUBE(url,name)		
elif mode==151:
        INDEX_MERL7(url)    
elif mode==155:
        EPISODE_MERL7(url,name)		
elif mode==161:
        INDEX_DRAMA4(url)    
elif mode==165:
        EPISODE_DRAMA4(url,name)	
elif mode==171:
        INDEX_CHAN7(url) 
elif mode==172:
        CDVCD(url)		
elif mode==173:
        EPISODE_CHAN7(url,name)		
elif mode==181:
        INDEX_CITY(url)    
elif mode==185:
        EPISODE_CITY(url,name)
elif mode==191:
        INDEX_MERLKON1(url)    
elif mode==195:
        EPISODE_MERLKON1(url,name)		
elif mode==201:
        INDEX_CKH7(url)    
elif mode==205:
        EPISODE_CKH7(url,name)
elif mode==211:
        INDEX_KM168(url)    
elif mode==215:
        EPISODE_KM168(url,name)		
elif mode==221:
        INDEX_PHUMIKHMER1(url)    
elif mode==225:
        EPISODE_PHUMIKHMER1(url,name)			
elif mode==231:
        INDEX_PHUMIKHMER2(url)    
elif mode==235:
        EPISODE_PHUMIKHMER2(url,name)	
	
		
xbmcplugin.endOfDirectory(int(sysarg))
        