import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
import urlresolver

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonMovie')
addon_name = 'plugin.video.KonMovie'

MOVIE9999 ='http://www.khmermovie999.com/'
KHFULLHD ='http://www.khfullhd.com/'
KHMER7HD ='https://khmer7hd.com/'
KHMERKH ='http://www.khmerkhmovie.com/'
DAILY ='https://www.dailymovie.us/'
GOMOVIES ='https://www1.gomovies.sc/'

USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')
movie9Image = os.path.join(ADDON_PATH, 'resources', 'images','movie9.png')

def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response

	
def HOME():
		addDir('KhmerFull',KHFULLHD,11,'http://www.khfullhd.com/wp-content/uploads/2017/10/cropped-Khmer-Full-HD-3-e1508147298324.png')	
		addDir('Movies',MOVIE9999,21,movie9Image+'')	
		#addDir('Khmer7HD',KHMER7HD+'movies/',31,'https://khmer7hd.com/wp-content/themes/V1.1.8/images/logo.png')	
		addDir('KhmerKh',KHMERKH+'http:/www.khmerkhmovie.com/topics/uncategorized/khmer-dubbed',41,'http://www.khmerkhmovie.com/wp-content/uploads/2017/12/logo-1.png')	
		addDir('DailyMovie',DAILY,51,'https://3.bp.blogspot.com/-dPlYFZYZo1A/WsmWJGX726I/AAAAAAAAA1k/FqnvpLPGAsYy3XMakvDsHlAcfbdzQMTfQCLcBGAs/s1600/Dailymoie-Logo.gif')
		addDir('TV Series',GOMOVIES+'tvseries/',65,'https://www1.gomovies.sc/wp-content/themes/assets/images/gomovies-logo-light.png')
		addDir('Movies',GOMOVIES+'movies/',61,'https://www1.gomovies.sc/wp-content/themes/assets/images/gomovies-logo-light.png')
		
		xbmcplugin.endOfDirectory(pluginhandle)
		

############## khmerkhmovie SITE ****************** 			   
def INDEX_KHMERKH(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('a',{'class':"ml-mask jt"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['data-original']
            vTitle = BeautifulSoup(str(link))('a')[0]['oldtitle']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,45,vImage)
        match5=re.compile("<ul class='pagination'>((.|\s)*?)</ul>").findall(html)
        if(len(match5) >= 1 and len(match5[0]) >= 1 ):
                pagelist =re.compile('<a [^>]*href=["\']?([^>^"^\']+)["\']?[^>]*>(.+?)</a>').findall(match5[0][0])
                for pageurl,pagenum in pagelist:
					addDir("page " + pagenum,pageurl,41,"")

def EPISODE_KHMERKH(url,name): 
         html = requests.get(url)
         match=re.compile('src="(.+?)" scrolling="no" frameborder="0" width=".+?" height=".+?" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true">').findall(html.content)
         for vurl in match:
            addLink(name,vurl,4,'')
         else:
          match=re.compile('<p>(.+?)</p>\n<div id="video">\n<div id="screen">\n<div class="video-wrap">\n<iframe[^>]*src="(.+?)"[^>]*allowfullscreen=true">').findall(html.content)
          for vname,vurl in match:
            addLink(vname,vurl.replace('//',"https://"),4,'')		 	
			
			
############## KHFULLHD SITE ****************** 			   
def INDEX_KHFULLHD(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"entry-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['srcset']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,15,vImage)
        try:
           paging = soup('div',{'class':'nav-links'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,11,"")
        except:pass 
			
def EPISODE_KHFULLHD(url,name):    
         html = requests.get(url)
         match=re.compile('src="(.+?)" width=".+?" height=".+?">').findall(html.content)
         for vurl in match:
            addLink(name,vurl,4,'')		
		
############## khmer7hd SITE ****************** 			   
def INDEX_KHMER7HD(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"ml-item"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['data-original']
            vTitle = BeautifulSoup(str(link))('a')[0]['oldtitle']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,35,vImage)
        match5=re.compile("<ul class='pagination'>((.|\s)*?)</ul>").findall(html)
        if(len(match5) >= 1 and len(match5[0]) >= 1 ):
                pagelist =re.compile('<a [^>]*href=["\']?([^>^"^\']+)["\']?[^>]*>(.+?)</a>').findall(match5[0][0])
                for pageurl,pagenum in pagelist:
					addDir("page " + pagenum.replace('Last \xc2\xbb','Last >>').replace('\xc2\xab',"Prev <<").replace("Prev << First","<< First").replace('\xc2\xbb',"Next >>"),pageurl,31,"")

def EPISODE_KHMER7HD(url,name): 
         html = requests.get(url)
         match=re.compile('src="(.+?)" width=".+?" height=".+?" frameborder="0" marginwidth="0px" marginheight="0px" scrolling="no" allowfullscreen="allowfullscreen">').findall(html.content)
         for vurl in match:
            addLink(name,vurl.replace('//',"https://"),3,'')
		
############## Khmermovie9999 SITE ****************** 			 
def INDEX_MOVIE9999(url):     
    link = OpenURL(url)
    try:
        link =link.encode("UTF-8")
    except: pass
    match=re.compile("<a href='(.+?)' style='background:url\((.*?)\) no-repeat center center;background-size:cover'></a>").findall(link.replace("s72-c","s1600"))
    if(len(match) > 0): 
     for vurl,vimage in match:
        addDir('',vurl,25,vimage) 
    else: 
     match=re.compile("<a href='(.+?)' style=\"background:url\((.*?)\) no-repeat center center;background-size:cover").findall(link.replace("s72-c","s1600"))
     if(len(match) > 0): 
      for vurl,vimage in match:
        addDir('',vurl,25,vimage.replace("//","http://")) 
    pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(link)
    for pageurl in pages:
        addDir("[B][COLOR blue]%s >>[/B][/COLOR]"% 'NEXT PAGE',pageurl,21,"") 
		  
def EPISODE_MOVIE9999(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('<iframe mozallowfullscreen="yes" .+?src="(.+?)"\s*width=".+?"').findall(link)
        if(len(match) > 0):
         counter = 0      
         for vLink in match:
            counter += 1 
            addLink(" Part " + str(counter),vLink,4,'')
        else: 
         match=re.compile('<source src="(.+?)" type="video/mp4">').findall(link)
         if(len(match) > 0):
          counter = 0      
          for vLink in match:
             counter += 1 
             addLink(" Part " + str(counter),vLink,4,'')
         else: 
          match=re.compile('<iframe src="(.+?)" .+? allowfullscreen="yes">').findall(link)
          if(len(match) > 0):
           counter = 0      
           for vLink in match:
              counter += 1 
              addLink(" Part " + str(counter),vLink,4,'')
			
############## DAILYMOVIE SITE ****************** 			
def INDEX_DAILY(url):
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            print vImage.encode("UTF-8")
            addDir(vTitle,vLink,55,vImage)			
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
			addDir("[B][COLOR blue]%s >>[/B][/COLOR]"% 'NEXT PAGE',pageurl,51,"") 			

def EPISODE_DAILY(url,name): 
    link = OpenURL(url)
    match=re.compile("unescape\('(.+?)'\)").findall(urllib.unquote(link).decode('utf8'))
    if(len(match) > 0):
     counter = 0 
     for vid in match:
         counter += 1 
         vurl=re.compile('<iframe src="(.+?)"').findall(vid)[0]
         addLink(" Server " + str(counter),vurl,4,'')
    else:
     match=re.compile('<iframe src="(.+?)"').findall(link)
     if(len(match) > 0):
      counter = 0      
      for vLink in match:
         counter += 1 
         addLink(" Server " + str(counter),vLink,4,'')	
			
############## GOMOVIES SITE ****************** 			   
def INDEX_GOMOVIES(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('a',{'class':"ml-mask jt"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['data-original']
            vTitle = BeautifulSoup(str(link))('a')[0]['oldtitle']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,66,vImage)
        try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&#8594;","").replace("&raquo;","Last").replace("&#8592;","")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,61,"")
        except:pass 
		
def EPISODE_GOMOVIES(url,name): 
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"ml-item"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['data-original']
            vTitle = BeautifulSoup(str(link))('a')[0]['oldtitle']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,67,vImage)
        try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&#8594;","").replace("&raquo;","Last").replace("&#8592;","")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,61,"")
        except:pass 
			
def PLAY_GOMOVIES(url,name):
    link = OpenURL(url)
    URL=re.compile('<a onclick="watching[^>]* href="(.+?)"').findall(link)[0]
    link = OpenURL(URL)  
    match=re.compile('onclick=".+?" data-(.+?)="(.+?)"').findall(link.replace('openload','https://openload.co/embed/').replace('strgo','https://streamgo.me/player/'))
    if(len(match) > 0):
      counter = 0 
      for vid1, vid2 in match:
         counter += 1
         addLink(" Server " + str(counter),vid1+vid2,4,'')
		 
def PLAY_GOSHOW(url,name):
    link = OpenURL(url)
    URL=re.compile('<a onclick="watching[^>]* href="(.+?)"').findall(link)[0]
    link = OpenURL(URL) 
    match=re.compile('<a title="(.+?)" data-(.+?)="(.+?)"').findall(link.replace('openload','https://openload.co/embed/').replace('strgo','https://streamgo.me/player/'))
    for vname,vid1,vid2 in reversed(match):
        addLink(vname,vid1+vid2,4,'')

############## END ****************** 
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):       
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link)
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):                    
                            match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                            for url in match:
                             vid = url[0].replace("['']", "")       
                             match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                             VIDEO_HOSTING(match)
                             print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
   
def VIDEO_HOSTING(vlink):
           if 'dailymotion' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'streamango.com' in vlink:
                VideoURL = STREAMANGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'streamgo.me' in vlink:
                VideoURL = STREAMGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamgo Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'streamcherry.com' in vlink:
                VideoURL = STREAMANGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'openload.co' in vlink:
                VideoURL = OPENLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Openload Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'google.com' in vlink:   
                VideoURL = DOCS_GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'vimeo' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)

           elif 'vid.me' in vlink:                   
                VideoURL = VIDDME(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vid.me Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'sendvid.com' in vlink:
                VideoURL = SENDVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sendvid Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'viddme' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Viddme Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'az665436' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,AZ Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'd1wst0behutosd' in vlink:
                #link = OpenURL(vlink)   
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,d1wst0behutosd Loading selected video)")
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
           #     Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,MP4UPLOAD Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'videobam' in vlink:  
                VideoURL = VIDEOBAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Videobam Loading selected video)")                                
                Play_VIDEO(VideoURL)     

           elif 'sharevids.net' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sharevids Loading selected video)")
                Play_VIDEO(VideoURL)   
                    # d = xbmcgui.Dialog()
                    # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')     
					
           elif 'videos4share.com' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,videos4share Loading selected video)")
                #Play_VIDEO(VideoURL)
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
				
           elif 'youtu.be' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")            
                Play_VIDEO(VideoURL)     

           elif 'youtube' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)
           else:
                #if 'grayshare.net' in vlink:
                if 'share.net' in vlink:    
                    VideoURL = vlink
                    print 'VideoURL: %s' % VideoURL
                    Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))    
                      # d = xbmcgui.Dialog()
                      # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')                
               
                else:
                    print 'VideoURL: %s' % vlink
                    xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonMovie is loading...)")
                    Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                    #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                    #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)
	
def STREAMANGO(SID):
        VideoURL = urlresolver.HostedMediaFile(url=SID).resolve()
        return VideoURL     
		
def STREAMGO(SID):
        VideoURL = urlresolver.HostedMediaFile(url=SID).resolve()
        return VideoURL   
		
def OPENLOAD(SID):
        VideoURL = urlresolver.HostedMediaFile(url=SID).resolve()
        return VideoURL  	

def DAILYMOTION(SID):
        match=re.compile('(dailymotion\.com\/(watch\?(.*&)?v=|(embed|v|user|video)\/))([^\?&"\'>]+)').findall(SID)                
        SID = match[0][len(match[0])-1]
        VideoURL = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' +SID
        return VideoURL

def DOCS_GOOGLE(Video_ID):
                docid=re.compile('/d/(.+?)/preview').findall(Video_ID)[0]
                cj = cookielib.LWPCookieJar()
                (cj,vidcontent) = GetContent2("https://docs.google.com/get_video_info?docid="+docid,"", cj) 
                html = urllib2.unquote(vidcontent)
                cookiestr=""
                for cookie in cj:
					cookiestr += '%s=%s;' % (cookie.name, cookie.value)
                try:
					html=html.encode("utf-8","ignore")
                except: pass
                stream_map = re.compile('fmt_stream_map=(.+?)&fmt_list').findall(html)
                if(len(stream_map) > 0):
					formatArray = stream_map[0].replace("\/", "/").split(',')
					for formatContent in formatArray:
						 formatContentInfo = formatContent.split('|')
						 qual = formatContentInfo[0]
						 vidlink = (formatContentInfo[1]).decode('unicode-escape')

                else:
						cj = cookielib.LWPCookieJar()
						newlink1="https://docs.google.com/uc?export=download&id="+docid  
						(cj,vidcontent) = GetContent2(newlink1,newlink, cj)
						soup = BeautifulSoup(vidcontent)
						downloadlink=soup.findAll('a', {"id" : "uc-download-link"})[0]
						newlink2 ="https://docs.google.com" + downloadlink["href"]
						vidlink=GetDirVideoUrl(newlink2,cj) 
                VideoURL = (vidlink+ ('|Cookie=%s' % cookiestr))
                return  VideoURL

def FACEBOOK (SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()
       vlink = 'http://www.facebook.com/video/video.php?v=' + str(link)
       #vlink = re.compile('"params","([\w\%\-\.\\\]+)').findall(link)[0]
       html = urllib.unquote(vlink.replace('\u0025', '%')).decode('utf-8')
       html = html.replace('\\', '')
       videoUrl = re.compile('(?:hd_src|sd_src)\":\"([\w\-\.\_\/\&\=\:\?]+)').findall(html)
       if len(videoUrl) > 0:    
           VideoURL =  videoUrl[0]
       else:
           VideoURL =  videoUrl
       return  VideoURL  

def MP4UPLOAD(SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()    
       VideoURL=re.compile('\'file\': \'(.+?)\'').findall(link)[0]
       return VideoURL

def SENDVID(SID):
        #Video_ID = urllib.unquote_plus(SID).replace("//", "http://")
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match = re.compile('<source src="([^"]+?)"').findall(link)
        #match = re.compile('<meta property="og:video:secure_url" content="([^"]+?)"').findall(link)
        #VideoURL = (match[0]).decode("utf-8")
        VideoURL =  urllib2.unquote(match[0]).replace("//", "http://")
        return VideoURL

def VIDDME(Video_ID):
        VideoURL = urlresolver.HostedMediaFile(url=url).resolve()
        #SID=re.compile('vid.me/e/(.+)').findall(Video_ID)[0]
        #URL = "https://vid.me/e/"+str(SID)
        #VideoURL = media_url = urlresolver.resolve(URL)
        return VideoURL        

def VIDEOBAM(Video_ID):        
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('"url"\s*:\s*"(.+?)","').findall(link)               
        for URL in match:
            if(URL.find("mp4") > -1):
               VideoURL = URL.replace("\\","")
        return VideoURL       

def VIMEO(Video_ID):
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            SID =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              SID =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
        VideoURL = 'plugin://plugin.video.vimeo/play/?video_id='+str(SID)
        return VideoURL
		
def VIMEO1(Video_ID):
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            vlink =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              vlink =re.compile("//vimeo.com/(.+?)\?").findall(Video_ID+'?')
        #result = common.fetchPage({"link": "http://player.vimeo.com/video/%s/config?type=moogaloop&referrer=&player_url=player.vimeo.com&v=1.0.0&cdn_url=http://a.vimeocdn.com" % vlink[0],"refering": HomeURL})
        result = common.fetchPage({"link": "http://player.vimeo.com/video/%s?title=0&byline=0&portrait=0" % vlink[0],"refering": HomeURL})        
        print 'Result: %s' % result
        collection = {}
        if result["status"] == 200:
            html = result["content"]
            html = html[html.find('={"cdn_url"')+1:]
            html = html[:html.find('}};')]+"}}"
            #print html
            collection = json.loads(html)
            print 'Collection: %s' %collection
            #codec = collection["request"]["files"]["codecs"][0]
            #print codec            
            video = collection["request"]["files"]["progressive"]#[0]
            #isHD = collection["request"]["files"][video]
            print 'VideoCOLL1: %s' % video
            if(len(video) > 2):
            #if video.get("720p"):
                VideoURL = video[2]['url']
                print 'VideoSD: %s' % VideoURL
            #elif(len(video) > 1):
            #    VideoURL = video[1]['url']
            #    print 'VideoSD: %s' % VideoURL
            else: 
               VideoURL = video[0]['url']
               print 'VideoLD: %s' % VideoURL
        return VideoURL
		
def YOUTUBE(SID):
        match=re.compile('(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)').findall(SID)
        if(len(match) > 0):
             URL = match[0][len(match[0])-1].replace('v/','')
        else:   
             match = re.compile('([^\?&"\'>]+)').findall(SID)
             URL = match[1].replace('v=','')
        VideoURL = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' +URL.replace('?','')     
        return VideoURL	
###################### Resolver End  ###################    
    
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    

params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	
		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)        

		
elif mode==11:
        INDEX_KHFULLHD(url)    
elif mode==15:
        EPISODE_KHFULLHD(url,name)			
elif mode==21:
        INDEX_MOVIE9999(url)    
elif mode==25:
        EPISODE_MOVIE9999(url,name)	
elif mode==31:
        INDEX_KHMER7HD(url)    
elif mode==35:
        EPISODE_KHMER7HD(url,name)		
elif mode==41:
        INDEX_KHMERKH(url)    
elif mode==45:
        EPISODE_KHMERKH(url,name)	
elif mode==51:
        INDEX_DAILY(url)    
elif mode==55:
        EPISODE_DAILY(url,name)		
elif mode==61:
        INDEX_GOMOVIES(url)    
elif mode==65:
        EPISODE_GOMOVIES(url,name)	
elif mode==66:
        PLAY_GOMOVIES(url,name)	
elif mode==67:
        PLAY_GOSHOW(url,name)				
       
xbmcplugin.endOfDirectory(int(sysarg))
        