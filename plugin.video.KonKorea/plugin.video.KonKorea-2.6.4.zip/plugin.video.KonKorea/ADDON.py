import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
import resolveurl
import pickle

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonKorea')
addon_name = 'plugin.video.KonKorea'

KHMOTION ='https://www.khmotionn.com/'
KHDRAMA ='http://www.khmer-drama.com/'
FILM4KH ='http://www.film2us.com/'
JONGMEL ='http://asialakorn.com/'
K8MER = 'http://www.top2khmer.com/'
KHMER4F ='http://preahchan.com/'
PHUMKOM ='http://www.phumkomsan.com/'
KHMERKOM ='https://www.cartoonson.tv/'
PHUMIHD ='http://www.ckh7.com/'
VIDEO4U ='http://www.video4khmer36.com/'
PHUMIKHMER ='http://www.phumikhmer9.com/'
LAKHOAN ='http://www.themoviekhmer.com/'
MERLKON ='http://www.khmerstream.net/'
AVE ='http://www.khmeravenue.com/'
TUBE_KHMER ='http://www.tubekhmer24.com/'
KM168 ='http://www.kolabkhmer7.club/'
CITY ='http://www.khmerkomsan.net/'


USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
addon_name = PLUGIN.getAddonInfo('profile')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
SearchImage = os.path.join(ADDON_PATH, 'resources', 'images','search.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')

def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response
	
def GetInput(strMessage,headtxt,ishidden):
    keyboard = xbmc.Keyboard("",strMessage,ishidden)
    keyboard.setHeading(headtxt) # optional
    keyboard.doModal()
    inputText=""
    if (keyboard.isConfirmed()):
        inputText = keyboard.getText()
    del keyboard
    return inputText	

# KhmerStream login
def LOGIN():
		khmerstream_account = PLUGIN.getSetting('khmerstream-account')
		hide_message = PLUGIN.getSetting('hide-successful-login-messages')
		if khmerstream_account == 'true':
				loginurl = 'http://www.khmerstream.net/wp-login.php'
				login = PLUGIN.getSetting('khmerstream-username')
				password = PLUGIN.getSetting('khmerstream-password')
				form = {'log' : login, 'pwd' : password, 'wp-submit' : 'Log In'}				
				net.http_POST(loginurl, form)
				print 'Cookiess: %s' % net
				net.save_cookies(cookiejar)        
				CHECKUSER(MERLKON)
				
def CHECKUSER(url):
		hide_message = PLUGIN.getSetting('hide-successful-login-messages')
		net.set_cookies(cookiejar)
		#print 'Cookiesss: %s' % net
		req = urllib2.Request(url)
		req.add_header('User-Agent', USER_AGENT)
		response = urllib2.urlopen(req)
		link=response.read()
		#print 'Links: %s' % link
		response.close()
		match=re.compile('<li id="wp-admin-bar-logout"><a class="ab-item"  href="(.+?)">(.+?)</a>').findall(link)
		#print 'LinkMatchs: %s' % match
		if match:
				if hide_message == 'false':
						print 'Khmerstream Account: login successful'
						xbmc.executebuiltin("XBMC.Notification('small','Khmerstream Account login successful.')")						
		if not match:
				print 'Khmerstream Account: login failed'
				#xbmc.executebuiltin("XBMC.Notification('small,'Login failed: check your username and password')")				
		pass	
# KhmerStream login	
	
def HOME():
		LOGIN()
		khmerstream_account = PLUGIN.getSetting('khmerstream-account')	
		addDir('Search',MERLKON,5,SearchImage+'')
		addDir('7Khmer',KHMOTION+'search/label/Korean%20Drama?&max-results=20',11,'http://1.bp.blogspot.com/-eYngwVMs7wk/VbIiF42BlDI/AAAAAAAAMpc/APh97n98Vy4/s1600/7khmer%2Blogo.png')		
		addDir('Cartoonson',KHMERKOM,81,'https://www.cartoonson.tv/images/logos/logo-cartoons-on.png')	
		addDir('CKH7',PHUMIHD+'category.php?cat=korean-drama',91,'http://www.ckh7.com/templates/default/img/logo.png')		
		addDir('Drama4Kh',KHDRAMA+'category.php?cat=korean-drama',21,'http://www.khmer-drama.com/templates/default/img/khmer-drama.png')	
		addDir('KhmerKomsan',CITY+'category.php?cat=korean-drama',181,'http://www.khmerkomsan9.com/templates/default/img/KhmerKomsan.png')		
		addDir('KhmerStream',AVE+'genre/korean/',131,'http://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png')		
		addDir('KolapKhmer',KM168+'search/label/KOREA?&max-results=24',151,'https://2.bp.blogspot.com/-Fs1Xu7DJ20k/WojR-gsNIOI/AAAAAAAAOgQ/xGXdg-jUr0YAfbRCvLj_q2P5a_SqXmTWgCK4BGAYYCw/s1600/kolabkhmer%2Blogo%2B1.png')	
		#addDir('PhumKomsan',PHUMKOM+'search/label/Korean%20Drama',71,'http://1.bp.blogspot.com/-mLnQCEv8hRs/V_sSRlxVgSI/AAAAAAAABGE/qHwOVe1JiJEGrwllFV7dUBIhbFUbS0DoACK4B/s1600/phum-komsan-web-logo.png')	
		addDir('VideoKhmer',VIDEO4U+'khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')
		addDir('Video4Khmer',VIDEO4U+'khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html',101,'http://www.video4khmer16.com/templates/kulenkiri/images/header/logo.png')
		if khmerstream_account == 'true':            
			net.set_cookies(cookiejar)
			link = OpenURL(MERLKON)
			match=re.compile('<li id="wp-admin-bar-logout"><a class="ab-item"  href="(.+?)">(.+?)</a>').findall(link)
			for vurl,vname in match:
				addDir('[B][COLOR red]%s[/B][/COLOR]'% vname,vurl,HOME,'')			
		xbmcplugin.endOfDirectory(pluginhandle)
		
### search ###
def SEARCH():
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        #searchText = '01'
        if (keyb.isConfirmed()):
                searchText = urllib.quote_plus(keyb.getText())
        url = 'http://www.khmeravenue.com/?s='+ searchText
        SINDEX_KHMERSTREAM(url)
        url = 'https://www.khmotionn.com/search?q='+ searchText
        SINDEX_KHMOTION(url)
        url = 'http://www.video4khmer36.com/search.php?keywords='+ searchText
        SINDEX_VIDEO4U(url)	
        url = 'http://www.kolabkhmer7.club/search/max-results=8?q='+ searchText
        SINDEX_KOLAB(url)	
        url = 'http://www.khmer-drama.com/search.php?keywords='+ searchText
        SINDEX_KHDRAMA(url)	
        url = 'http://www.khmerstation.live/search?q='+ searchText
        SINDEX_KHDRAMA(url)	
        url = 'http://www.ckh7.com/search.php?keywords='+ searchText
        SINDEX_PHUMIHD(url)		
        url = 'http://www.phumkomsan.com/search?q='+ searchText
        SINDEX_PHUMKOM(url)			
        url = 'http://www.khmerkomsan.net/search.php?keywords='+ searchText
        SINDEX_CITY(url)		
		

### End search ####		


############## khmerkomsan SITE ****************** 			   
def INDEX_CITY(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,185,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmerkomsan9.com/' + pageurl.encode("utf-8")),181,"")		 
         except:pass
		 
### search ##			
def SINDEX_CITY(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] KHMERKOMSAN[/COLOR]',vLink,185,vImage)			
##end ##		 

def EPISODE_CITY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 
		  
############## KOLAPKHMER SITE ****************** 			 
def INDEX_KM168(url):     
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle,vLink,155,vImage)
        pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
        for pageurl in pages:
            addDir('NEXT PAGE',pageurl,151,"") 
			
### search ##			
def SINDEX_KOLAB(url):
    #try:
        html = OpenSoup(url)
        try:
            html = html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        video_list = soup('div',{'class':'post-outer'})
        for link in video_list:
            vLink = BeautifulSoup(str(link))('a')[1]['href']
            #vTitle = BeautifulSoup(str(link))('a')[0].contents[0]
            vTitle = BeautifulSoup(str(link))('a')[1]['title']			
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
            addDir(vTitle+'[COLOR red] KOLABKHMER[/COLOR]',vLink,155,vImage)			
##end ##			
		  
def EPISODE_KM168(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName.replace("&#8203;",""),vLink,4,'')
        else: 
         match=re.compile('<iframe allowfullscreen="" frameborder="0" height=".+?" mozallowfullscreen="" name=".+?" src="(.+?)" webkitallowfullscreen="" width=".+?">').findall(link)
         if(len(match) > 0): 
          counter = 0		 
          for vLink in match:
           counter += 1		   
           addLink("Part " + str(counter),vLink,4,'')			
		
############## 7Khmer SITE ****************** 
def INDEX_KHMOTION(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' id=\'pindah-judul\' itemprop=\'headline\'>\n<a href=\'(.+?)\' itemprop=\'url mainEntityOfPage\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname,vurl,15,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir(pagenum.replace("Older Posts","Next Page").replace("Newer Posts","Prev Page"),pageurl,11,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)
		
###search ###		
def SINDEX_KHMOTION(url):     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile('<h2 class=\'post-title entry-title index\' id=\'pindah-judul\' itemprop=\'headline\'>\n<a href=\'(.+?)\' itemprop=\'url mainEntityOfPage\'>(.+?)</a>\n</h2>\n<meta content=\'(.+?)\'').findall(link)
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;","")+'[COLOR red] 7KHMER[/COLOR]',vurl,15,vimage)		
### end ###		
	
def EPISODE_KH(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle)  
		
############## drama4khmers SITE ****************** 			   
def INDEX_KHDRAMA(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"heading"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,25,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmer-drama.com/' + pageurl.encode("utf-8")),21,"")		 
         except:pass   
		 
### SEARCH ###
def SINDEX_KHDRAMA(url):     
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"heading"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;","")+'[COLOR red] DRAMA4K[/COLOR]',vLink,25,vImage)		 
## END ##		 

def EPISODE_KHD(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'') 
	      

############## Phumkomsan SITE ****************** 		  
def INDEX_PHUMKOM(url):
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumbimage imglatest"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,75,vImage)		  
         pages=re.compile('<span id=\'blog-pager-older-link\'>\n<a class=\'blog-pager-older-link\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE',pageurl,71,"")                    
         #xbmcplugin.endOfDirectory(pluginhandle)
		 
### SEARCH ###
def SINDEX_PHUMKOM(url):     
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumbimage imglatest"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('img')[0]['src'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle+'[COLOR red] PHUMKOMSAN[/COLOR]',vLink,75,vImage)			 
## END ##		 
		  
def EPISODE_PHUMKOM(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')			 

############## cartoonson.tv SITE ****************** 
def INDEX_KID(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"image-overlay"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vTitle = BeautifulSoup(str(link))('img')[0]['title'].replace('Watch','')
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,85,vImage)
        try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&raquo;","Next").replace("&laquo;","Prev")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,81,"")
        except:pass 	
	
def PLAY_KID(url,name): 
    link = OpenURL(url)
    match=re.compile('>\n(.+?)</a>\n<a\nhref="(.+?)"').findall(link.replace('\t',''))
    for vname,vurl in match:
        addDir(vname,vurl,86,'')
    else:
     match=re.compile('data-src="(.+?)"[^>]*>\n</a><h3 class="text-center" ><a\nhref="(.+?)">(.+?)</a></h3></div>').findall(link)
     for vimage,vurl,vname in match:
         addDir(vname,vurl,87,vimage)
     else:
      match=re.compile('<a\nhref="(.+?)" class="btn btn-primary btn-lg"').findall(link.replace('-preview',''))
      for vurl in match:
          link2 = OpenURL(vurl) 
          match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link2)
          for vlink in match:
              addLink('Server 1',vlink,4,'')
          else:
           match=re.compile('<li>\n<a\nhref="(.+?)" >.+?</a></li></ul>').findall(link2)
           for URL in match:
               link = OpenURL(URL)
               match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link)
               for vlink in match:
                   addLink('Server 2',vlink,4,'')				  
           else: 
            match=re.compile('<source\n[^>]*src="(.+?)"').findall(link2)
            if(len(match) > 0):
             counter = 0      
             for vLink in match:
              counter += 1 
              addLink("Server "+str(counter),vLink,4,'')		   
				  
def PLAY_KID2(url,name):
    link = OpenURL(url)
    match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link)
    for vlink in match:
        addLink(name,vlink,4,'')

def EPISODE_KID(url,name):
    link = OpenURL(url)
    match=re.compile('\n(.+?)</a>\n<a\nhref="(.+?)" class="pull-right play-episode-btn btn btn-default">').findall(link.replace('-preview',''))
    for vname,vurl in match:
        link2 = OpenURL(vurl) 
        match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link2)
        for vlink in match:
            addLink(vname.replace('\t','').replace('&amp;','&'),vlink,4,'')			  

############## ckh7 SITE ****************** 
def INDEX_PHUMIHD(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,95,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.ckh7.com/' + pageurl.encode("utf-8")),91,"")		 
         except:pass
		 
## SEARCH ##
def SINDEX_PHUMIHD(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-xs-6 col-md-3"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             #print vTitle
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] CKH7[/COLOR]',vLink,95,vImage)
##END ##		 
						
def EPISODE_PHUMIHD(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	

############## video4khmer1 SITE ****************** 
def INDEX_VIDEO4U(url):
        referer = {1:url}
        pickle_out = open(datapath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,105,vImage)
        try:
           paging = soup('div',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&gt;",">").replace("&lt;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,101,"")
        except:pass

### SEARCH ##
def SINDEX_VIDEO4U(url):
        referer = {1:url}
        pickle_out = open(datapath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"cat-thumb"})
        for link in div_index:
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('img')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle+'[COLOR red] VIDEO4U[/COLOR]',vLink,105,vImage)
## END ##			
	 
def EPISODE_VIDEO4U(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"id" : "content-center"})
        for item in listcontent[0].findAll('div', {"class" : "movie-thumb"}):
			vname=item.a.img["alt"]
			vurl=item.a["href"]
			vimg=item.a.img["src"]
			addLink(vname,vurl,3,vimg)

        for item in listcontent[0].findAll('li'):
             if(item.a!=None):
				pageurl=item.a["href"]
				pagenum=item.a.contents[0].replace("&gt;",">").replace("&lt;","<")
				addDir("Page " + pagenum,pageurl,105,"")
    #except: pass
     #xbmcplugin.endOfDirectory(pluginhandle)
	 
def EPISODE4U(url,name):        
        link = OpenURL(url)
        match=re.compile('<div class=".+?"><div class="movie-thumb"><a href="(.+?)"><img src="(.+?)" alt=".+?" title="(.+?)" width="180" height="170"').findall(link)
        counter = 1
        #for url,name,thumbnail in match:
        if (len(match) >= 1):
           for vLink,Vimage,vLinkName in match:
               counter += 1
               addLink(vLinkName,vLink,3,Vimage)
        match5=re.compile('<div class="pagination">(.+?)</div>').findall(link)
        if(len(match5)):
           pages=re.compile('<a href="(.+?)">(.+?)</a>').findall(match5[0])
           for pageurl,pagenum in pages:
               addDir(" Page " + pagenum.encode("utf-8"),pageurl,105,"")     
           xbmcplugin.endOfDirectory(pluginhandle)


############## Khmerstream SITE ****************** 		  
def INDEX_MERLKON(url):
        referer = {1:url}
        pickle_out = open(datapath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()    
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0].replace("&#8217;","")
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle,vLink,135,vImage)
        try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0]
             addDir(" Page " + pagenum.encode("utf-8"),pageurl,131,"")
        except:pass 	

### search ###
def SINDEX_KHMERSTREAM(url): 
        referer = {1:url}
        pickle_out = open(datapath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()   
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0].replace("&#8217;","")
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle+'[COLOR red] MERLKON[/COLOR]',vLink,135,vImage)
### end ###			

def EPISODE_MERLKON(url,name):
        link = OpenURL(url)
        match=re.compile('<a href="(.+?)"><button type="button" class="btn btn-episode">(.+?)</button></a>').findall(link)     
        if(len(match) == 0):
          match=re.compile('<a href="(.+?)"><span style=".+?">(.+?)</span></a>').findall(link)
        for vLink, vLinkName in match:
            addLink(vLinkName,vLink,3,'')
        xbmcplugin.endOfDirectory(pluginhandle)		
		
##########
		
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):              
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link.replace('=m37','=m18')) 
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):   
                            match=re.compile('playlist: "(.+?)"').findall(link)# Good Link
                            if(len(match) == 0):
                             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# KhmerTV
                             if(len(match) == 0):							
                              match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                              for url in match:
                               vid = url[0].replace("['']", "")       
                               match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                               #REAL_VIDEO_HOST(match)
                               VIDEO_HOSTING(match)
                               print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
    
def VIDEO_HOSTING(vlink):
           if 'khmotions.com' in vlink:   
                VideoURL = KHMOTIONS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Khmotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'kolabkhmer.club' in vlink:
                VideoURL = KOLABKHMERS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Kolabkhmer Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'dailymotion.com' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'estream.to' in vlink:   
                VideoURL = ESTREAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Estream Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'fembed.com' in vlink:
                VideoURL = FEMBED(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Fembed Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'google.com' in vlink:   
                VideoURL = GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'k-vid.net' in vlink:   
                VideoURL = KVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,K-vid Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Mp4upload Loading selected video)")
                Play_VIDEO(VideoURL)				
		
           elif 'ok.ru' in vlink:
                VideoURL = OKRU(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,OK Loading selected video)")
                Play_VIDEO(VideoURL)	
				
           elif 'openload.co' in vlink:   
                VideoURL = OPENLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Openload Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'rapidvideo.com' in vlink:   
                VideoURL = RAPIDVIDEOCOM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Rapidvideo Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'streamango.com' in vlink:   
                VideoURL = STREAMANGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)		

           elif 'vev.io' in vlink:   
                VideoURL = VEVIO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vevio Loading selected video)")
                Play_VIDEO(VideoURL)				
     
           elif 'vimeo.com' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)
				 
           elif 'vidlox.me' in vlink:
                 VideoURL = VIDLOX(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vidlox Loading selected video)")
                 Play_VIDEO(VideoURL)	

           elif 'xstreamcdn.com' in vlink:
                 VideoURL = XSTREAMCDN(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,xStreamcdn Loading selected video)")
                 Play_VIDEO(VideoURL)				 

           elif 'youtube.com' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)        
       
           else:
                print 'VideoURL: %s' % vlink
                xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonJen is loading...)")
                Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)
	
def KHMOTIONS(SID):
	req = urllib2.Request(SID)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()    
	match720p = re.compile('file:\s"(.+?)",.+?720.+?"', re.DOTALL).findall(link)
	match480p = re.compile('file:\s"(.+?)",.+?480.+?"', re.DOTALL).findall(link)
	match360p = re.compile('file:\s"(.+?)",.+?360.+?"', re.DOTALL).findall(link)
	match240p = re.compile('file:\s"(.+?)",.+?240.+?"', re.DOTALL).findall(link)
	matchSD = re.compile('file : "(.+?)"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	elif matchSD:
		VideoURL = matchSD[0]
	return VideoURL			

def KOLABKHMERS(SID):
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        VideoURL =  re.compile('"file":"(.+?)"').findall(link.replace('\/','/'))[0]
        return VideoURL	

def DAILYMOTION(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def ESTREAM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL		

def FACEBOOK(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	

def FEMBED(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	

def GOOGLE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def KVID(SID):
		link = OpenURL(SID)
		URL=re.compile('window.location = "(.+?)"').findall(link)[0]
		VideoURL = resolveurl.resolve(URL)
		return VideoURL	

def MP4UPLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def OKRU(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def OPENLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL			

def RAPIDVIDEOCOM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def STREAMANGO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def VEVIO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL  		
		
def VIDLOX(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def VIMEO(Video_ID):
        pickle_in = open(datapath+"dict.pickle","rb")
        referer = pickle.load(pickle_in)
        Referer = (referer[1])
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            media_id =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              media_id =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
        SID = "https://player.vimeo.com/video/%s?api=1&amp;player_id=video_player" % media_id[0]  
        headers = {'Referer': Referer}
        link = requests.get(SID, headers=headers)
        VideoURL = re.compile('"hls"[^>]*"akfire_interconnect_quic":{"url":"(.+?)"').findall(link.content)[0]
        return VideoURL	
		
def XSTREAMCDN(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	 
	
def YOUTUBE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
###################### Resolver End  ###################   
     
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    

params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	
		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)        
elif mode==5:
        SEARCH()	
	
elif mode==11:
        INDEX_KHMOTION(url)    
elif mode==15:
        EPISODE_KH(url,name)
elif mode==21:
        INDEX_KHDRAMA(url)    
elif mode==25:
        EPISODE_KHD(url,name)		
elif mode==31:
        INDEX_FILM2US(url)    
elif mode==35:
        EPISODE_FILM2US(url,name)			
elif mode==41:
        INDEX_JONGMEL(url)    
elif mode==45:
        EPISODE_JONGMEL(url,name)			
elif mode==51:
        INDEX_K8MERHD(url)    
elif mode==55:
        EPISODE_K8MERHD(url,name)			
elif mode==61:
        INDEX_KHMER4F(url)    
elif mode==65:
        EPISODE_KHMER4F(url,name)	
elif mode==71:
        INDEX_PHUMKOM(url)    
elif mode==75:
        EPISODE_PHUMKOM(url,name)	
elif mode==81:
        INDEX_KID(url) 		
elif mode==85:
        PLAY_KID(url,name)
elif mode==86:
        PLAY_KID2(url,name)		
elif mode==87:
        EPISODE_KID(url,name)			
elif mode==91:
        INDEX_PHUMIHD(url)    
elif mode==95:
        EPISODE_PHUMIHD(url,name)		
elif mode==101:
        INDEX_VIDEO4U(url)    
elif mode==105:
        EPISODE_VIDEO4U(url,name)			
elif mode==111:
        INDEX_PHUMIKHMER(url)    
elif mode==115:
        EPISODE_PHUMIKHMER(url,name)		
elif mode==121:
        INDEX_LAKHOAN(url)    
elif mode==125:
        EPISODE_LAKHOAN(url,name)
elif mode==131:
        INDEX_MERLKON(url)    
elif mode==135:
        EPISODE_MERLKON(url,name)
elif mode==141:
        INDEX_TUBE(url)    
elif mode==145:
        EPISODE_TUBE(url,name)	
elif mode==151:
        INDEX_KM168(url)    
elif mode==155:
        EPISODE_KM168(url,name)			
elif mode==181:
        INDEX_CITY(url)    
elif mode==185:
        EPISODE_CITY(url,name)	
				      
xbmcplugin.endOfDirectory(int(sysarg))
        