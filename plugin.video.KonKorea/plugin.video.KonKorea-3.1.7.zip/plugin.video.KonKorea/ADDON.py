import httplib
import urllib,urllib2,re,sys
import requests
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
try: import simplejson as json
except ImportError: import json
import cgi
import datetime
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
from BeautifulSoup import SoupStrainer
from urllib import urlencode
import resolveurl
import jsunpack
import pickle
from dodge import dodge
dodge = dodge()

PLUGIN = xbmcaddon.Addon(id='plugin.video.KonKorea')
addon_name = 'plugin.video.KonKorea'
addondl = 'plugin.video.khmerdl' ########## Download

KHMOTION ='https://www.khmotions.com/'
KHDRAMA ='http://www.thekomsan.com/'
KHMERKOM ='https://www.cartoonson.tv/'
PHUMIHD ='http://movie-khmer.com/'
VIDEO4U ='https://www.mahbaa.com/'
AVE ='http://www.khmeravenue.com/'
KM168 ='https://www.helthytips.com/'
CITY ='http://www.khmerkomsan.net/'
KHMERFAN = 'http://www.khmerfans.com/'


USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
########### download 
dpath = xbmc.translatePath('special://profile/addon_data/'+addondl+'/cookies/')
if not os.path.exists(dpath):
	os.makedirs(dpath)
###########
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
addon_name = PLUGIN.getAddonInfo('profile')
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from bs4 import BeautifulSoup
#from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image

JolchetImage = os.path.join(ADDON_PATH, 'resources', 'images','icon.png')
SearchImage = os.path.join(ADDON_PATH, 'resources', 'images','search.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor4.jpg')

def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response
	
def GetInput(strMessage,headtxt,ishidden):
    keyboard = xbmc.Keyboard("",strMessage,ishidden)
    keyboard.setHeading(headtxt) # optional
    keyboard.doModal()
    inputText=""
    if (keyboard.isConfirmed()):
        inputText = keyboard.getText()
    del keyboard
    return inputText	

	
def HOME():
		#addDir('Search',AVE,5,SearchImage+'')
		#addDir('7Khmer',KHMOTION+'search/label/Korean%20Drama?&max-results=20',11,'http://1.bp.blogspot.com/-eYngwVMs7wk/VbIiF42BlDI/AAAAAAAAMpc/APh97n98Vy4/s1600/7khmer%2Blogo.png')		
		#addDir('Cartoonson',KHMERKOM,81,'https://www.cartoonson.tv/images/logos/logo-cartoons-on.png')	
		addDir('KhmerAve',AVE+'country/korea/',131,'http://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png')	
		addDir('Movie-Khmer',PHUMIHD+'korean-drama/',91,'https://movie-khmer.com/wp-content/uploads/site-logo.png')		
		addDir('Drama4Kh',KHDRAMA+'category.php?cat=korean',21,'http://www.thekomsan.com/templates/default/img/the-komsan-logo.png')	
		#addDir('KhmerKomsan',CITY+'category.php?cat=korean-drama',181,'http://www.khmerkomsan.net/templates/default/img/KhmerKomsan.png')
		#addDir('KhmerFans',KHMERFAN+'albumcategory/korean/',132,'http://www.khmerfans.com/wp-content/themes/khmerdrama/img/logo.png')			
		#addDir('KolapKhmer',KM168+'search/label/Korean%20Drama',151,'https://2.bp.blogspot.com/-Fs1Xu7DJ20k/WojR-gsNIOI/AAAAAAAAOgQ/xGXdg-jUr0YAfbRCvLj_q2P5a_SqXmTWgCK4BGAYYCw/s1600/kolabkhmer%2Blogo%2B1.png')	
		addDir('Video4Khmer',VIDEO4U+'category/korean-drama-watch-online-free-catalogue-507-page-1.html',101,'http://www.video4khmer36.com/templates/kulenkiri/specials/kny2019/logo.png')
		xbmcplugin.endOfDirectory(pluginhandle)
		
### search ###
def SEARCH():
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        #searchText = '01'
        if (keyb.isConfirmed()):
                searchText = urllib.quote_plus(keyb.getText())
        url = 'http://www.khmeravenue.com/?s='+ searchText
        SINDEX_KHMERSTREAM(url)
        url = 'https://www.khmotionn.com/search?q='+ searchText
        SINDEX_KHMOTION(url)
        url = 'http://www.video4khmer36.com/search.php?keywords='+ searchText
        SINDEX_VIDEO4U(url)	
        url = 'https://www.khreplay8.com/search?q='+ searchText
        SINDEX_KOLAB(url)	
        url = 'http://www.thekomsan.com/search.php?keywords='+ searchText
        SINDEX_KHDRAMA(url)	
        url = 'https://www.khmercitylove.com/search?q='+ searchText
        SINDEX_PHUMIHD(url)			
		

### End search ####		


############## khmerkomsan SITE ****************** 			   
def INDEX_CITY(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 		    
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,185,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.khmerkomsan9.com/' + pageurl.encode("utf-8")),181,"")		 
         except:pass
		 
### search ##			
def SINDEX_CITY(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close() 		
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] KHMERKOMSAN[/COLOR]',vLink,185,vImage)			
##end ##		 

def EPISODE_CITY(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)"').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'') 
		  
############## KOLAPKHMER SITE ****************** 			 
def INDEX_KM168(url):     
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()   
         html = OpenSoup(url)
         try:   
			html =html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         video_list = soup('div',{'class':"thumb-area thumb-outer latest-img"})
         for link in video_list:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vLink = vLink.encode("UTF-8",'replace')
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             print vTitle
             vImage = BeautifulSoup(str(link))('a')[0]['data-img'].replace("s72-c","s1600")
             print vImage
             addDir(vTitle,vLink,155,vImage)		  
         pages=re.compile('<span class=\'pager-older-link\'>\n<a class=\'blog-pager-older-link btn\' href=\'([^"]+?)\' ').findall(html)
         for pageurl in pages:
				addDir('NEXT PAGE',pageurl,151,"")  
  
def EPISODE_KM168(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')		
		
############## 7Khmer SITE ****************** 
def INDEX_KHMOTION(url): 
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()     
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile("<a class='thumbimgx' href='(.+?)'.+?><img alt='(.+?)' class='.+? itemprop='image' src='(.+?)'").findall(link.replace('s72-c','s1600'))
        for vurl,vname,vimage in match:
            addDir(vname,vurl,15,vimage)
        pages=re.compile('<span id=\'.+?\'>\n<a class=\'.+?\' href=\'([^"]+?)\' id=\'.+?\' title=\'.+?\'>(.+?)</a>\n</span>').findall(link)
        for pageurl,pagenum in pages:
               addDir(pagenum.replace("Older Posts","Next Page").replace("Newer Posts","Prev Page"),pageurl,11,"")                        
        xbmcplugin.endOfDirectory(pluginhandle)
		
###search ###		
def SINDEX_KHMOTION(url):  
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()    
        link = OpenURL(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        match=re.compile("<a class='thumbimgx' href='(.+?)'.+?><img alt='(.+?)' class='.+? itemprop='image' src='(.+?)'").findall(link.replace('s72-c','s1600'))
        for vurl,vname,vimage in match:
            addDir(vname.replace("&#8203;","")+'[COLOR red] 7KHMER[/COLOR]',vurl,15,vimage)		
### end ###		
	
def EPISODE_KH(url,name):    
	link = OpenURL(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\t','')
	match=re.compile('<script language="javascript" type="text/javascript">(.+?)</script>').findall(newlink)
	match=re.compile('{\s*"file":\s*"(.+?)","title":\s*"(.+?)",').findall(match[0])
	for vurl,vname in match:
		addLink(vname,vurl,4,'')
	xbmcplugin.endOfDirectory(pluginhandle)  
	
def get_link(url, movie):
    if xbmcaddon.Addon(id='service.liveproxy'):
        command = 'streamlink --player-passthrough hls --http-header "Origin=%s" %s best' % (movie, url)
        return "http://127.0.0.1:53422/base64/%s" % base64.b64encode(command)
    else:
        header = {
            'Origin': movie('originUrl'),
            'User-Agent': "Chrome/59.0.3071.115 Safari/537.36",
            'Referrer': movie('originUrl')
        }

    return url + "|%s" % urlencode(header)	
		
############## drama4khmers SITE ****************** 			   
def INDEX_KHDRAMA(url): 
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()    
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-sm-4 portfolio-item"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,25,vImage)
         try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('li')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8") ,('http://www.thekomsan.com/' + pageurl.encode("utf-8")),21,"")		 
         except:pass   
		 
### SEARCH ###
def SINDEX_KHDRAMA(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()      
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-sm-4 portfolio-item"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             vTitle = BeautifulSoup(str(link))('img')[0]['alt']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle.replace("&euro;&lsaquo;","")+'[COLOR red] DRAMA4K[/COLOR]',vLink,25,vImage)		 
## END ##		 

def EPISODE_KHD(url,name):    
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)"').findall(link)     
        if(len(match) > 0):      
         for vLink,vName in match:                 
          addLink(vName,vLink,4,'')
        else:
          match=re.compile('<a class=".+?" style="margin: 5px 0;" href="(.+?)">(.+?)</a>').findall(link)
          if(len(match) > 0):      
           for vLink,vName in match:
            addLink(vName.encode("utf-8"),vLink,3,'') 
	      
		 

############## cartoonson.tv SITE ****************** 
def INDEX_KID(url):     
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"image-overlay"})
        for link in div_index:            
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vImage = BeautifulSoup(str(link))('img')[0]['src']
            vTitle = BeautifulSoup(str(link))('img')[0]['title'].replace('Watch','')
            vTitle = vTitle.encode("UTF-8",'replace')
            addDir(vTitle,vLink,85,vImage)
        try:
           paging = soup('ul',{'class':'pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&raquo;","Next").replace("&laquo;","Prev")
             addDir(" Page " + pagenum.encode("utf-8") ,pageurl,81,"")
        except:pass 	
	
def PLAY_KID(url,name): 
    link = OpenURL(url)
    match=re.compile('>\n(.+?)</a>\n<a\nhref="(.+?)"').findall(link.replace('\t',''))
    for vname,vurl in match:
        addDir(vname,vurl,86,'')
    else:
     match=re.compile('data-src="(.+?)"[^>]*>\n</a><h3 class="text-center" ><a\nhref="(.+?)">(.+?)</a></h3></div>').findall(link)
     for vimage,vurl,vname in match:
         addDir(vname,vurl,87,vimage)
     else:
      match=re.compile('<a\nhref="(.+?)" class="btn btn-primary btn-lg"').findall(link.replace('-preview',''))
      for vurl in match:
          link2 = OpenURL(vurl) 
          match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link2)
          for vlink in match:
              addLink('Server 1',vlink,4,'')
          else:
           match=re.compile('<li>\n<a\nhref="(.+?)" >.+?</a></li></ul>').findall(link2)
           for URL in match:
               link = OpenURL(URL)
               match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link)
               for vlink in match:
                   addLink('Server 2',vlink,4,'')				  
           else: 
            match=re.compile('<source\n[^>]*src="(.+?)"').findall(link2)
            if(len(match) > 0):
             counter = 0      
             for vLink in match:
              counter += 1 
              addLink("Server "+str(counter),vLink,4,'')		   
				  
def PLAY_KID2(url,name):
    link = OpenURL(url)
    match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link)
    for vlink in match:
        addLink(name,vlink,4,'')

def EPISODE_KID(url,name):
    link = OpenURL(url)
    match=re.compile('\n(.+?)</a>\n<a\nhref="(.+?)" class="pull-right play-episode-btn btn btn-default">').findall(link.replace('-preview',''))
    for vname,vurl in match:
        link2 = OpenURL(vurl) 
        match=re.compile('<iframe\n[^>]*src="(.+?)"').findall(link2)
        for vlink in match:
            addLink(vname.replace('\t','').replace('&amp;','&'),vlink,4,'')			  

############## MOVIE-KHMER SITE ****************** 
def INDEX_PHUMIHD(url):
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"featured featured-type-featured-image"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('a')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('a')[0]['data-src']
             print vImage.encode("UTF-8")
             addDir(vTitle,vLink,95,vImage)
         try:
           paging = soup('div',{'class':'pagination bs-numbered-pagination'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum,pageurl,91,"")		 
         except:pass
		 
## SEARCH ##
def SINDEX_PHUMIHD(url):
         referer = {1:url}
         pickle_out = open(dpath+"dict.pickle","wb")
         pickle.dump(referer, pickle_out)
         pickle_out.close()   
         html = OpenSoup(url)
         try:
             html = html.encode("UTF-8")
         except: pass
         soup = BeautifulSoup(html.decode('utf-8'))
         div_index = soup('div',{"class":"col-lg-3 col-md-3 col-sm-3 col-xs-6"})
         for link in div_index:
             vLink = BeautifulSoup(str(link))('a')[0]['href']
             print vLink
             vTitle = BeautifulSoup(str(link))('img')[0]['title']
             vTitle = vTitle.encode("UTF-8",'replace')
             vImage = BeautifulSoup(str(link))('img')[0]['src']
             print vImage.encode("UTF-8")
             addDir(vTitle+'[COLOR red] MOVIE-KHMER[/COLOR]',vLink,95,vImage)	
##END ##		 
						
def EPISODE_PHUMIHD(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass
        match=re.compile('{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)",').findall(link)     
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName,vLink,4,'')	

############## video4khmer1 SITE ****************** 
def INDEX_VIDEO4U(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html.decode('utf-8'))
        div_index = soup('div',{'class':"post-thumb-inner"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('a')[0]['title']
            vTitle = vTitle.encode("UTF-8",'replace')
            #vImage = BeautifulSoup(str(link))('div')[1]['style']
            #addDir(vTitle,vLink,105,vImage.replace('background-image: url(',''))            
            vImage = BeautifulSoup(str(link))('div')[0]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle,vLink,105,vImage)
        try:
           paging = soup('ul',{'class':'pagination m-0 mt-3'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0]
             addDir(" Page " + pagenum.encode("utf-8").replace("fas fa-angle-left","").replace("fas fa-angle-double-left","").replace("fas fa-angle-right","").replace("fas fa-angle-double-right","").replace("i class=","").replace("</i>","").replace("<","").replace(">","").replace("",""),pageurl,101,"")
        except:pass			
     
def EPISODE_VIDEO4U(url,name):
    #try:
        link = OpenSoup(url)
        try:
            link =html.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        listcontent=soup.findAll('div', {"class" : "row"})
        for item in listcontent[1].findAll('div', {"class" : "col-6 col-md-4 post-col"}):
			vname=item.a["title"]
			vname = vname.encode("UTF-8",'replace') 
			vurl=item.a["href"]
			#vimg=item.div["style"]
			addLink(vname,vurl,3,"")
        try:
           paging = soup('ul',{'class':'pagination m-0 mt-3'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0]
             addDir(" Page " + pagenum.encode("utf-8").replace("fas fa-angle-left","").replace("fas fa-angle-double-left","").replace("fas fa-angle-right","").replace("fas fa-angle-double-right","").replace("i class=","").replace("</i>","").replace("<","").replace(">",""),pageurl,105,"")
        except:pass


############## Khmeravenue SITE ****************** 		  
def INDEX_MERLKON(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html, 'html.parser')
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0].replace("&#8217;","")
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle,vLink,135,vImage)            
				#addDir(vTitle,vLink.replace('album','videos')[:-01]+"-02/",135,vImage)
        try:
           paging = soup('div',{'class':'wp-pagenavi'})
           pages = BeautifulSoup(str(paging[0]))('a')
           for p in pages:
             psoup = BeautifulSoup(str(p))
             pageurl = psoup('a')[0]['href']
             pagenum = psoup('a')[0].contents[0].replace("&laquo;",">").replace("&raquo;","<")
             addDir(" Page " + pagenum.encode("utf-8"),pageurl,131,"")
        except:pass 

### search ###
def SINDEX_KHMERSTREAM(url):
        referer = {1:url}
        pickle_out = open(dpath+"dict.pickle","wb")
        pickle.dump(referer, pickle_out)
        pickle_out.close()
        html = OpenSoup(url)
        try:   
           html =html.encode("UTF-8")
        except: pass
        soup = BeautifulSoup(html, 'html.parser')
        div_index = soup('div',{'class':"col-6 col-sm-4 thumbnail-container"})
        for link in div_index:
            vLink = BeautifulSoup(str(link))('a')[0]['href']
            vTitle = BeautifulSoup(str(link))('h3')[0].contents[0].replace("&#8217;","")
            vTitle = vTitle.encode("UTF-8",'replace')
            vImage = BeautifulSoup(str(link))('div')[1]['style']
            match = re.compile('url\((.+?)\)').findall(vImage)
            for vImage in match:
				addDir(vTitle+'[COLOR red] KHMERAVE[/COLOR]',vLink,135,vImage)

### end ###			
def EPISODE_MERLKON(url,name):
        link = OpenURL(url)
        try:
             link = link.encode("UTF-8")
        except: pass 
        match=re.compile('<td><a href="(.+?)"><i class=".+?" style=".+?"></i>(.+?)</a></td>').findall(link)
        if(len(match) > 0):      
         for vLink,vLinkName in match:                 
          addLink(vLinkName.replace('Episode','Part'),vLink,3,'')
                  
##########
		
def OpenXML(Doc):
    document = xml.dom.minidom.parseString(Doc)      
    items = document.getElementsByTagName('item')
    for itemXML in items:
     vname=itemXML.getElementsByTagName('title')[0].childNodes[0].data
     vpart=itemXML.getElementsByTagName('description')[0].childNodes[0].data
     vImage=itemXML.getElementsByTagName('jwplayer:image')[0].childNodes[0].data
     vurl=itemXML.getElementsByTagName('jwplayer:source')[0].getAttribute('file')     
     addLink(vpart.encode("utf-8"),vurl.encode("utf-8"),4,"")           

def VIDEOLINKS(url):              
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link.replace('=m37','=m18')) 
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):   
                            match=re.compile('playlist: "(.+?)"').findall(link)# Good Link
                            if(len(match) == 0):
                             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# KhmerTV
                             if(len(match) == 0):							
                              match = re.compile('<iframe[^<]+src="(.+?)"').findall(link.replace('=m37','=m18')) 
                              if(len(match) == 0): 							 
                               match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                               for url in match:
                                vid = url[0].replace("['']", "")       
                                match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                                #REAL_VIDEO_HOST(match)
                                VIDEO_HOSTING(match)
                                print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
    
def VIDEO_HOSTING(vlink):
           if 'khmotions.com' in vlink:   
                VideoURL = KHMOTIONS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Khmotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'kolabkhmer.club' in vlink:
                VideoURL = KOLABKHMERS(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Kolabkhmer Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'kolabkhmer.html' in vlink:                   
                VideoURL = KHMER7(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Khmer7 Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'dailymotion.com' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'estream.to' in vlink:   
                VideoURL = ESTREAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Estream Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'fembed.com' in vlink:
                VideoURL = FEMBED(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Fembed Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'google.com' in vlink:   
                VideoURL = GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)	

           elif 'k-vid.net' in vlink:   
                VideoURL = KVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,K-vid Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'movie-khmer.com' in vlink:   
                VideoURL = MOVIEKHMER(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Subkh Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Mp4upload Loading selected video)")
                Play_VIDEO(VideoURL)				
		
           elif 'ok.ru' in vlink:
                VideoURL = OKRU(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,OK Loading selected video)")
                Play_VIDEO(VideoURL)	
				
           elif 'openload.co' in vlink:   
                VideoURL = OPENLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Openload Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'rapidvideo.com' in vlink:   
                VideoURL = RAPIDVIDEOCOM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Rapidvideo Loading selected video)")
                Play_VIDEO(VideoURL)				

           elif 'streamango.com' in vlink:   
                VideoURL = STREAMANGO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Streamango Loading selected video)")
                Play_VIDEO(VideoURL)		

           elif 'subkh.com' in vlink:   
                VideoURL = SUBKH(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Subkh Loading selected video)")
                Play_VIDEO(VideoURL)				
				
           elif 'vev.io' in vlink:   
                VideoURL = VEVIO(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vevio Loading selected video)")
                Play_VIDEO(VideoURL)				
     
           elif 'vimeo.com' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)
				 
           elif 'vidlox.me' in vlink:
                 VideoURL = VIDLOX(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vidlox Loading selected video)")
                 Play_VIDEO(VideoURL)	

           elif 'xstreamcdn.com' in vlink:
                 VideoURL = XSTREAMCDN(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,xStreamcdn Loading selected video)")
                 Play_VIDEO(VideoURL)				 

           elif 'youtube.com' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)        
       
           else:
                print 'VideoURL: %s' % vlink
                xbmc.executebuiltin("XBMC.Notification(Please Wait!, KonJen is loading...)")
                Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def GetContent2(url,referr, cj):
    if cj is None:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [(
        'Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Referer', referr),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')]
    usock = opener.open(url)
    if usock.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(usock.read())
        f = gzip.GzipFile(fileobj=buf)
        response = f.read()
    else:
        response = usock.read()
    usock.close()
    return (cj, response)
	
def KHMOTIONS(SID):
	req = urllib2.Request(SID)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()    
	match720p = re.compile('file:\s"(.+?)",.+?720.+?"', re.DOTALL).findall(link)
	match480p = re.compile('file:\s"(.+?)",.+?480.+?"', re.DOTALL).findall(link)
	match360p = re.compile('file:\s"(.+?)",.+?360.+?"', re.DOTALL).findall(link)
	match240p = re.compile('file:\s"(.+?)",.+?240.+?"', re.DOTALL).findall(link)
	matchSD = re.compile('file : "(.+?)"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	elif matchSD:
		VideoURL = matchSD[0]
	return VideoURL			

def KOLABKHMERS(SID):
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        VideoURL =  re.compile('"file":"(.+?)"').findall(link.replace('\/','/'))[0]
        return VideoURL	
		
def KHMER7(SID):
	media_id =re.compile("slug=(.+?)&").findall(SID)[0]
	headers = {'Referer': 'https://www.kolabkhmer.com/kolabkhmer.html', 'User-Agent': 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'}
	link = requests.get(SID, headers=headers).content
	key= re.compile('key: "(.+?)",').findall(link)[0]
	data = {'key':key,'type':'slug','value':media_id,'dataType':'m3u8'}
	url2 = requests.post("https://multi.idocdn.com/vip", data=data).content
	vid = re.compile('"link":"(.+?)",').findall(url2)[0]
	origin = 'https://www.kolabkhmer.com'
	VideoURL = get_link(vid, origin)
	return VideoURL			

def DAILYMOTION(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def ESTREAM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL		

def FACEBOOK(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	

def FEMBED(Video_ID):
	media_id = re.compile("fembed.com/v/(.+)").findall(Video_ID)[0]
	SID = 'https://www.fembed.com/api/source/%s' % media_id
	link = requests.post(SID).content
	match720p = re.compile('"file":"(.+?)".+?"720p"', re.DOTALL).findall(link)
	match480p = re.compile('"file":"(.+?)".+?"480p"', re.DOTALL).findall(link)
	match360p = re.compile('"file":"(.+?)".+?"360p"', re.DOTALL).findall(link)
	match240p = re.compile('"file":"(.+?)".+?"240p"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	return VideoURL.replace('\/','/')

def GOOGLE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def KVID(SID):
		link = OpenURL(SID)
		URL=re.compile('window.location = "(.+?)"').findall(link)[0]
		VideoURL = resolveurl.resolve(URL)
		return VideoURL	
		
def MOVIEKHMER(SID):
	headers = {'Referer': 'https://movie-khmer.com', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'}
	link = requests.get('https:'+SID, headers=headers).content 
	VideoURL=re.compile('file:"(.+?)"').findall(link)[0]
	headers.update({'verifypeer': 'false'})
	return VideoURL+'|'+urlencode(headers)		

def MP4UPLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def OKRU(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 

def OPENLOAD(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL			

def RAPIDVIDEOCOM(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def STREAMANGO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
def SUBKH(SID):
	headers = {'Referer': 'https://www.khmotions.com', 'User-Agent': 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'}
	link = requests.get(SID, headers=headers).content
	code = dodge.resolver(link)
	VideoURL=re.compile('"file":"(.+?)"').findall(code)[0]
	return(VideoURL+'|Referer='+SID)	

def VEVIO(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL  		
		
def VIDLOX(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 		
		
def VIMEO(Video_ID):
        pickle_in = open(dpath+"dict.pickle","rb")
        referer = pickle.load(pickle_in)
        Referer = (referer[1])
        HomeURL = ("http://"+Video_ID.split('/')[2])
        if 'player' in Video_ID:
            media_id =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
        elif 'vimeo' in Video_ID:
              media_id =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
        SID = "https://player.vimeo.com/video/%s?api=1&amp;player_id=video_player" % media_id[0]  
        headers = {'Referer': Referer}
        link = requests.get(SID, headers=headers)
        VideoURL = re.compile('"hls"[^>]*"akfire_interconnect_quic":{"url":"(.+?)"').findall(link.content)[0]
        return VideoURL	
		
def XSTREAMCDN(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL	 
	
def YOUTUBE(SID):
        VideoURL = resolveurl.resolve(SID)
        return VideoURL 
		
###################### Resolver End  ###################   
     
def addLink(name,url,mode,iconimage):
### added download popup
        u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&title="+urllib.quote_plus(name)+"&thumb="+urllib.quote_plus(iconimage)
        ok = True
        contextMenuItems = []
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name})
        liz.setProperty('IsPlayable', 'true')
        contextMenuItems.append(('Download', 'XBMC.RunPlugin(plugin://plugin.video.khmerdl?url=%s&mode=%s&name=%s)'%(urllib.quote_plus(url),mode,urllib.quote_plus(name))))
        contextMenuItems.append(('Download Manager', 'XBMC.RunScript(script.module.youtube.dl)'))
        liz.addContextMenuItems(contextMenuItems)
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
        return ok		
###
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://3.bp.blogspot.com/-wqpOG9eFzYQ/U1aOJ6I21lI/AAAAAAAADwg/TDo9luPxcWA/w263-h155-no/button.next.bue.arrow.gif", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    

params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	
		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)        
elif mode==5:
        SEARCH()	
	
elif mode==11:
        INDEX_KHMOTION(url)    
elif mode==15:
        EPISODE_KH(url,name)
elif mode==21:
        INDEX_KHDRAMA(url)    
elif mode==25:
        EPISODE_KHD(url,name)	
elif mode==81:
        INDEX_KID(url) 		
elif mode==85:
        PLAY_KID(url,name)
elif mode==86:
        PLAY_KID2(url,name)		
elif mode==87:
        EPISODE_KID(url,name)
elif mode==91:
        INDEX_PHUMIHD(url)    
elif mode==95:
        EPISODE_PHUMIHD(url,name)		
elif mode==101:
        INDEX_VIDEO4U(url)    
elif mode==105:
        EPISODE_VIDEO4U(url,name)
elif mode==131:
        INDEX_MERLKON(url)    
elif mode==135:
        EPISODE_MERLKON(url,name)	      
elif mode==151:
        INDEX_KM168(url)    
elif mode==155:
        EPISODE_KM168(url,name)			
elif mode==181:
        INDEX_CITY(url)    
elif mode==185:
        EPISODE_CITY(url,name)	
			      
xbmcplugin.endOfDirectory(int(sysarg))
        