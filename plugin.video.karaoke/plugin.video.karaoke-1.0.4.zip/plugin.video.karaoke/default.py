# -*- coding: utf-8 -*-


import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.karaoke'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Tonsaay Karaoke
YOUTUBE_CHANNEL_ID_1 = "UUBtrs7T6C2oUBLcKD8OaVVg" 	
YOUTUBE_CHANNEL_ID_2 = "PLZkt3klVIdkv4pLUlUTlm3hQ0Eh6K9Erp" 	
YOUTUBE_CHANNEL_ID_3 = "PLZkt3klVIdks8w60FEpanyba7_rogGJPe" 	
YOUTUBE_CHANNEL_ID_4 = "PLZkt3klVIdkstfgpNroo0xTdl9eeXh_6N" 
YOUTUBE_CHANNEL_ID_5 = "PLZkt3klVIdkvq4Ynf6jBpUfQZQ0BIiQ5B" 
YOUTUBE_CHANNEL_ID_6 = "PL29FFF5D546179BE5" 
YOUTUBE_CHANNEL_ID_7 = "UC5lBH5Q2up9C29UuPUt6ALA" 

YOUTUBE_CHANNEL_ID_8 = "PL0jG7kt_U1jlmjbGxv7r_7sSk-13wRNJF" 
YOUTUBE_CHANNEL_ID_9 = "PL0jG7kt_U1jn6IJM0eAlEPkeBDzgviFIG" 
YOUTUBE_CHANNEL_ID_10 = "PL0jG7kt_U1jm359FqcjOdN1_MOKnkEBDJ" 

YOUTUBE_CHANNEL_ID_11 = "UCBKNhE4weHAj-w2Aiqg0kgA" 
YOUTUBE_CHANNEL_ID_12 = "UCwTHlNgKDKCYzerMVRwuOZQ" 
YOUTUBE_CHANNEL_ID_13 = "UCxg0eOCQBKG-P28mnDlFQMA" 
YOUTUBE_CHANNEL_ID_14 = "UCmeOImKUaJNV7R_MJJmX5nA" 
YOUTUBE_CHANNEL_ID_15 = "UCkaX7VKW1einqnKgIJUosKg" 
YOUTUBE_CHANNEL_ID_16 = "UCaU4xBD5z7UKOfLSe7XaIpQ" 
YOUTUBE_CHANNEL_ID_17 = "UCMo69sx4BqmRYJrLEa7OVvg" 
YOUTUBE_CHANNEL_ID_18 = "UCocl4hMfO53I-YrbdY6nvVA" 
YOUTUBE_CHANNEL_ID_19 = "UCSeTx2Js9UNPBzAuda-Vq6w" 
YOUTUBE_CHANNEL_ID_20 = "UCofTRHJJldLw90OANSN4vtA" 

YOUTUBE_CHANNEL_ID_21 = "UUwTRjvjVge51X-ILJ4i22ew" 

YOUTUBE_CHANNEL_ID_22 = "PLZkt3klVIdku1YXwbMAhEq4Ezt3IfjAEb" 
YOUTUBE_CHANNEL_ID_23 = "PLZkt3klVIdksNp37Kmygl0TrgxXLlWV_F" 
YOUTUBE_CHANNEL_ID_24 = "PLZkt3klVIdkv2wRk1OygY3u45_drzqdAK" 
YOUTUBE_CHANNEL_ID_25 = "PLZkt3klVIdkshvAIjWethqyTNqUVFsQov" 
YOUTUBE_CHANNEL_ID_26 = "PLZkt3klVIdku9IW4wQ5AShCcttlFw5PYo" 
YOUTUBE_CHANNEL_ID_27 = "UUM6unVkIvWsIuL4zQBp-cuw" 
YOUTUBE_CHANNEL_ID_28 = "PLii-MS7JD3agEUGoP4Oiw6KdlxW8mGtX9"


#YOUTUBE_CHANNEL_ID_7 = "" 



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="English Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-GA1xxmp0Ac2uXESBwuu4g4B3GId8KZTRbJw=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="Variety Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-25aExaF43bK8eO7288nPIb1QYj0MsS8AY6A=s288-c-k-c0xffffffff-no-rj-mo",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Khmer-Glish Karaoke",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_To79Qt2bgbU2rRhUcCwp2gozMwu4Ec1Dj=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="Karaoke Mix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.ytimg.com/vi/bQagcQ1gw8I/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAIIT3ePE7uhMUUchVZQzwjPNOKMQ",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Sinn Sisamouth",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="http://3.bp.blogspot.com/_8b4R5sEznho/R2TXT1p5O7I/AAAAAAAAAzY/q9yO911n9Bs/s400/Sinn.sisamouth.jpg",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Ros Serey Sothea",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://img.discogs.com/dP-bE4APqkBpoyNAPpoMB4oquho=/fit-in/300x300/filters:strip_icc():format(jpeg):mode_rgb():quality(40)/discogs-images/A-1075094-1490641478-9507.jpeg.jpg",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Pan Ron",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://img.discogs.com/-zStLefCyJRZXAJ48pkNsIq3kwg=/fit-in/300x300/filters:strip_icc():format(jpeg):mode_rgb():quality(40)/discogs-images/A-1100716-1490641421-9519.png.jpg",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Keo Sarat",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://3.bp.blogspot.com/-j0jhAkFE660/Wjaw9T_3vpI/AAAAAAAAUpg/YzSa7TVgxh8cECrQh29dzPAxjQXvu3_eACLcBGAs/s1600/Collection%2Bof%2BKeo%2BSarath.jpg",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Romvong",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/vi/84LwpZouYPg/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAX2CwOI_VuENZR1HqG7CuD_JKbQw",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Cha Cha",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://i.ytimg.com/vi/eVSZ2VhVmac/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDZIl8Tj3emFryB4MHNAeIxHndB-Q",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Duet",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.ytimg.com/vi/YWHKGdi_9tM/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCDoExvrrsMxy1CWU-4OfEWsx0INQ",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Saravan",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://i.ytimg.com/vi/JmOK_7D072I/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCmOQSDzt9DMhN2RDKnpRVqJH_2Mg",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Kontrem",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.ytimg.com/vi/pKPcrjKSRSE/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCU9Ztt1Kb0Em7x8NDaKp0ExWIb0A",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Chlangden Collection",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://i.ytimg.com/vi/7US7mCHHA6Y/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLApdwaDoLddfcBM8qXRdTVv3BWEhA",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="DomPic Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAykpBXV6GDwCKWvEOCcNS3CZFW91FSz2ryvng=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Duet2",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.ytimg.com/vi/QXArssZW0L8/hqdefault.jpg?sqp=-oaymwEiCKgBEF5IWvKriqkDFQgBFQAAAAAYASUAAMhCPQCAokN4AQ==&rs=AOn4CLDrBIv2N5l0X_JeL8SBYuwM-OSn4Q",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Male",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.ytimg.com/vi/f1Ga41jKbKc/hqdefault.jpg?sqp=-oaymwEiCKgBEF5IWvKriqkDFQgBFQAAAAAYASUAAMhCPQCAokN4AQ==&rs=AOn4CLAN2b5eNtrJVq2VOi8lbI7cGYtOCA",
		fanart="",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="Female",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://i.ytimg.com/vi/-DNr5jdbhhM/hqdefault.jpg?sqp=-oaymwEiCKgBEF5IWvKriqkDFQgBFQAAAAAYASUAAMhCPQCAokN4AQ==&rs=AOn4CLAIx53xiJ8NNSI8H0YogfjQ6hhDgg",
		fanart="",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="KH4Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAzsEccTKyrBNaVTVI1uQzwpw65EyHtB_QtGCQ=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="Kolab Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAyaZsApGRzue0ouOU-dYx-MMsD35_PTLikBlg=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="KlorngMeas Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAyGIcp7jeOap_p46pU7gNxN1DyF-a6d8BxCwA=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )			
				
    plugintools.add_item( 
        #action="", 
        title="Meas Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAzJ4PAA8NnME3kuRxJ6tU5etasZXLinJ2YK4w=s48-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )					
		
    plugintools.add_item( 
        #action="", 
        title="PlengSot karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAwa4baN90_Y82K4QdURuBHNRcoKdAB9fbOjQA=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Kamsan Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAy7z4864e488XHWeUm1NQFsU9RnoZlI5XmrBA=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Sarika Dontrey Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAzEtQJwbvBXlzeceslTSBkbcedKtKMakPhS8Q=s48-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Mohanokor Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAzc4aOkdguq2eTcrkmG1MUlRvyrTDhadyHQcQ=s288-mo-c-c0xffffffff-rj-k-no",
		fanart="",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Panharath Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.ytimg.com/vi/XeeasaK31q8/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLA109dDL9eLxwAKRNZBesSr9-R6ig",
		fanart="",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="KaroNa Karaoke",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.ytimg.com/vi/Ee-Oy_7j6bo/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBbVZX-cNzuMQOM6FJnvNV8F88PCQ",
		fanart="",
        folder=True )		
		
run()
