# -*- coding: utf-8 -*-


import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.movieMV'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Tonsaay Karaoke
YOUTUBE_CHANNEL_ID_1 = "UCAbHU5C61UNjwPV8MF5b2Bg/playlists" 
YOUTUBE_CHANNEL_ID_4 = "UUHwYHdX37UUt6d9e1wAp9Bw"	
YOUTUBE_CHANNEL_ID_2 = "UCJMJEBLhYT8VCVy0K82omfg/playlists"
YOUTUBE_CHANNEL_ID_3 = "UUKRp5dNEBko_xLYf_kHuZcw"



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Cambodia TVB",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJzLK64Qi1ae65tOM_HhncrlJ5CWyuCLLyLbMA=s100-c-k-c0xffffffff-no-rj-mo",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Hang Meas MV",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJw3ltFA66aKB-XycqiQdi_VaOJn8crIJc87-g=s100-c-k-c0xffffffff-no-rj-mo",
		fanart="",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="Thailand TVB",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz1CiZ2HCZcCGPaiju7YPhKzbzJ-g_DwTNj2g=s100-c-k-c0xffffffff-no-rj-mo",
		fanart="",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="Thailand MV",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/a/AATXAJz-fLT8XAwst2hMOBqZXuu8H9pS3d5oyeU6Eg=s100-c-k-c0xffffffff-no-rj-mo",
		fanart="",
        folder=True )		
		
			
	
		
run()
