# ── Compatibility & Imports ─────────────────────────────────────
import sys
import os
import re
import ast
import json
import gzip
import time
import random
import base64
import string
import requests
import xml.dom.minidom
import xml.etree.ElementTree as ET

# ── Kodi Modules ────────────────────────────────────────────────
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ── External Libraries ──────────────────────────────────────────
import resolveurl
from bs4 import BeautifulSoup
from urllib.parse import urlparse, quote_plus, unquote_plus, urljoin
from html import unescape as html_unescape
from resources.lib.constants import khmertv

# --- HTTP session (connection reuse) ---
_SESSION = requests.Session()

# --- tiny negative cache for 404/410 ---
_NEG_CACHE = {}      # url -> expiry_ts
_NEG_TTL   = 300     # 5 minutes
_NEG_MAX   = 512     # cap entries to avoid unbounded growth

def _neg_cached(url):
    exp = _NEG_CACHE.get(url)
    if exp and exp > time.time():
        xbmc.log(f"[{ADDON_ID}] NEG-CACHE hit: {url}", xbmc.LOGDEBUG)
        return True
    if exp:
        _NEG_CACHE.pop(url, None)
    return False

def _neg_save(url):
    # simple size cap
    if len(_NEG_CACHE) >= _NEG_MAX:
        # drop an arbitrary expired or the oldest-ish key
        try:
            stale = min(_NEG_CACHE.items(), key=lambda kv: kv[1])[0]
            _NEG_CACHE.pop(stale, None)
        except ValueError:
            _NEG_CACHE.clear()
    _NEG_CACHE[url] = time.time() + _NEG_TTL
    
# ── Add-on Constants ────────────────────────────────────────────
ADDON_ID      = 'plugin.video.KDubbed'
ADDON         = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PATH    = ADDON.getAddonInfo('path')
DATA_PATH     = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])

# ── User Agent ──────────────────────────────────────────────────
MODERN_UA  = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
USER_AGENT = MODERN_UA

# ── Base URLs ───────────────────────────────────────────────────
VIDEO4KHMER  = 'https://www.video4khmer36.com/'
PHUMIK       = 'https://www.phumikhmer1.club/'
KHMERAVENUE  = 'https://www.khmeravenue.com/'
MERLKON      = 'https://www.khmerdrama.com/'
CKCH7        = 'http://www.ckh7.com/'
SUNDAY       = 'https://www.sundaydrama.com/'
VIP          = 'https://phumikhmer.vip/'
IDRAMA       = 'https://www.idramahd.com/'

# ── Icons and Fanart ────────────────────────────────────────────
IMAGE_PATH     = os.path.join(ADDON_PATH, 'resources', 'images')
ICON_JOLCHET   = os.path.join(IMAGE_PATH, 'icon.png')
ICON_SEARCH    = os.path.join(IMAGE_PATH, 'search1.png')
ICON_KHMERTV   = os.path.join(IMAGE_PATH, 'khmertv.png')
FANART         = os.path.join(IMAGE_PATH, 'fanart.jpg')
ICON_KHMERAVE  = "https://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png"
ICON_MERLKON   = "https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png"
ICON_VIP       = "https://raw.githubusercontent.com/goupon/file/master/logo/vip.jpg"
ICON_SUNDAY    = "https://raw.githubusercontent.com/goupon/file/master/logo/SD.jpg"
ICON_IDRAMA    = "https://www.idramahd.com/wp-content/uploads/2024/12/idramahd-Black.png"

# ── Utility Functions ───────────────────────────────────────────
def OpenURL(url, headers=None, user_agent=None, timeout=(5, 10), retries=2, delay=1.5, as_text=False):
    empty = '' if as_text else b''
    if _neg_cached(url):
        return empty

    h = {'User-Agent': user_agent or USER_AGENT, 'Accept-Encoding': 'gzip, deflate'}
    if headers:
        h.update(headers)

    for a in range(1, retries + 1):
        try:
            r = _SESSION.get(url, headers=h, timeout=timeout)
            sc = r.status_code

            if sc in (404, 410):
                _neg_save(url); return empty
            if sc == 429 and a < retries:
                time.sleep(1.0); continue
            if 400 <= sc < 500:
                return empty

            r.raise_for_status()
            return r.text if as_text else r.content

        except requests.exceptions.RequestException as e:
            xbmc.log(f"[{ADDON_ID}] Network error (attempt {a}) on {url}: {e}", xbmc.LOGWARNING)
            if a == retries:
                return empty
            time.sleep(delay + random.uniform(0, 0.5))


def OpenSoup(url, return_html=False, **kwargs):
    html = OpenURL(url, as_text=True, **kwargs)
    if not html:
        raise Exception(f"Empty or failed response from URL: {url}")
    soup = BeautifulSoup(html, "html.parser")
    return (soup, html) if return_html else soup


# ── Virtual Keyboard Input ──────────────────────────────────────
def GetInput(message, heading, is_hidden=False):
    keyboard = xbmc.Keyboard('', message, is_hidden)
    keyboard.setHeading(heading)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ""


# Main Menu
def HOME():
    addDir("[COLOR yellow][B][I]SEARCH[/I][/B][/COLOR]", MERLKON, "search", ICON_SEARCH)
    addDir("Khmer Live TV", khmertv, "khmer_livetv", ICON_KHMERTV)

    # Structured site definitions
    sites = [
        {
            "title": "Vip • Sunday • iDrama • KhmerAve • Merlkon",
            #"action": "index_khmeravenue",
            "categories": [
                ("VIP", f"{VIP}", ICON_VIP, "index_vip"),            
                ("Sunday", f"{SUNDAY}", ICON_SUNDAY, "index_sunday"),
                ("iDrama", f"{IDRAMA}", ICON_IDRAMA, "index_idrama"),                
                ("KhmerAve", f"{KHMERAVENUE}album/", ICON_KHMERAVE, "index_khmeravenue"),
                ("Merlkon", f"{MERLKON}album/", ICON_MERLKON, "index_merlkon")  
            ]
        },       
        {
            "title": "Video4Khmer",
            "logo": "https://www.video4khmer36.com/templates/pkakrovan/images/all/logo.png",
            "action": "index_video4u",
            "categories": [
                ("Cambodia", f"{VIDEO4KHMER}khmer-movie-category/khmer-drama-watch-online-free-catalogue-504-page-1.html"),
                ("Chinese Aired", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html"),
                ("Chinese Completed", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-watch-online-free-catalogue-506-page-1.html"),
                ("Thai Aired", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html"),
                ("Thai Completed", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html"),
                ("Korean Aired", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-to-be-continued-catalogue-508-page-1.html"),
                ("Korean Completed", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html")
            ]
        },
        {
            "title": "PhumiKhmer",
            "logo": "https://phumikhmer2.com/home/img/logo.png",
            "action": "index_phumik",
            "categories": [
                ("Thai", f"{PHUMIK}search/label/Thai?&max-results=24"),
                ("Chinese", f"{PHUMIK}search/label/Chinese?&max-results=24"),
                ("Korean", f"{PHUMIK}search/label/Korea?&max-results=24")
            ]
        },
        {
            "title": "Ckh7",
            "logo": "https://www.ckh7.com/uploads/custom-logo.png",
            "action": "index_ckch7",
            "categories": [
                ("Khmer", f"{CKCH7}category.php?cat=khmer"),
                ("Thai", f"{CKCH7}category.php?cat=thai"),
                ("Chinese", f"{CKCH7}category.php?cat=chinese")
            ]
        }       
    ]

    # ── Render all site headers and their categories ────────────
    for site in sites:
        header = f"============= [COLOR red] {site['title']} [/COLOR] ============="
        addDir(header, "", site.get('action', ''), site.get('logo', ''))

        for category in site.get('categories', []):
            if len(category) == 4:
                label, url, icon, action = category
            elif len(category) == 3:
                label, url, icon = category
                action = site.get('action', '')
            else:  # len == 2
                label, url = category
                icon = site.get('logo', '')
                action = site.get('action', '')

            addDir(label, url, action, icon)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# Search function    
def SEARCH():
    sources = [
        ("Ckh7",          lambda q: SINDEX_CKCH7(f'{CKCH7}search.php?keywords={quote_plus(q)}')),    
        ("iDrama",        lambda q: SINDEX_IDRAMA(f'{IDRAMA}?s={quote_plus(q)}')),          
        ("KhmerAvenue",   lambda q: INDEX_GENERIC(f'{KHMERAVENUE}?s={quote_plus(q)}', 'index_khmeravenue', label_suffix=" [COLOR yellow]KHMERAVE[/COLOR]")),
        ("Merlkon",       lambda q: INDEX_GENERIC(f'{MERLKON}?s={quote_plus(q)}', 'index_merlkon', label_suffix=" [COLOR cyan]MERLKON[/COLOR]")),
        ("PhumiKhmer",    lambda q: SINDEX_PHUMIK(f'{PHUMIK}search?q={quote_plus(q)}')),
        ("Sunday",        lambda q: SINDEX_SUNDAY(f'{SUNDAY}search?q={quote_plus(q)}')),   
        ("Video4Khmer",   lambda q: SEARCH_VIDEO4U(q)),       
        ("Vip",           lambda q: SINDEX_VIP(f'{VIP}?s={quote_plus(q)}')),      
        
    ]

    dialog = xbmcgui.Dialog()
    choice = dialog.select('Search From:', [label for label, _ in sources])
    if choice == -1:
        return
    keyboard = xbmc.Keyboard('', 'Enter Search Text')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    search_text = keyboard.getText()
    try:
        sources[choice][1](search_text)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[{ADDON_ID}] Search dispatch failed: {e}", xbmc.LOGERROR)
  

# KhmerTV
def KHMER_LIVETV():
    try:
        xml_data = OpenURL(base64.b64decode(khmertv).decode("utf-8"))
        if isinstance(xml_data, bytes):
            xml_data = xml_data.decode("utf-8", errors="ignore")
        xml_data = "\n".join(line.strip() for line in xml_data.splitlines() if line.strip())
        xml_data = re.sub(r'&(?!amp;|lt;|gt;|apos;|quot;)', '&amp;', xml_data)
        root = ET.fromstring(xml_data)
        items = root.findall(".//channel/item") or root.findall(".//item")
        if not items:
            raise Exception("No <item> found")
        xbmc.log(f"[{ADDON_ID}] Loaded {len(items)} channels", xbmc.LOGINFO)
        for item in items:
            title = item.findtext("title", "No Title").strip()
            url   = item.findtext("link", "").strip()
            icon  = item.findtext("thumbnail", "").strip() or ICON_KHMERTV
            resolve = item.findtext("resolve", "false").strip().lower() == "true"
            if not url:
                xbmc.log(f"[{ADDON_ID}] Missing URL for: {title}", xbmc.LOGWARNING)
                continue
            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
            li.getVideoInfoTag().setTitle(title)
            li.setProperty('IsPlayable', 'true' if resolve else 'false')
            action = "playloop" if resolve else "video_hosting"
            plugin_url = f"{sys.argv[0]}?action={action}&url={quote_plus(url)}"
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, not resolve)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] KHMER_LIVETV load failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Failed to load Live TV feed.")


############## VIDEO4KHMER ****************** 
def INDEX_VIDEO4U(url):
    _render_video4u_listing(url, label_suffix=None, include_pagination=True)

def SEARCH_VIDEO4U(search_term):
    url = f"https://www.video4khmer36.com/search.php?keywords={quote_plus(search_term)}&page=1"
    _render_video4u_listing(url, label_suffix=" [COLOR red]Video4Khmer[/COLOR]", include_pagination=False)

def _render_video4u_listing(url, label_suffix=None, include_pagination=True):
    soup, html = OpenSoup(url, return_html=True)
    
    for item in soup.find_all('div', class_='cover-item'):
        cover_thumb = item.find('div', class_='cover-thumb')
        if not cover_thumb:
            continue

        # Extract image from style
        style = cover_thumb.get('style', '')
        image = style.replace('background-image: url(', '').replace(')', '').strip()

        # Get <a> tag for title and link
        a_tag = cover_thumb.find('a', class_='hover-cover')
        if not a_tag:
            continue

        title = a_tag.get('title', 'No Title').strip()
        link  = a_tag.get('href', '').strip()

        # Extract episode text from the LAST video-stats span (if any)
        ep_text = ''
        stats = cover_thumb.find_all('div', class_='video-stats')
        for stat in stats:
            span = stat.find('span')
            if span and "Ep" in span.text:
                ep_text = span.get_text(strip=True)

        # Build final label
        label = f"{title} ({ep_text})" if ep_text else title
        if label_suffix:
            label += label_suffix

        addDir(label, link, "episode_players", image)

    # Pagination
    if include_pagination:
        for a in soup.select('ul.pagination a[href]'):
            page_url = a['href']
            page_num = re.sub(r'<i[^>]*></i>', '', a.decode_contents().strip())
            addDir(f"Page {page_num}", page_url, "index_video4u", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
    
def EPISODE_VIDEO4KHMER(url):
    html = OpenURL(url, as_text=True)
    if not html:
        xbmcgui.Dialog().ok("Error", "Failed to load Video4Khmer episode page.")
        return

    # --- Parse episodes ---
    soup = BeautifulSoup(html, "html.parser")
    episodes = {}
    for tr in soup.select("#episode-list tbody tr"):
        td = tr.find("td")
        if not td:
            continue
        a = td.find("a")
        title = a.get_text(strip=True) if a else td.get_text(strip=True)
        link = a["href"] if a else url
        m = re.search(r'(\d+)', title)
        ep_num = int(m.group(1)) if m else 0
        if ep_num and ep_num not in episodes:
            episodes[ep_num] = (title, link)

    # --- Show episodes or fallback ---
    if episodes:
        for ep_num in sorted(episodes):
            title, link = episodes[ep_num]
            addLink(title, link, "videolinks", "")
    else:
        xbmcgui.Dialog().ok("No Episodes Found", "No episode links detected on this page.")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)    
    
############## idrama ****************** 
def INDEX_IDRAMA(url):
    _render_idrama_listing(url)

def SINDEX_IDRAMA(url):
    _render_idrama_listing(url, label_suffix=" [COLOR green]iDrama[/COLOR]", include_pagination=False)

def _render_idrama_listing(url, label_suffix="", include_pagination=True):
    soup, _ = OpenSoup(url, return_html=True)
    grid = soup.select_one('div.posts-wrap.th-grid-3') or soup

    for art in grid.select('article.hitmag-post'):
        a = art.select_one('h3.entry-title a[href]')
        if not a:
            continue
        v_link, v_title = urljoin(url, a['href']), a.get_text(strip=True)

        img = art.select_one('.archive-thumb img')
        v_image = ""
        if img:
            v_image = img.get('data-src') or img.get('src') or ""
            if not v_image and img.get('srcset'):
                v_image = img['srcset'].split(',')[0].split()[0]
            if v_image:
                v_image = urljoin(url, v_image)
                v_image = re.sub(r'/s\d+(?:-[a-z]+)*/', '/s1600/', v_image)

        label = v_title + label_suffix  # suffix only shows in search
        addDir(label, v_link, "episode_players", v_image)

    if include_pagination:
        nxt = soup.find('link', rel='next')
        if nxt and nxt.get('href'):
            addDir("[B]NEXT PAGE ›[/B]", urljoin(url, nxt['href']), "index_idrama", "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
 
def EPISODE_TVSABAY(start_url): # iDrama -->t.co -->tvsabay
    html = OpenURL(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch Tvsabay page", xbmc.LOGERROR)
        return

    m = re.search(r'data-post-id=["\']?(\d+)', html)
    if not m:
        xbmc.log("[KDUBBED] No post-id found in Tvsabay page", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("No Episodes Found", "Tvsabay post-id not found.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    post_id = m.group(1)
    xbmc.log(f"[KDUBBED] Found Tvsabay post-id: {post_id}", xbmc.LOGINFO)

    blog_id = "8016412028548971199"
    feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
    xbmc.log(f"[KDUBBED] Fetching Blogger feed: {feed_url}", xbmc.LOGINFO)


    json_text = OpenURL(feed_url, as_text=True)
    try:
        data = json.loads(json_text)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to parse Tvsabay JSON: {e}", xbmc.LOGERROR)
        return

    content = data["entry"]["content"]["$t"]

    # Extract .m3u8
    streams = re.findall(r"https?://[^\s\"']+\.m3u8", content)

    if not streams:
        xbmcgui.Dialog().ok("No Video", "No playable source found on Tvsabay.")
        return

    for idx, s in enumerate(streams, 1):
        addLink(f"Episode {idx}", s, "play_direct", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_ONELEGEND(start_url):  # iDrama -->t.co -->OneLegend
    html = OpenURL(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch OneLegend page", xbmc.LOGERROR)
        return

    # Look for data-post-id in the HTML
    m = re.search(r'data-post-id=["\']?(\d+)', html)
    if not m:
        xbmc.log("[KDUBBED] No post-id found in OneLegend page", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("No Episodes Found", "OneLegend post-id not found.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    post_id = m.group(1)
    xbmc.log(f"[KDUBBED] Found OneLegend post-id: {post_id}", xbmc.LOGINFO)

    # OneLegend uses a different Blogger blog_id
    blog_id = "596013908374331296"
    feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
    xbmc.log(f"[KDUBBED] Fetching OneLegend Blogger feed: {feed_url}", xbmc.LOGINFO)

    json_text = OpenURL(feed_url, as_text=True)
    try:
        data = json.loads(json_text)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to parse OneLegend JSON: {e}", xbmc.LOGERROR)
        return

    content = data["entry"]["content"]["$t"]

    # Extract video links (.m3u8 or .mp4)
    streams = re.findall(r"https?://[^\s\"']+\.(?:m3u8|mp4)", content)

    if not streams:
        xbmcgui.Dialog().ok("No Video", "No playable source found on OneLegend.")
        return

    for idx, s in enumerate(streams, 1):
        addLink(f"Episode {idx}", s, "play_direct", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



############## vip ****************** 
def INDEX_VIP(url):
    _render_vip_listing(url) 

def SINDEX_VIP(url):
    _render_vip_listing(url, label_suffix=" [COLOR green]Vip[/COLOR]", include_pagination=False)

def _render_vip_listing(url, label_color=None, label_suffix="", include_pagination=True):
    soup, html = OpenSoup(url, return_html=True)

    # ------- 1 · Video cards -------------------------------------------------
    for art in soup.find_all('article', class_=re.compile(r'listing-item-grid')):
        h2_tag = art.find('h2', class_='title')
        a_tag = h2_tag.find('a') if h2_tag else None
        feat_a = art.select_one('div.featured a')

        if not (a_tag and feat_a):
            continue

        v_link  = urljoin(url, a_tag['href'])
        v_title = a_tag.get_text(strip=True)
        img_tag = art.select_one('div.featured img')
        v_image = feat_a.get('data-src') or (img_tag.get('src') if img_tag else "")
        v_image = urljoin(url, v_image) if v_image else ""
        v_image = re.sub(r'/s\d+(-[a-z]+)*/', '/s1600/', v_image) if v_image else v_image

        label = f"{v_title}{label_suffix}" if label_suffix else v_title
        if label_color:
            label = f"[COLOR {label_color}]{label}[/COLOR]"

        addDir(label, v_link, "episode_players", v_image)

    # ------- 2 · Pagination --------------------------------------------------
    if include_pagination:
        next_link = soup.find('link', rel='next')
        if next_link and next_link.get('href'):
            page_url = urljoin(url, next_link['href'])
            addDir("[B]NEXT PAGE ›[/B]", page_url, "index_vip", "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def EPISODE_CRAFT4U(start_url): # vip -->t.co -->craft4u
    html = OpenURL(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch Craft4u page", xbmc.LOGERROR)
        return

    m = re.search(r'craft4u\.top/([^/]+)-0*(\d+)/', html)
    if not m:
        xbmc.log("[KDUBBED] Could not extract series base name", xbmc.LOGERROR)
        return

    base_name = m.group(1)
    ep_numbers = re.findall(rf"{base_name}-0*(\d+)", html)
    max_ep = max(map(int, ep_numbers)) if ep_numbers else 1

    for ep in range(1, max_ep + 1):
        ep_url = f"https://www.craft4u.top/{base_name}-{ep:02d}/"
        addLink(f"Episode {ep}", ep_url, "craft4u_play", '')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def PLAY_CRAFT4U(ep_url):
    if "tvsabay.com" in ep_url:
        xbmc.log(f"[{ADDON_ID}] WARNING: PLAY_CRAFT4U called with Tvsabay URL ({ep_url}). "
                 f"This should go to play_direct instead.", xbmc.LOGWARNING)
        return

    html = OpenURL(ep_url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] Failed to load Craft4u episode page", xbmc.LOGERROR)
        return

    # Try iframe (ok.ru, youtube, etc.)
    iframe = re.search(r'<iframe[^>]+src=[\'"]([^\'"]+)', html, re.IGNORECASE)
    if iframe:
        vurl = iframe.group(1)
        xbmc.log(f"[{ADDON_ID}] Craft4u iframe found: {vurl}", xbmc.LOGINFO)
        VIDEO_HOSTING(vurl)
        return

    # Try JWPlayer "sources" style embed (new format)
    m = re.search(r'sources\s*:\s*\[\{file\s*:\s*"([^"]+)"', html, re.IGNORECASE)
    if m:
        vurl = m.group(1).replace("\\/", "/")
        xbmc.log(f"[{ADDON_ID}] Craft4u JWPlayer source: {vurl}", xbmc.LOGINFO)
        vurl = f"{vurl}|Referer=https://www.craft4u.top/&User-Agent={USER_AGENT}"
        Play_VIDEO(vurl)
        return

    # Fallback: old-style file line
    m = re.search(r'file:\s*"([^"]+\.(?:mp4|m3u8|aaa\.mp4|gaa\.mp4))"', html)
    if m:
        vurl = m.group(1).replace("\\/", "/")
        xbmc.log(f"[{ADDON_ID}] Craft4u direct source: {vurl}", xbmc.LOGINFO)
        vurl = f"{vurl}|Referer=https://www.craft4u.top/&User-Agent={USER_AGENT}"
        Play_VIDEO(vurl)
        return

    xbmc.log(f"[{ADDON_ID}] No video source found in Craft4u page", xbmc.LOGERROR)
    xbmcgui.Dialog().ok("Playback Failed", "No playable video source found.")



############## SUNDAY ****************** 
def INDEX_SUNDAY(url):
    render_sunday_listing(url)

def SINDEX_SUNDAY(url):
    render_sunday_listing(url, label_suffix=" [COLOR green]Sunday[/COLOR]", include_pagination=False)

def render_sunday_listing(url, label_suffix="", include_pagination=True):
    try:
        headers = {'Referer': 'https://www.sundaydrama.com/', 'User-Agent': USER_AGENT}
        html = OpenURL(url, headers=headers, as_text=True)
        if not html:
            xbmc.log(f"[KDUBBED] Empty response from URL: {url}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", "Failed to retrieve SundayDrama content.")
            return

        soup = BeautifulSoup(html, 'html.parser')

        # ── Focus on main post container only ─────────────────
        main_container = soup.find('div', class_='blog-posts')
        if not main_container:
            xbmc.log("[KDUBBED] Could not find main post container.", xbmc.LOGWARNING)
            return

        # ── Extract drama cards from full entry blocks ────────
        for post in main_container.find_all('div', class_='entry-inner'):
            a_tag = post.find('a', class_='entry-image-wrap is-image')
            if not a_tag:
                continue

            v_link  = a_tag.get('href', '').strip()
            v_title = a_tag.get('title', 'No Title').strip()

            # Image
            v_image = ''
            span_tag = a_tag.find('span')
            if span_tag and span_tag.has_attr('data-src'):
                v_image = span_tag['data-src'].strip()
                # Smaller Blogger proxy for faster loading
                if "bp.blogspot.com" in v_image:
                    v_image = re.sub(r'/s\d+/', '/s320/', v_image)
            else:
                img_tag = a_tag.find('img')
                if img_tag and img_tag.has_attr('src'):
                    v_image = img_tag['src'].strip()

            label = v_title + label_suffix if label_suffix else v_title

            if v_link:
                addDir(label, v_link, "episode_players", v_image)

        # ── Pagination ─────────────────────────────────────────
        if include_pagination:
            next_page = soup.find('a', class_='blog-pager-older-link')
            if next_page and next_page.has_attr('href'):
                next_url = html_unescape(next_page['href'])
                if "?m=1" not in next_url:
                    next_url += "&m=1" if "?" in next_url else "?m=1"
                xbmc.log(f"[KDUBBED] Next page URL: {next_url}", xbmc.LOGDEBUG)
                addDir('[B]Next Page >>>[/B]', next_url, "index_sunday", '')

        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

    except Exception as e:
        import traceback
        xbmc.log(f"[KDUBBED] render_sunday_listing failed: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Could not load SundayDrama page.")
  
    
############## ckch7 ****************** 
def INDEX_CKCH7(url):
    _render_ckch7_listing(url)

def SINDEX_CKCH7(url):
    _render_ckch7_listing(url, label_suffix=" [COLOR green]Ckh7[/COLOR]", include_pagination=False)

def _render_ckch7_listing(url, label_suffix="", include_pagination=True):
    soup, _ = OpenSoup(unquote_plus(url), return_html=True)

    for card in soup.select("div.card.shadow-sm[class*='post-']"):
        a   = card.select_one("h3.post-title a[href]") or card.select_one("a[href]")
        img = card.find("img")
        if not a or not img:
            continue

        v_link  = urljoin(CKCH7, a["href"])
        v_title = (a.get("title") or a.get_text(strip=True) or img.get("title") or img.get("alt") or "No Title").strip()
        v_image = urljoin(CKCH7, img.get("data-src") or img.get("data-original") or img.get("src") or "")

        addDir(f"{v_title}{label_suffix}", v_link, "episode_players", v_image)

    if include_pagination:
        for a in soup.select("ul.pagination a[href], nav .pagination a[href]"):
            addDir(f"Page {a.get_text(strip=True)}", quote_plus(urljoin(CKCH7, a["href"])), "index_ckch7", "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_CKCH7(url):
    html = OpenURL(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] Failed to fetch CKCH7 page: %s" % url, xbmc.LOGERROR)
        return

    # Try to match new/old formats
    m = re.search(r"options\.player_list\s*=\s*(\[[\s\S]+?\]);", html)
    if not m:
        m = re.search(r"const\s+list_vdoiframe\s*=\s*(\[[\s\S]+?\])\s*;", html)
    if not m:
        m = re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\])\s*;", html)

    if not m:
        xbmcgui.Dialog().ok("Error", "No episodes found on CKCH7.")
        xbmc.log(f"[{ADDON_ID}] CKCH7: no video arrays found", xbmc.LOGERROR)
        return

    try:
        raw = m.group(1)
        raw = re.sub(r",\s*([\]}])", r"\1", raw)
        raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
        raw = raw.replace("'", '"')
        videos = json.loads(raw)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] CKCH7 JSON parse failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Failed to parse CKCH7 episodes.")
        return

    DIRECT_EXT = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4")
    seen = set()
    ep_counter = 1

    for v in videos:
        vurl = (v.get("file") or "").replace("\\", "").strip()
        if not vurl or vurl.lower() in seen:
            continue
        seen.add(vurl.lower())

        if vurl.startswith("https://youtu.be/"):
            vurl = vurl.replace("https://youtu.be/", "https://www.youtube.com/watch?v=")

        vtitle = f"Episode {ep_counter:02d}"
        ep_counter += 1

        if vurl.split("?", 1)[0].endswith(DIRECT_EXT):
            addLink(vtitle, vurl, "play_direct", "")
        elif any(host in vurl for host in ["ok.ru", "youtube.com", "youtu.be", "vimeo.com"]):
            addLink(vtitle, vurl, "video_hosting", "")
        else:
            addLink(vtitle, vurl, "video_hosting", "")  # fallback

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


############## phumikhmer2 ****************** 
def INDEX_PHUMIK(url):
    _render_phumik_listing(url, label_suffix=None, include_pagination=True)

def SINDEX_PHUMIK(url):  # for search
    _render_phumik_listing(url, label_suffix=" [COLOR green]PhumiKhmer[/COLOR]", include_pagination=False)

def _render_phumik_listing(url, label_suffix=None, include_pagination=True):
    soup, html = OpenSoup(url, return_html=True)
    
    # ------- 1 · Video cards -------------------------------------------------
    for wrap in soup.find_all('div', class_='post-filter-inside-wrap'):
        a_tag  = wrap.find('a', class_='post-filter-link')
        h2_tag = wrap.find('h2', class_=re.compile(r'entry-title'))
        img_tag = wrap.find('img', class_='snip-thumbnail')
        if not (a_tag and h2_tag and img_tag):
            continue

        v_link  = a_tag['href']
        v_title = h2_tag.get_text(strip=True)
        v_image = img_tag.get('data-src') or img_tag.get('src', '')
        v_image = re.sub(r'/w\d+-h\d+[^/]+/', '/s1600/', v_image)

        label = f"{v_title}{label_suffix}" if label_suffix else v_title
        addDir(label, v_link, "episode_players", v_image)

    # ------- 2 · Pagination --------------------------------------------------
    if include_pagination:
        for page_url in re.findall(r"<a[^>]*class='blog-pager-older-link'[^>]*href='([^']+)'", html):
            addDir('NEXT PAGE', page_url, "index_phumik", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
 
def EPISODE_PHUMIK(url):
    html = OpenURL(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] Failed to fetch PhumiKhmer page: {url}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Could not load this PhumiKhmer episode page.")
        return

    # --- Try Blogger JSON feeds first ---
    blogger_urls = extract_all_blogger_json_urls_from_page(html) or []
    all_links, seen = [], set()
    ep_counter = 1

    for blogger_url in blogger_urls:
        xbmc.log(f"[{ADDON_ID}] PhumiKhmer Blogger URL: {blogger_url}", xbmc.LOGINFO)
        links = parse_blogger_video_links(blogger_url) or []
        for link in links:
            vurl = (link.get("file") or "").strip()
            if not vurl or vurl in seen:
                continue
            seen.add(vurl)
            all_links.append({'file': vurl, 'title': f"Episode {ep_counter:02d}"})
            ep_counter += 1

    # --- If Blogger links were found, show them ---
    if all_links:
        DIRECT_EXT = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4", ".caa.mp4")
        for item in all_links:
            vurl, vtitle = item['file'], item['title']
            if any(h in vurl for h in ("ok.ru", "youtube.com", "youtu.be", "vimeo.com")):
                addLink(vtitle, vurl, "video_hosting", "")
            elif any(vurl.split("?", 1)[0].endswith(ext) for ext in DIRECT_EXT):
                addLink(vtitle, vurl, "play_direct", "")
            else:
                addLink(vtitle, vurl, "video_hosting", "")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # --- Blogger feeds not found → fallback to generic parsing ---
    xbmc.log(f"[{ADDON_ID}] No Blogger feeds on PhumiKhmer page, trying fallback parse", xbmc.LOGINFO)

    # Look for embedded players (player_list, const videos, etc.)
    m = re.search(r"options\.player_list\s*=\s*(\[[\s\S]+?\]);", html) \
        or re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\]);", html)

    if m:
        try:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            videos = json.loads(raw)
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] JSON parse failed on PhumiKhmer page: {e}", xbmc.LOGERROR)
            videos = []
    else:
        videos = []

    if videos:
        for idx, v in enumerate(videos, start=1):
            vurl = (v.get("file") or "").strip()
            if not vurl:
                continue
            vtitle = f"Episode {idx:02d}"
            if any(h in vurl for h in ("ok.ru", "youtube.com", "youtu.be", "vimeo.com")):
                addLink(vtitle, vurl, "video_hosting", "")
            else:
                addLink(vtitle, vurl, "play_direct", "")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # --- Nothing playable found ---
    xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected on this PhumiKhmer page.")
    xbmc.log(f"[{ADDON_ID}] PhumiKhmer: no episode links found at {url}", xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE) 
	
############## KhmerAve Merlkon SITE ****************** 		  
def INDEX_GENERIC(url, action, site_name='', label_suffix=None):
    try:
        headers = {'User-Agent': USER_AGENT}
        if 'khmeravenue.com' in url or site_name == 'khmeravenue':
            headers['Referer'] = KHMERAVENUE
        elif 'khmerdrama.com' in url or site_name == 'merlkon':
            headers['Referer'] = MERLKON

        soup, html = OpenSoup(url, return_html=True, headers=headers)

        # KhmerAvenue (Chinese) → "thumbnail-container"
        # Merlkon / KhmerAvenue (Korean) → "card-content"
        items = soup.select('div.col-6.col-sm-4.thumbnail-container, div.card-content')

        # Helper: extract image URL from inline CSS style
        def style_url(style):
            if not style:
                return ""
            m = re.search(r'url\((.*?)\)', style)
            return m.group(1) if m else ""

        for item in items:
            try:
                is_thumb = 'thumbnail-container' in (item.get('class') or [])

                if is_thumb:
                    # -------- KhmerAvenue (Chinese layout) --------
                    a_tag   = item.find('a')
                    h3_tag  = item.find('h3')
                    h4_tag  = item.find('h4')
                    v_link  = (a_tag or {}).get('href', '')
                    v_title = (h3_tag.get_text(strip=True) if h3_tag else '').replace("&#8217;", "")
                    v_info  = (h4_tag.get_text(strip=True) if h4_tag else '').replace("Episode", "").strip()
                    v_image = style_url((item.find('div', style=True) or {}).get('style'))

                else:
                    # -------- Merlkon / KhmerAvenue (Korean layout) --------
                    a_tag   = item.find('a', href=True)
                    v_link  = a_tag['href'] if a_tag else ''
                    v_title = (item.find('h3').get_text(strip=True) if item.find('h3') else '')
                    ep_tag  = item.find('span', class_='card-content-episode-number')
                    v_info  = (ep_tag.get_text(strip=True) if ep_tag else '').replace("Ep", "").strip()
                    img_div = item.find('div', class_='card-content-image')
                    v_image = style_url(img_div.get('style') if img_div else '')

                if v_link and v_title:
                    name  = f"{v_title} {v_info}".strip()
                    label = f"{name}{label_suffix}" if label_suffix else name
                    addDir(label, v_link, "episode_players", v_image)

            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) item error: {str(e)}", xbmc.LOGWARNING)

        # -------- Pagination --------
        try:
            nav = soup.select_one('nav.navigation.pagination .nav-links')
            if nav:
                for a in nav.select('a.page-numbers[href]'):
                    text, href = a.get_text(strip=True), urljoin(url, a['href'])
                    classes = a.get('class') or []
                    if 'next' in classes:
                        addDir('Next »', href, action, '')
                    elif 'prev' in classes:
                        addDir('« Previous', href, action, '')
                    elif text.isdigit():
                        addDir(f'Page {text}', href, action, '')
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC pagination error: {str(e)}", xbmc.LOGWARNING)

        # finish the listing so Kodi is happy
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) failed: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Failed to load {site_name or 'page'}.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

def EPISODE_GENERIC(url, site_name=''):
    html = OpenURL(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] EPISODE_GENERIC ({site_name}) failed to fetch: {url}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Failed to load {site_name or 'page'} episode list.")
        return

    decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html
    soup = BeautifulSoup(decoded, "html.parser")

    # --- Detect submitter (optional tag or pattern) ---
    submitter = ""
    m = re.search(r"Submitter:\s*<b[^>]*>([^<]+)</b>", decoded, re.IGNORECASE)
    if m:
        submitter = m.group(1).strip()
        xbmc.log(f"[{ADDON_ID}] Found submitter: {submitter}", xbmc.LOGINFO)

    # --- Episode parsing ---
    episodes = []
    for a in soup.select("table#latest-videos a[href], div.col-xs-6.col-sm-6.col-md-3 a[href]"):
        v_link = urljoin(url, a['href'])
        v_title = a.get_text(strip=True)
        episodes.append(v_link)

    # --- Rename sequentially as Episode 01, 02, 03... ---
    if episodes:
        for i, v_link in enumerate(episodes, start=1):
            v_title = f"Episode {i:02d}"
            if submitter:
                v_title += f" [COLOR grey](by {submitter})[/COLOR]"
            addLink(v_title, v_link, "videolinks", '')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # --- Fallback: try player_list in JSON/JS ---
    player_list = []
    m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded, re.DOTALL)
    if m:
        try:
            player_list = json.loads(m.group(1))
        except:
            pass

    if not player_list:
        m = re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\])\s*;", decoded)
        if m:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            try:
                player_list = json.loads(raw)
            except:
                pass

    if player_list:
        for i, item in enumerate(player_list, start=1):
            v_link = (item.get('file') or '').strip()
            if not v_link:
                continue
            v_title = f"Episode {i:02d}"
            if submitter:
                v_title += f" [COLOR grey](by {submitter})[/COLOR]"
            if v_link.endswith((".mp4", ".m3u8")):
                addLink(v_title, v_link, "play_direct", '')
            else:
                addLink(v_title, v_link, "video_hosting", '')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmc.log(f"[{ADDON_ID}] EPISODE_GENERIC ({site_name}) no episodes found: {url}", xbmc.LOGWARNING)
    xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



############## use for sundaydrama episode ****************** 
BLOG_ID_CACHE = {}

BLOG_ID_SEEN = set()

BLOG_ID_BASELINE = {
    "2": "7871281676618369095",
    "4": "596013908374331296",
    "":  "3556626157575058125",
} 

"""
Guide to Finding the Blogger Blog ID and Server Index:

1. Open the webpage and view the page source (Ctrl+U or right-click > View page source).
2. Search for the string "fanta".
   Example found:
       <div id="fanta" data-post-id="4534454511319106355" data-server-index="4"></div>
3. Copy the `data-post-id` value (e.g., 4534454511319106355) and search for it using Inspect (DevTools).
4. You should find a script tag like this:
       <script src="https://www.blogger.com/feeds/596013908374331296/posts/default/4534454511319106355?alt=json-in-script&callback=fetchBloggerPostContent"></script>
5. Extract the following values:
   - Blog ID:        596013908374331296
   - Post ID:        4534454511319106355
   - Server Index:   "4" (as seen in data-server-index)
6. Use Server Index and Blod ID as for BLOG_ID_BASELINE

Special Case:
If the source only shows:
    <div id="fanta" data-post-id="8526567538163274964"></div>
Then no data-server-index is present, so treat it as an empty string ("").
Example script tag:
    <script src="https://www.blogger.com/feeds/3556626157575058125/posts/default/8526567538163274964?alt=json-in-script&callback=fetchBloggerPostContent"></script>
"""

ADDON_DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.KDubbed")
if not os.path.exists(ADDON_DATA_PATH):
    try:
        os.makedirs(ADDON_DATA_PATH)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to create addon data path: {e}", xbmc.LOGWARNING)

BLOG_ID_CACHE_PATH = os.path.join(ADDON_DATA_PATH, "blog_id_cache.json")

def load_blog_id_cache_from_disk():
    global BLOG_ID_CACHE, BLOG_ID_SEEN
    if os.path.exists(BLOG_ID_CACHE_PATH):
        try:
            with open(BLOG_ID_CACHE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            BLOG_ID_CACHE = data.get("map", {})
            BLOG_ID_SEEN = set(data.get("seen", []))
            xbmc.log(f"[KDUBBED] Loaded BLOG_ID_CACHE: {BLOG_ID_CACHE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[KDUBBED] Failed to load BLOG_ID_CACHE: {e}", xbmc.LOGWARNING)

def save_blog_id_cache_to_disk():
    try:
        data = {"map": BLOG_ID_CACHE, "seen": list(BLOG_ID_SEEN)}
        with open(BLOG_ID_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f)
        xbmc.log("[KDUBBED] Saved BLOG_ID_CACHE.", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to save BLOG_ID_CACHE: {e}", xbmc.LOGWARNING)

load_blog_id_cache_from_disk()

def _learn_mapping(server_index, blog_id, source="unknown"):
    prev = BLOG_ID_CACHE.get(server_index)
    if prev != blog_id:
        BLOG_ID_CACHE[server_index] = blog_id
        xbmc.log(
            f"[KDUBBED] Learned blog_id mapping: server_index={server_index} -> {blog_id} (source={source}, prev={prev})",
            xbmc.LOGINFO
        )
        save_blog_id_cache_to_disk()
    if blog_id not in BLOG_ID_SEEN:
        BLOG_ID_SEEN.add(blog_id)
        save_blog_id_cache_to_disk()

def extract_blog_id_mapping_from_scripts(html):
    matches = re.findall(
        r'src=["\']https://www\\.blogger\\.com/feeds/(\d+)/posts/default/(\d+)\?alt=json-in-script',
        html
    )
    mapping = {}
    for blog_id, post_id in matches:
        BLOG_ID_SEEN.add(blog_id)
        div_match = re.search(
            fr'<div[^>]+data-post-id=["\']{post_id}["\'][^>]*data-server-index=["\']?(\d*)["\']?',
            html
        )
        if div_match:
            server_index = div_match.group(1) or ""
            mapping[server_index] = blog_id
            _learn_mapping(server_index, blog_id, source="script-tag")
    if matches:
        save_blog_id_cache_to_disk()
    return mapping

def _get_blog_id_for_server_index(server_index):
    if server_index in BLOG_ID_CACHE:
        return BLOG_ID_CACHE[server_index]
    if server_index in BLOG_ID_BASELINE:
        blog_id = BLOG_ID_BASELINE[server_index]
        _learn_mapping(server_index, blog_id, source="baseline")
        return blog_id
    return None

def extract_all_blogger_json_urls_from_page(html):
    extract_blog_id_mapping_from_scripts(html)
    matches = re.findall(
        r'<div[^>]+id=["\']fanta["\'][^>]*data-post-id=["\'](\d+)["\'](?:[^>]*data-server-index=["\']?(\d*)["\']?)?',
        html
    )
    urls = []
    for post_id, server_index in matches:
        server_index = server_index or ""
        blog_id = _get_blog_id_for_server_index(server_index)
        if blog_id:
            feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
            urls.append(feed_url)
        else:
            xbmc.log(
                f"[KDUBBED] Unknown server index: {server_index} for post ID {post_id} (no mapping; cache={BLOG_ID_CACHE})",
                xbmc.LOGWARNING
            )
    return urls
    
# ── VIP (phumikhmer.*) helpers ─────────────────────────────────────────────
def _vip_blogid_and_alt_from_scripts(html, post_id):
    m = re.search(
        r'src\s*=\s*["\'](?:https?:)?//www\.blogger\.com/feeds/(\d+)/posts/default/\s*'
        + re.escape(post_id) +
        r'\?([^"\']*)["\']',
        html, re.IGNORECASE
    )
    if m:
        blog_id = m.group(1)
        qs = (m.group(2) or "").lower().replace("&amp;", "&")
        if "json-in-script" in qs or "callback=" in qs:
            return blog_id, "json-in-script"
        if "alt=json" in qs:
            return blog_id, "json"
        return blog_id, "json"

    # Script without query (rare)
    m2 = re.search(
        r'src\s*=\s*["\'](?:https?:)?//www\.blogger\.com/feeds/(\d+)/posts/default/\s*'
        + re.escape(post_id) + r'["\']',
        html, re.IGNORECASE
    )
    if m2:
        return m2.group(1), "json"

    return None, None

def is_vip_url(u: str) -> bool:
    base_host = urlparse(VIP).netloc.lower().lstrip("www.")
    host = urlparse(u).netloc.lower().lstrip("www.")
    return host == base_host

def is_idrama_url(u: str) -> bool:
    base_host = urlparse(IDRAMA).netloc.lower().lstrip("www.")
    host = urlparse(u).netloc.lower().lstrip("www.")
    return host == base_host


def extract_vip_blogger_json_urls_from_page(html):
    urls = []

    # Prefer the real player block
    post_ids = re.findall(
        r'<div[^>]+id=["\']player["\'][^>]*\bdata-post-id=["\'](\d+)["\']',
        html, re.IGNORECASE
    )
    if not post_ids:
        # Safety net: any data-post-id on page
        post_ids = re.findall(r'\bdata-post-id=["\'](\d+)["\']', html, re.IGNORECASE)

    # helper to dedupe while preserving order
    def _uniq(seq):
        seen = set()
        out = []
        for x in seq:
            if x and x not in seen:
                seen.add(x); out.append(x)
        return out

    for pid in _uniq([p.strip() for p in post_ids if p]):
        # 1) First choice: exact blog_id/alt from <script> for THIS pid
        blog_id, alt_kind = _vip_blogid_and_alt_from_scripts(html, pid)
        if blog_id:
            # Try the script’s alt first, plus the other alt as backup
            first_alt = alt_kind or "json"
            alts = [first_alt, "json-in-script" if first_alt == "json" else "json"]
            for alt in alts:
                if alt == "json-in-script":
                    urls.append(
                        f"https://www.blogger.com/feeds/{blog_id}/posts/default/{pid}?alt=json-in-script&callback=fetchBloggerPostContent"
                    )
                else:
                    urls.append(
                        f"https://www.blogger.com/feeds/{blog_id}/posts/default/{pid}?alt=json"
                    )
            continue  # script-derived is strongest; move to next pid

        # 2) No script? rotate a SHORT list of candidate blog_ids
        #    Order: cache(''), cache('4'), cache('2'), all cache values, all baselines
        candidates = _uniq([
            BLOG_ID_CACHE.get(""),
            BLOG_ID_CACHE.get("4"),
            BLOG_ID_CACHE.get("2"),
            *BLOG_ID_CACHE.values(),
            *BLOG_ID_BASELINE.values(),
        ])

        # For each candidate blog_id, try both alt flavors
        for bid in candidates:
            urls.append(f"https://www.blogger.com/feeds/{bid}/posts/default/{pid}?alt=json")
            urls.append(f"https://www.blogger.com/feeds/{bid}/posts/default/{pid}?alt=json-in-script&callback=fetchBloggerPostContent")

    return _uniq(urls)

# ====    

def parse_blogger_video_links(blogger_post_url):
    if "?alt=" not in blogger_post_url:
        blogger_post_url = blogger_post_url.split("?", 1)[0] + "?alt=json"

    try:
        response = OpenURL(blogger_post_url, as_text=True)
        if not response or not response.strip().startswith("{"):
            xbmc.log(f"[{ADDON_ID}] Empty or invalid feed: {blogger_post_url}", xbmc.LOGWARNING)
            return []

        data = json.loads(response)
        raw_html = data.get("entry", {}).get("content", {}).get("$t", "")
        decoded_html = html_unescape(raw_html)

        # Keep only Server 1 (before {nextServer})
        if "{nextServer}" in decoded_html:
            decoded_html = decoded_html.split("{nextServer}", 1)[0]
            xbmc.log(f"[{ADDON_ID}] Server 1 mode: content truncated before {{nextServer}}", xbmc.LOGINFO)

        # SundayDrama special: detect {embed=ok} and build OK.ru episodes
        if "{embed=ok}" in decoded_html:
            ids = re.findall(r"\d{10,}", decoded_html)
            if ids:
                xbmc.log(f"[{ADDON_ID}] OK embed detected ({len(ids)} episodes) in Blogger feed", xbmc.LOGINFO)
                links = []
                for i, vid in enumerate(ids, start=1):
                    links.append({
                        'file': f"https://ok.ru/videoembed/{vid}",
                        'title': f"Episode {i:02d}"
                    })
                return links

        # Step 1: collect all .mp4 (strong preference)
        mp4_matches = re.findall(r"(https?:\/\/[^\s\"']+?\.mp4)(?:\s+(\d{1,3}))?", decoded_html)
        links = []
        seen = set()
        seq = 1

        for url, epnum in mp4_matches:
            url = url.strip().rstrip(';').rstrip(',')
            if not url or url in seen:
                continue
            seen.add(url)

            low = url.lower()
            # Skip HLS disguised
            if "playlist.m3u8" in low or "manifest.m3u8" in low or "master.m3u8" in low:
                continue

            # Skip promo/test or duplicates right here
            if any(x in url for x in ["cloudokyo.cloud", "rumble.com/hls-vod", "playlist.m3u8?key="]):
                xbmc.log(f"[{ADDON_ID}] Skipped unwanted link in mp4 scan: {url}", xbmc.LOGINFO)
                continue

            title = f"Episode {int(epnum)}" if epnum else f"Episode {seq}"
            seq += 1
            links.append({'file': url, 'title': title})

        # Step 2: fallback to HLS / m3u8
        if not links:
            hls_matches = re.findall(r"https?:\/\/[^\s\"']+?\.m3u8", decoded_html)
            for url in hls_matches:
                url = url.strip().rstrip(';').rstrip(',')
                if url in seen:
                    continue
                seen.add(url)

                low = url.lower()
                # Skip playlist and unwanted promos
                if "playlist" in low or "master" in low:
                    continue
                if any(x in url for x in ["cloudokyo.cloud", "rumble.com/hls-vod", "playlist.m3u8?key="]):
                    xbmc.log(f"[{ADDON_ID}] Skipped unwanted link in HLS scan: {url}", xbmc.LOGINFO)
                    continue

                links.append({'file': url, 'title': f"Episode {len(links)+1}"})

        return links

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Error parsing Blogger video links from {blogger_post_url}: {e}", xbmc.LOGERROR)
        return []


def parse_blogger_video_links_script(blogger_post_url):
    """
    Handles Blogger feeds with ?alt=json-in-script&callback=fetchBloggerPostContent
    Used by PhumiKhmer VIP and similar sites.
    """
    if "?alt=" not in blogger_post_url:
        blogger_post_url = blogger_post_url.split("?", 1)[0] + "?alt=json-in-script&callback=fetchBloggerPostContent"
    elif "json" in blogger_post_url and "callback=" not in blogger_post_url:
        blogger_post_url = blogger_post_url.replace("alt=json", "alt=json-in-script&callback=fetchBloggerPostContent")

    try:
        response = OpenURL(blogger_post_url, as_text=True)
        if not response or "fetchBloggerPostContent(" not in response:
            xbmc.log(f"[{ADDON_ID}] No script JSON found in: {blogger_post_url}", xbmc.LOGWARNING)
            return []

        # Extract the JSON between the parentheses
        m = re.search(r"fetchBloggerPostContent\((\{.*\})\);?$", response, re.DOTALL)
        if not m:
            xbmc.log(f"[{ADDON_ID}] Failed to extract JSON payload from script feed", xbmc.LOGWARNING)
            return []

        data = json.loads(m.group(1))
        raw_html = data.get("entry", {}).get("content", {}).get("$t", "")
        decoded_html = html_unescape(raw_html)

        # Parse .mp4 and .m3u8 URLs
        links = []
        seen = set()
        seq = 1

        for url in re.findall(r"https?:\/\/[^\s\"']+(?:\.mp4|\.m3u8)", decoded_html):
            url = url.strip().rstrip(";")
            if url in seen:
                continue
            seen.add(url)

            title = f"Episode {seq}"
            seq += 1
            links.append({'file': url, 'title': title})

        xbmc.log(f"[{ADDON_ID}] Parsed {len(links)} video links from script feed", xbmc.LOGINFO)
        return links

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Error parsing script-based Blogger feed: {e}", xbmc.LOGERROR)
        return []


def is_url_valid(url, referer=None):
    try:
        headers = {'User-Agent': USER_AGENT}
        if referer: headers['Referer'] = referer

        r = requests.head(url, headers=headers, allow_redirects=True, timeout=5)
        if r.status_code == 200 and int(r.headers.get('Content-Length', 0)) > 50*1024:
            return True

        # Fallback if HEAD isn’t allowed
        r = requests.get(url, headers={**headers, "Range": "bytes=0-0"}, stream=True, timeout=6)
        return r.status_code in (200, 206)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] HEAD/GET check failed for {url}: {e}", xbmc.LOGWARNING)
        return False
    


############## episode_players ****************** 
def EPISODE_PLAYERS(url, name):
    if not url:
        xbmc.log(f"[{ADDON_ID}] Empty URL passed to EPISODE_PLAYERS", xbmc.LOGERROR)
        return
        
    links_found = False
    
    # ── Site-specific direct handlers ─────────────────────────────
    if "tvsabay.com" in url:
        xbmc.log(f"[{ADDON_ID}] Detected Tvsabay URL: {url}", xbmc.LOGINFO)
        return EPISODE_TVSABAY(url)
    if "craft4u.top" in url:
        xbmc.log(f"[{ADDON_ID}] Detected Craft4u URL: {url}", xbmc.LOGINFO)
        return EPISODE_CRAFT4U(url)
    if "onelegend.asia" in url:
        xbmc.log(f"[{ADDON_ID}] Detected OneLegend URL: {url}", xbmc.LOGINFO)
        return EPISODE_ONELEGEND(url)
    if "ckh7.com/watch.php" in url:
        xbmc.log(f"[{ADDON_ID}] Detected CKCH7 URL: {url}", xbmc.LOGINFO)
        return EPISODE_CKCH7(url)
    if "phumikhmer1.club" in url:
        xbmc.log(f"[{ADDON_ID}] Detected PhumiKhmer (classic) URL: {url}", xbmc.LOGINFO)
        return EPISODE_PHUMIK(url)
    if "khmeravenue.com" in url or "khmerdrama.com" in url:
        xbmc.log(f"[{ADDON_ID}] Detected KhmerAve/Merlkon URL: {url}", xbmc.LOGINFO)
        return EPISODE_GENERIC(url, site_name="khmerave/merlkon")
    if VIDEO4KHMER in url:
        xbmc.log(f"[{ADDON_ID}] Detected Video4Khmer URL: {url}", xbmc.LOGINFO)
        return EPISODE_VIDEO4KHMER(url)     

    # Fetch HTML for redirect handling
    html = OpenURL(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] Failed to fetch page for: {url}", xbmc.LOGERROR)
        return

    # Tvsabay redirect inside iDrama page
    tvsabay_match = re.search(r'href="(https://www\.tvsabay\.com/[^"]+)"', html, re.IGNORECASE)
    if tvsabay_match:
        tvsabay_url = tvsabay_match.group(1)
        xbmc.log(f"[{ADDON_ID}] Redirecting to Tvsabay: {tvsabay_url}", xbmc.LOGINFO)
        EPISODE_TVSABAY(tvsabay_url)
        return

    # Craft4u redirect inside VIP page
    craft_match = re.search(r'href="(https://www\.craft4u\.top/[^"]+)"', html, re.IGNORECASE)
    if craft_match:
        craft_url = craft_match.group(1)
        xbmc.log(f"[{ADDON_ID}] Redirecting to Craft4u: {craft_url}", xbmc.LOGINFO)
        EPISODE_CRAFT4U(craft_url)
        return
        
    # OneLegend redirect inside iDrama page
    onelegend_match = re.search(r'(https://onelegend\.asia/[^"\']+)', html, re.IGNORECASE)
    if onelegend_match:
        onelegend_url = onelegend_match.group(1)
        xbmc.log(f"[{ADDON_ID}] Redirecting to OneLegend: {onelegend_url}", xbmc.LOGINFO)
        EPISODE_ONELEGEND(onelegend_url)
        return        
     
    # Episode list
    if VIDEO4KHMER in url:
        html = OpenURL(url, as_text=True)
        decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html

        # --- One-time summary popup ---
        if ADDON.getSetting("summary_url") != url:
            m = re.search(r'<h2 class="h3">Summary:</h2>\s*<p class="justified-text">(.*?)</p>', decoded, re.DOTALL | re.IGNORECASE)
            if m:
                summary = re.sub(r'\s+', ' ', re.sub(r'<br\s*/?>', '\n', m.group(1))).strip()
                try:
                    xbmcgui.Dialog().textviewer("Summary", summary)
                    ADDON.setSetting("summary_url", url)
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] Summary popup failed: {e}", xbmc.LOGWARNING)

        # --- Parse episodes ---
        soup = BeautifulSoup(decoded, "html.parser")
        episodes = {}
        for tr in soup.select("#episode-list tbody tr"):
            td = tr.find("td")
            if not td:
                continue

            a = td.find("a")
            title = a.get_text(strip=True) if a else td.get_text(strip=True)
            link = a["href"] if a else url

            m = re.search(r'(\d+)', title)
            ep_num = int(m.group(1)) if m else 0
            if ep_num and ep_num not in episodes:
                episodes[ep_num] = (title, link)

        # --- Show episodes ---
        for ep_num in sorted(episodes):
            title, link = episodes[ep_num]
            addLink(title, link, "videolinks", "")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return    

    if "sundaydrama.com" in url:
        html = OpenURL(url, as_text=True)
        blogger_urls = extract_all_blogger_json_urls_from_page(html)
        
        # Handle Blogger {embed=ok} pattern (OK.ru episode IDs)
        if "fetchBloggerPostContent({" in html and "{embed=ok}" in html:
            m = re.search(r'"content":\{"type":"html","\$t":"([^"]+)"\}', html)
            if m:
                content = html_unescape(m.group(1))
                ids = re.findall(r"\d{10,}", content)
                if ids:
                    xbmc.log(f"[{ADDON_ID}] SundayDrama Blogger OK embed found: {len(ids)} IDs", xbmc.LOGINFO)
                    for i, vid in enumerate(ids, start=1):
                        ok_url = f"https://ok.ru/videoembed/{vid}"
                        addLink(f"Episode {i:02d}", ok_url, "video_hosting", "")
                    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
                    return
        

        all_links = []
        episode_counter = 1
        for blogger_url in blogger_urls:
            xbmc.log(f"[{ADDON_ID}] Extracted Blogger URL: {blogger_url}", xbmc.LOGINFO)
            links = parse_blogger_video_links(blogger_url)
            if links:
                for link in links:
                    link['title'] = f"Episode {episode_counter}"
                    episode_counter += 1
                all_links.extend(links)

        if all_links:
            DIRECT_EXTENSIONS = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4", ".caa.mp4")
            for item in all_links:
                vurl = item['file']
                vtitle = item['title']

                if any(host in vurl for host in ["ok.ru", "youtube.com", "youtu.be", "vimeo.com"]):
                    addLink(vtitle, vurl, "video_hosting", '')
                elif any(vurl.split('?')[0].endswith(ext) for ext in DIRECT_EXTENSIONS):
                    addLink(vtitle, vurl, "play_direct", '')
                else:
                    addLink(vtitle, vurl, "video_hosting", '')  # fallback

            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return
        else:
            xbmcgui.Dialog().ok("No Episodes Found", "No playable episodes found in Blogger posts.")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

# ── VIP: phumikhmer.vip ─────────────────────────────────────────
    if is_vip_url(url) or is_idrama_url(url):
        decoded = OpenURL(url, as_text=True)
        blogger_urls = extract_vip_blogger_json_urls_from_page(decoded)

        # Put the guard *inside* the VIP block 
        if not blogger_urls:
            # Extra Craft4u / Tvsabay / t.co check for VIP/iDrama pages with no feeds
            craft_match = re.search(
                r'href=[\'"]?(https?://(?:t\.co|(?:www\.)?(craft4u\.top|tvsabay\.com))/[^\'"]+)',
                decoded, re.IGNORECASE
            )
            if craft_match:
                craft_url = craft_match.group(1)
                xbmc.log(f"[{ADDON_ID}] VIP/iDrama page redirected (raw): {craft_url}", xbmc.LOGINFO)

                # If it's a t.co shortlink → resolve it
                if "t.co" in craft_url:
                    try:
                        r = requests.head(craft_url, allow_redirects=True, timeout=5)
                        craft_url = r.url
                        xbmc.log(f"[{ADDON_ID}] Resolved t.co → {craft_url}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[{ADDON_ID}] Failed to resolve t.co link: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().ok("No Episodes Found", "Could not resolve redirect link.")
                        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
                        return

                # Handle Tvsabay separately
                if "tvsabay.com" in craft_url:
                    xbmc.log(f"[{ADDON_ID}] Redirecting to Tvsabay handler: {craft_url}", xbmc.LOGINFO)
                    EPISODE_TVSABAY(craft_url)
                    return

                # Handle OneLegend separately
                if "onelegend.asia" in craft_url:
                    xbmc.log(f"[{ADDON_ID}] Redirecting to OneLegend handler: {craft_url}", xbmc.LOGINFO)
                    EPISODE_ONELEGEND(craft_url)
                    return

                # Otherwise assume Craft4u
                EPISODE_CRAFT4U(craft_url)
                return

            xbmc.log(f"[{ADDON_ID}] No blogger feeds detected, skipping VIP Blogger parse.", xbmc.LOGINFO)
            xbmcgui.Dialog().ok("No Episodes Found", "No blogger feeds were found on this VIP page.")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

        all_links, seen, episode_counter = [], set(), 1
        for blogger_url in blogger_urls:
            xbmc.log(f"[{ADDON_ID}] VIP Blogger URL: {blogger_url}", xbmc.LOGINFO)

            # Try normal Blogger JSON first
            links = parse_blogger_video_links(blogger_url)

            # If empty or invalid, try JSON-in-script (for PhumiKhmer VIP)
            if not links or all(".mp4" in l['file'] for l in links):
                xbmc.log(f"[{ADDON_ID}] Switching to script-based Blogger parser (likely PhumiKhmer VIP feed)", xbmc.LOGINFO)
                links = parse_blogger_video_links_script(blogger_url)

            for link in links or []:
                vurl = (link.get('file') or '').strip()
                if not vurl or vurl in seen:
                    continue
                seen.add(vurl)
                all_links.append({'file': vurl, 'title': f"Episode {episode_counter}"})
                episode_counter += 1


        if all_links:
            DIRECT_EXT = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4")
            for item in all_links:
                vurl, vtitle = item['file'], item['title']
                if any(h in vurl for h in ("ok.ru", "youtube.com", "youtu.be", "vimeo.com")):
                    addLink(vtitle, vurl, "video_hosting", '')
                elif any(vurl.split('?', 1)[0].endswith(ext) for ext in DIRECT_EXT):
                    addLink(vtitle, vurl, "play_direct", '')
                else:
                    addLink(vtitle, vurl, "video_hosting", '')
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

        xbmcgui.Dialog().ok("No Episodes Found", "No playable episodes found on this VIP page.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # Blogger JSON feed direct
    if "blogger.com/feeds/" in url:
        blogger_links = parse_blogger_video_links(url)
        if blogger_links:
            for item in blogger_links:
                addLink(item['title'], item['file'], "play_direct", '')
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return
        else:
            xbmcgui.Dialog().ok("No Episodes Found", "No playable episodes found in Blogger feed.")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # ── Load standard HTML and parse ─────────────────────────────
    html = OpenURL(url)
    decoded = html.decode("utf-8") if isinstance(html, bytes) else html

    def show_about_section():
        if ADDON.getSetting("about_url") == url:
            return
        m = re.search(
            r'<div[^>]+id=["\']about["\'][^>]*>.*?<p[^>]*class=["\']album-content-description["\'][^>]*>(.*?)</p>',
            decoded, re.DOTALL | re.IGNORECASE)
        if m:
            about = re.sub(r'\s+', ' ', re.sub(r'<br\s*/?>', '\n', m.group(1))).strip()
            try:
                xbmcgui.Dialog().textviewer("About", about)
                ADDON.setSetting("about_url", url)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Failed to show About popup: {e}", xbmc.LOGWARNING)

    def get_submitter():
        m = re.search(r'Submitter:\s*<b[^>]*>([^<]+)</b>', decoded, re.IGNORECASE)
        return m.group(1).strip() if m else ""

    def parse_episode_table():
        table = re.search(r'<table id="latest-videos"[^>]*>(.*?)</table>', decoded, re.DOTALL)
        if table:
            return re.findall(r'<td>\s*<a href="([^"]+)">\s*(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>', table.group(1))
        return re.findall(
            r'<div class="col-xs-6 col-sm-6 col-md-3">.*?<a href="([^"]+)"[^>]*>\s*(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>',
            decoded, re.DOTALL
        )

    def try_player_list_json():
        m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed: {e}", xbmc.LOGWARNING)
        return None

    def try_player_list_eval():
        m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded.replace("null", "None"), re.DOTALL)
        if m:
            try:
                return ast.literal_eval(m.group(1))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] ast.literal_eval failed: {e}", xbmc.LOGWARNING)
        return None

    def try_videos_list_const(): #ckch7/sunday
        m = re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\])\s*;", decoded)
        if m:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            try:
                return json.loads(raw)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed on cleaned const videos list: {e}", xbmc.LOGWARNING)
        return None

    def try_fallback_player_list():
        return [{'file': f, 'title': t} for f, t in re.findall(
            r"[{[]\s*['\"]file['\"]\s*:\s*['\"](.+?)['\"],\s*['\"]title['\"]\s*:\s*['\"](.+?)['\"]", decoded)]

    def sort_episodes_by_number(episodes):
        def extract_number(title):
            m = re.search(r'\b(?:Ep(?:isode)?|Part)\s*(\d+)\b', title, re.IGNORECASE)
            return int(m.group(1)) if m else 0
        return sorted(episodes, key=lambda x: extract_number(x[1]))

    def sort_player_list_by_title(items):
        def extract_number(title):
            m = re.search(r'\b(?:Ep(?:isode)?|Part)\s*(\d+)\b', title, re.IGNORECASE)
            return int(m.group(1)) if m else 0
        return sorted(items, key=lambda x: extract_number(x.get("title", "")))

    # ── Begin parsing ──────────────────────────────────────────── 
    show_about_section()
    submitter = get_submitter()

    episodes = parse_episode_table()
    episodes = sort_episodes_by_number(episodes)
    
    for i, (v_link, _) in enumerate(episodes, start=1):   
        v_link = urljoin(url, v_link)
        v_title = f"Episode {i}"
        if submitter:
            v_title += f" [COLOR grey](by {submitter})[/COLOR]"
        addLink(v_title, v_link, "videolinks", '')
        links_found = True

    if not links_found:
        player_list = (
            try_player_list_json() or
            try_player_list_eval() or
            try_videos_list_const() or
            try_fallback_player_list()
        )

        if player_list:   
            player_list = sort_player_list_by_title(player_list)
            for i, item in enumerate(player_list, start=1):
                try:
                    v_link = item.get('file', '').strip()
                    v_title = f"Episode {i}"
                    
                    if submitter:
                        v_title += f" [COLOR grey](by {submitter})[/COLOR]"
                     
                    if not v_link:
                        continue

                    if (
                        "1a-1791.com" in v_link or
                        v_link.endswith(".aaa.mp4") or
                        any(domain in v_link for domain in ["ckh7.com", "sundaydrama.com"])
                    ):
                        addLink(v_title, v_link, "play_direct", '')
                    else:
                        addLink(v_title, v_link, "video_hosting", '')

                    links_found = True
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] Failed to parse video item: {e}", xbmc.LOGWARNING)

    if not links_found:
        xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
        xbmc.log(f"[{ADDON_ID}] No episode links found at: {url}", xbmc.LOGWARNING)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def resolve_redirect(url): # Craft4u
    try:
        r = requests.head(url, allow_redirects=True, timeout=5)
        return r.url
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Redirect resolve failed: {e}", xbmc.LOGERROR)
        return url

def VIDEOLINKS(url):
    content = str(OpenSoup(url))  # Ensure string format
    blacklist = ['googletagmanager.com', 'facebook.com', 'twitter.com', 'doubleclick.net']

    def is_blacklisted(link):
        return any(bad in link for bad in blacklist)

    def try_base64_iframe():
        matches = re.findall(r'Base64.decode\("(.+?)"\)', content)
        if matches:
            try:
                decoded = base64.b64decode(matches[0]).decode('utf-8', errors='ignore')
                iframe = re.search(r'<iframe[^>]+src="(.+?)"', decoded)
                if iframe:
                    VIDEO_HOSTING(iframe.group(1))
                    return True
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Base64 decode failed: {e}", xbmc.LOGWARNING)
        return False

    def try_patterns():
        patterns = [
            r'[\'"]?file[\'"]?\s*:\s*[\'"]([^\'"]+)[\'"]',
            r'<iframe src="(.+?)" class="video allowfullscreen="true">',
            r'<iframe frameborder="0" [^>]*src="(.+?)">',
            r'<IFRAME SRC="(.+?)" [^>]*',
            r'<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
            r"var flashvars = {file: '(.+?)',",
            r'swfobject\.embedSWF\("(.+?)",',
            r'src="(.+?)" allow="autoplay"',
            r'<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
            r'<source [^>]*src="([^"]+?)"',
            r'playlist: "(.+?)"',
            r'<!\[CDATA\[(.*?)\]\]></tvurl>'
        ]
        for pattern in patterns:
            matches = re.findall(pattern, content)
            for url in matches:
                if not is_blacklisted(url):
                    VIDEO_HOSTING(url)
                    return True
        return False

    if try_base64_iframe() or try_patterns():
        return
    xbmc.log(f"[{ADDON_ID}] No video URL found in VIDEOLINKS()", xbmc.LOGWARNING)
    
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def enable_inputstream_adaptive():
    try:
        addon_id = "inputstream.adaptive"

        if not xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
            xbmc.log(f"[KDUBBED] Installing {addon_id}...", xbmc.LOGINFO)
            xbmc.executebuiltin(f"InstallAddon({addon_id})")

        if not xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
            xbmc.log(f"[KDUBBED] Enabling {addon_id}...", xbmc.LOGINFO)
            xbmc.executebuiltin(f"EnableAddon({addon_id})")

    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to enable {addon_id}: {e}", xbmc.LOGWARNING)


def Playloop(video_url):
    xbmc.log(f"[KDUBBED] PLAY VIDEO: {video_url}", xbmc.LOGINFO)

    # Safer header formatting (quote_plus ensures URL-safe encoding)
    headers_dict = {
        'verifypeer': 'false',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/90 Safari/537.36',
        'Referer': 'https://live-ali7.tv360.metfone.com.kh/',
    }
    headers = '&'.join(f'{k}={quote_plus(v)}' for k, v in headers_dict.items())
    full_url = f"{video_url}|{headers}"

    item = xbmcgui.ListItem(path=full_url)

    # Configure for adaptive HLS streaming
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    item.setProperty('inputstream', 'inputstream.adaptive')
    item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
    item.setProperty('inputstream.adaptive.heuristicstreamselection', 'true')
    
    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)


def VIDEO_HOSTING(vlink):
    resolved = None
    RESOLVABLE_HOSTS = (
        'ok.ru', 'youtube.com', 'youtu.be',
        'youtube-nocookie.com', 'vimeo.com', 'dailymotion.com'
    )

    # Try resolveurl for known hosts
    if any(host in vlink for host in RESOLVABLE_HOSTS):
        try:
            resolved = resolveurl.resolve(vlink)
            if resolved:
                xbmc.log(f"[KDUBBED] Resolved URL via resolveurl: {resolved}", xbmc.LOGINFO)
                Play_VIDEO(resolved)
                return
            else:
                xbmc.log(f"[KDUBBED] resolveurl returned None for: {vlink}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[KDUBBED] resolveurl error for {vlink}: {e}", xbmc.LOGWARNING)

    # Handle Google Drive links
    if "drive.google.com" in vlink or "docs.google.com/file/" in vlink:
        try:
            resolved = resolveurl.resolve(vlink)
            if resolved:
                xbmc.log(f"[KDUBBED] Resolved Google Drive via resolveurl: {resolved}", xbmc.LOGINFO)
                Play_VIDEO(resolved)
                return
        except Exception as e:
            xbmc.log(f"[KDUBBED] resolveurl error on Google Drive: {e}", xbmc.LOGWARNING)

    # Fallback to direct playback
    xbmc.log(f"[KDUBBED] Fallback to Play_VIDEO(): {vlink}", xbmc.LOGINFO)
    xbmc.executebuiltin("Notification(Please Wait!, KhmerDubbed is loading...)")
    Play_VIDEO(vlink)    
    

def Play_VIDEO(VideoURL):
    if not VideoURL:
        xbmcgui.Dialog().ok("Playback Error", "No video URL provided.")
        xbmc.log("[KDUBBED] Empty video URL passed to Play_VIDEO()", xbmc.LOGWARNING)
        return

    xbmc.log(f"[KDUBBED] Playing video: {VideoURL}", xbmc.LOGINFO)

    # Plugin URLs (like plugin://plugin.video.youtube/...) must not include headers
    if VideoURL.startswith("plugin://"):
        item = xbmcgui.ListItem(path=VideoURL)
        item.setInfo(type="Video", infoLabels={"title": "Playing..."})
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)
        return

    # Parse embedded headers if any (ckch7/sunday)
    if "|" in VideoURL:
        VideoURL, header_str = VideoURL.split("|", 1)
        header_parts = header_str.split("|")
        headers = dict(part.split("=", 1) for part in header_parts if "=" in part)
    else:
        headers = {}

    # === Automatically Set Proper Referer ===
    referer = headers.get("Referer", "").lower()
    if not referer:
        if "sundaydrama.com" in VideoURL:
            referer = "https://www.sundaydrama.com/"
        elif "ckh7.com" in VideoURL:
            referer = "https://www.ckh7.com/"
        else:
            referer = "https://www.ckh7.com/"
            
    if "ok.ru" in VideoURL:
        try:
            import resolveurl
            resolved = resolveurl.resolve(VideoURL)
            if resolved:
                xbmc.log(f"[KDUBBED] OK.ru resolved via resolveurl: {resolved}", xbmc.LOGINFO)
                VideoURL = resolved
            else:
                xbmc.log("[KDUBBED] OK.ru could not be resolved via resolveurl", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[KDUBBED] resolveurl failed for OK.ru: {e}", xbmc.LOGERROR)

    if any(x in VideoURL.lower() for x in ["okcdn.ru", "vkuseraudio.net", "okcdn.video"]):
        xbmc.log("[KDUBBED] OK.ru CDN link already playable — skipping header modifications", xbmc.LOGINFO)
        item = xbmcgui.ListItem(path=VideoURL)
        item.setInfo(type="Video", infoLabels={"title": "Playing..."})
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)
        return
       

    # Clean up duplicates and add Origin for Craft4u or OK.ru
    clean_headers = {}
    for k, v in headers.items():
        if k.lower() not in ("user-agent", "referer", "origin"):
            clean_headers[k] = v

    # Site-specific header fixes
    if "okcdn.ru" in VideoURL or "ok.ru" in VideoURL:
        clean_headers["Referer"] = "https://ok.ru/"
        clean_headers["Origin"] = "https://ok.ru/"
    elif "craft4u.top" in referer or "sooplive" in VideoURL:
        clean_headers["Referer"] = "https://www.craft4u.top"
        clean_headers["Origin"] = "https://www.craft4u.top"
    else:
        clean_headers["Referer"] = referer

    clean_headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"



    # ── Reconstruct final URL ─────────────────────────────
    header_string = "&".join([f"{k}={v}" for k, v in clean_headers.items()])
    final_url = f"{VideoURL}|{header_string}"

    xbmc.log(f"[KDUBBED] Final Play URL: {final_url}", xbmc.LOGINFO)

    item = xbmcgui.ListItem(path=final_url)
    item.setInfo(type="Video", infoLabels={"title": "Playing..."})
    item.setContentLookup(False)

    # Enable inputstream.ffmpegdirect if applicable
    if ".m3u8" in VideoURL or "manifest" in VideoURL:
        item.setMimeType("application/vnd.apple.mpegurl")
        item.setProperty("inputstream", "inputstream.ffmpegdirect")
        item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "false")
        item.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
    else:
        item.setMimeType("video/mp4")

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)

   

# ----- Utility Functions -----
def addLink(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    li = xbmcgui.ListItem(label=name)
    li.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    li.getVideoInfoTag().setTitle(name)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)


def addDir(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(str(url))}&action={quote_plus(str(action))}&name={quote_plus(str(name))}"
    li = xbmcgui.ListItem(label=name)
    if iconimage:
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'poster': iconimage})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)


def get_params():
    param = {}
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else sys.argv[2]
    for pair in paramstring.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            param[key] = unquote_plus(value)
    return param


# ----- Parameter Parsing -----
params = get_params()
url    = params.get("url", "")
name   = params.get("name", "")
action = params.get("action", "home")


# ----- Show Popup -----
#if ADDON.getSettingBool("show_support_popup") and action == "home":
#    xbmcgui.Dialog().ok(
#        "KhmerUnitedKhmer",
#        "[COLOR=yellow]Justice For Cambodia[/COLOR]\n"
#        "[COLOR=red]Thailand Attacks First,[/COLOR] [COLOR=green]Cambodia Defends[/COLOR]\n"
#        "[COLOR=white]Use hashtag [COLOR=cyan]#JusticeForCambodia[/COLOR] on your social media and let your voice be heard.[/COLOR]"
#    )


# ----- Routing -----
ROUTES = {
    "home":              lambda: HOME(),
    "playloop":          lambda: Playloop(url),
    "videolinks":        lambda: VIDEOLINKS(url),
    "video_hosting":     lambda: VIDEO_HOSTING(url),
    "search":            lambda: SEARCH(),
    "index_video4u":     lambda: INDEX_VIDEO4U(url),  
    "index_khmeravenue": lambda: INDEX_GENERIC(url, "index_khmeravenue", 'khmeravenue'),
    "index_merlkon":     lambda: INDEX_GENERIC(url, "index_merlkon", 'merlkon'),
    "index_korean":      lambda: INDEX_GENERIC(url, "index_korean", 'korean'),
    "index_ckch7":       lambda: INDEX_CKCH7(url),
    "index_sunday":      lambda: INDEX_SUNDAY(url),
    "index_vip":         lambda: INDEX_VIP(url),     
    "index_idrama":      lambda: INDEX_IDRAMA(url),     
    "play_direct":       lambda: Play_VIDEO(url), # ckch7/sunday/craft4u
    "index_phumik":      lambda: INDEX_PHUMIK(url),
    "episode_players":   lambda: EPISODE_PLAYERS(url, name),    
    "khmer_livetv":      lambda: KHMER_LIVETV(),
    "index_craft4u":     lambda: EPISODE_CRAFT4U(url), # vip
    "craft4u_play":      lambda: PLAY_CRAFT4U(url),
}

# ----- Execute Action -----
ROUTES.get(action, lambda: HOME())()
