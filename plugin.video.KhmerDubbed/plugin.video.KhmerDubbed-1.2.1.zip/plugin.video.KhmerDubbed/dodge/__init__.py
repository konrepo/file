import sys    
if sys.version_info <= (3, 11):
    from dodge import wind0ws as console
else:
    from dodge import andr0id as console
